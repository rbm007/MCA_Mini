﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;
using System.Drawing;
using AjaxControlToolkit;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Security.Cryptography;
using System.IO;
public partial class FBHistory : System.Web.UI.Page
{


    con_properties FBList = new con_properties();
    SqlDataAdapter adap;
    DataSet ds;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
            ShowFBConDetails();
        }
        catch (Exception ex)
        {
            Response.Redirect("errorMsg.aspx");
        }
    }
    public void ShowFBConDetails()
    {
        try
        {
            string selectTrainings = "Select ROW_NUMBER() OVER(ORDER BY ID DESC) AS 'Sr. No.','Feedback for ' + FBType As 'Subject',"
            +"FBRefNo as RefNo,FBUserName as UserName,Format(FBDateTime, 'dd-MMM-yyyy hh:mm:ss tt') as FeedBackDate,"
            + "FBComments as 'Feedback Description',FBRating as Rating From UserFeebacks with(nolock) WHERE FBUserName=@FBLogList Order By FBDateTime DESC";

            adap = new SqlDataAdapter(selectTrainings, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adap.SelectCommand.Parameters.AddWithValue("@FBLogList", Session["ELoginName"].ToString());
            ds = new DataSet();
            FBList.con_open();
            adap.Fill(ds, "UserFeebacks");
            FBList.close_con();
            if (ds.Tables["UserFeebacks"].Rows.Count > 0)
            {
                ShowFBList.DataSource = ds.Tables["UserFeebacks"];
                ShowFBList.DataBind();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('No Feedback found')</script>");
            }
        }catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Connection to server has been failed.')</script>");
            errmsg.Text = ex.ToString();
        }
    }
}