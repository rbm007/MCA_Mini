﻿Use JVIIT;
SELECT ROW_NUMBER() OVER(ORDER BY TRefNo ASC) AS SrNo,TRefNo as "Ticket Number", 
Format(TTrainingCreatedDate, 'dd-MMM-yyyy hh:mm tt') As 'Scheduled Date',
TTrainingTitle as 'Training Subject',
Format(TdateFromTime, 'dd-MMM-yyyy hh:mm tt') As 'Start Date', 
Format(TDateTillTime, 'dd-MMM-yyyy hh:mm tt') As 'End Date',
TType as 'Training Type', TTrainerName AS 'Trainer Name',
TTrainingLocation + ' ' + TTrainingVenue As 'Training Address',
TTrainingStatus as Status,
TTrainingNotes as Remarks
from UserTraining;
