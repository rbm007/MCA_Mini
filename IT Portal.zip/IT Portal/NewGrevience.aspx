﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="NewGrevience.aspx.cs" Inherits="NewGrevience" MasterPageFile="~/MasterPage.master" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <script src="scripts/jquery-ui.js"></script>
    <script src="scripts/jquery-ui.min.js"></script>
    <script src="scripts/jquery.js"></script>
    <div class="clear" runat="server"></div>
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div class="clear" runat="server"></div>
        <div class="clear" runat="server"></div>
        <div class="lblTrnTitle" runat="server">
            <p>Raise New Ticket</p>
        </div>
        <div class="clear" runat="server"></div>
        <%-- Requester Details --%>
        <div class="NewUserCreationSuper" runat="server">
            <asp:Panel class="frmSet" runat="server" GroupingText="Your Details" Direction="LeftToRight" CssClass="frmSet" ForeColor="#0033CC" Font-Bold="True">
                <div class="clear" runat="server"></div>
                <div class="trainingBox" runat="server">
                    <label class="left">Full Name: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtGrFullName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
                    </div>
                    <label class="left">User Name: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtGrUserName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
                    </div>
                    <label class="left">Email ID: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtGrEmailID" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
                    </div>
                </div>
            </asp:Panel>

            <%-- Ticket Details --%>
            <div class="clear" runat="server"></div>
            <br />
            <div class="frmSet" style="height: 500px; min-height: 400px;" cssclass="frmSet" runat="server" groupingtext="Ticket Information (All fields are mandatory)" direction="LeftToRight" forecolor="#000099" font-bold="True">
                <div class="clear" runat="server"></div>
                <p><b>Please enter all details and submit. We would revert you soon </b></p>
                <hr />
                <br />
                <div class="fieldRow" runat="server" id="Div9">
                    <label class="left">Issue Category: </label>
                    <div class="fixLength" runat="server">
                        <asp:DropDownList ID="cmbGrIssueCategory" runat="server" class="fixLength" OnSelectedIndexChanged="cmbIssueType_SelectedIndexChanged" OnLoad="cmbIssueType_SelectedIndexChanged" Enabled="false">
                            <asp:ListItem Selected="True" Enabled="true">Software/Hardware/HireCraft</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>

                <div class="clear" runat="server"></div>
                <div class="fieldRow" runat="server" id="Div1">
                    <label class="left">Issue Type: </label>
                    <div class="fixLength" runat="server">
                        <asp:DropDownList ID="cmbGrIssueType" runat="server" class="fixLength" OnSelectedIndexChanged="cmbIssueType_SelectedIndexChanged" OnLoad="cmbIssueType_SelectedIndexChanged">
                        </asp:DropDownList>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <div class="fieldRow" runat="server" id="Div2">
                    <label class="left">Issue Title: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtGrIssueTitle" runat="server" class="fixLength"></asp:TextBox>
                    </div>
                </div>

                <div class="clear" runat="server"></div>
                <div class="fieldRow" runat="server" id="Div3">
                    <label class="left">Issue Priority: </label>
                    <div class="fixLength" runat="server">
                        <asp:DropDownList ID="cmbGrIssuePriority" runat="server" class="fixLength">
                            <asp:ListItem Text="P1-Low" Selected="True"></asp:ListItem>
                            <asp:ListItem Text="P2-Medium"></asp:ListItem>
                            <asp:ListItem Text="P3-High"></asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>

                <div class="fieldRow" runat="server" id="Div4">
                    <label class="left">Facing Issue From: </label>
                    <div class="fixLength" runat="server">
                        <cc1:CalendarExtender TargetControlID="txtGrIssueDate" runat="server" FirstDayOfWeek="Monday" PopupPosition="TopLeft" Format="dd-MMM-yyyy dddd"></cc1:CalendarExtender>
                        <asp:TextBox ID="txtGrIssueDate" runat="server" Height="30" CssClass="fixLength" ToolTip="eg. 15-Jan-2017 10:00am"></asp:TextBox>
                    </div>
                </div>
                <div class="clear" runat="server"></div>

                <div class="fieldRow" runat="server" id="Div6">
                    <label class="left">Alternate Contact: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtGrAltContact" runat="server" class="fixLength"></asp:TextBox>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <div class="fieldRow" runat="server" id="Div5">
                    <label class="left">Describe your problem: </label>
                    <div class="fixLength" runat="server">
                        <textarea id="txtGrUserDecProblem" cols="10" rows="5" style="width: 350px; font-family:Verdana, Geneva, Tahoma, sans-serif; font-size:9px; overflow-x:hidden; overflow-y:auto;" runat="server"></textarea>
                    </div>
                </div>

            </div>
            <div class="clear" runat="server"></div>
            <div>
                
                <div class="LoginBtn" runat="server">
                    <asp:Button ID="btnSubmitNewGrevience" Text="Submit" runat="server" class="LogBtn" OnClick="btnSubmitNewGrevience_Click"/>
                    <asp:Button ID="btnResetGrevience" Text="Clear" runat="server" class="LogBtn" />
                </div>
<div class="clear" runat="server"></div>
                </div>
                <div class="clear" runat="server"></div>

                <asp:Label ID="lblResult" runat="server" Text="" ForeColor="#FF3300" Font-Size="Small"></asp:Label>
            
        </div>
    </div>
    <div class="NoShow" runat="server">

        <asp:Label ID="NWReqUserFullName" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWReqUserLogin" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWReqUserEmail" runat="server" Text=""></asp:Label>

        <asp:Label ID="NWReqNo" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWReqTitle" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWReqDate" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWReqType" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWEmpFullName" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWLocationOfWork" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWUserEmailAddress" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWHCID" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWHCNewOld" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWDesg" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWPhone" runat="server" Text=""></asp:Label>
        <asp:Label ID="NWRemarks" runat="server" Text=""></asp:Label>
    </div>
    <script>
        $(function () {
            $('#txtIssueDateFrom').datetimepicker
            ({
                inline: true
            });

            $('txtIssueDateFrom').datetimepicker
            ({ inline: true });

        })
    </script>

</asp:Content>
