﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="downloads.aspx.cs" Inherits="downloads" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>



<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear" runat="server">    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTeamMembers" runat="server">
   <div class="container" runat="server">
        <h1 class="lblTrnTitle">Important Download for Users<br /></h1>
<hr style="height:2pt; background-color:deepskyblue; border:0;" />

       <div class="ddList" runat="server">
       <asp:Panel GroupingText="Download Manuals" style="text-align:left;" runat="server" Font-Bold="True">
<li><a href="https://drive.google.com/file/d/1VObVb1reLgE0NY2EdoXVS4vjZ9Ai8Ks1/view?usp=sharing" target="HCManual">HireCraft User Manual</a></li>
<li><a href="https://drive.google.com/file/d/0B2eWHRO0BPadM25rMHJDRkNKOG8/view?usp=sharing" target="HCManual">HireCraft Resume Search Manual</a></li>
<li><a href="https://drive.google.com/file/d/1yHi2lfs4f9c1mNOva9c3dtmDK3vpLOgi/view?usp=sharing" target="HCManual">HireCraft SMS Manual</a></li>
<li><a href="https://drive.google.com/file/d/1yHi2lfs4f9c1mNOva9c3dtmDK3vpLOgi/view?usp=sharing" target="HCManual">Documents Uploading in HireCraft</a></li>
       </asp:Panel>
           </div>
       <div class="clear" runat="server"></div>
       <br />
       <br />
       <div class="ddList" runat="server">
              <asp:Panel GroupingText="Important Videos" style="text-align:left;" runat="server" Font-Bold="True">
               <li><a href="https://drive.google.com/file/d/1VObVb1reLgE0NY2EdoXVS4vjZ9Ai8Ks1/view?usp=sharing" target="HCManual">HireCraft User Manual</a></li>
               <li><a href="https://drive.google.com/file/d/0B2eWHRO0BPadM25rMHJDRkNKOG8/view?usp=sharing" target="HCManual">HireCraft Resume Search Manual</a></li>
               <li><a href="https://drive.google.com/file/d/1yHi2lfs4f9c1mNOva9c3dtmDK3vpLOgi/view?usp=sharing" target="HCManual">HireCraft SMS Manual</a></li>
       </asp:Panel>
           </div>
      <div class="clear" runat="server"></div>
       <br />
       <br />
       <div class="ddList" runat="server">
              <asp:Panel GroupingText="Other Important Downloads" style="text-align:left;" runat="server" Font-Bold="True">
               <li><a href="https://drive.google.com/file/d/1VObVb1reLgE0NY2EdoXVS4vjZ9Ai8Ks1/view?usp=sharing" target="HCManual">PC Cleaner</a></li>
               <li><a href="https://drive.google.com/file/d/0B2eWHRO0BPadV1RCNmVvaTc0RVk/view?usp=sharing" target="HCManual">HireCraft Fresh Setup</a></li>
               <li><a href="https://drive.google.com/file/d/1yHi2lfs4f9c1mNOva9c3dtmDK3vpLOgi/view?usp=sharing" target="HCManual">HireCraft SMS Manual</a></li>
       </asp:Panel>
           </div>
       <div class="clear" runat="server"></div>
       <br />
       <br />
       <div class="ddList" runat="server">
              <asp:Panel GroupingText="Forms and Formats" style="text-align:left;" runat="server" Font-Bold="True">
               <li><a href="https://drive.google.com/file/d/1VObVb1reLgE0NY2EdoXVS4vjZ9Ai8Ks1/view?usp=sharing" target="HCManual">Excel Resume Uploader(Referred Candidates)</a></li>
               <li><a href="https://drive.google.com/file/d/0B2eWHRO0BPadM25rMHJDRkNKOG8/view?usp=sharing" target="HCManual">New HireCraft Login Request</a></li>
               <li><a href="https://drive.google.com/file/d/1yHi2lfs4f9c1mNOva9c3dtmDK3vpLOgi/view?usp=sharing" target="HCManual">HireCraft Audit Sheet</a></li>
       </asp:Panel>
           </div>
</div>
    </asp:Content>
