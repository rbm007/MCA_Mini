﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Web.Globalization;

public partial class UserProfile : System.Web.UI.Page
{
    con_properties proLoad = new con_properties();
    SqlDataAdapter adp;
    DataSet dsProfile;
    SqlCommand cmd;
    string GetUserProfile;
    string saveUserProfileAboutUser;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoadUserProfile();
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");

            //lblShowError.Text = ex.ToString();
        }
    }
    public void LoadUserProfile()
    {
        GetUserProfile = "select EPreFix + ' ' + EFirstName + ' ' + EMiddleName + ' ' + ELastName As FullName,EGen As Gender,FORMAT(EDOB, 'dd-MMM-yyyy, dddd') As EDOB,"
        + "EMaritalStatus as Marital,EMobile,EEmail,EJoinDate,EEducation, EDesg + ' - ' + EDept + ' ( ' + ELocation + ', ' + EDiv + ' )' As WorkLocation,"
        + "EDesg,ELoginName as UserName,FORMAT(ELoginCreatedDate, 'dd-MMM-yyyy, dddd') As RegisteredOn,EmpModifiedDate as LastUpdated,"
        + "FORMAT(EJoinDate, 'dd-MMM-yyyy, dddd') As EDOJ,JVIEmpAboutUser from JVIEmp with(nolock) where ELoginName=@ELoginName";

        adp = new SqlDataAdapter(GetUserProfile, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
        adp.SelectCommand.Parameters.AddWithValue("@ELoginName", Session["ELoginName"].ToString().Trim());
        dsProfile = new DataSet();
        proLoad.con_open();
        adp.Fill(dsProfile, "JVIEmp");
        proLoad.close_con();

        if (dsProfile.Tables["JVIEmp"].Rows.Count > 0)
        {
            profileFullName.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["FullName"]);
            profileGen.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["Gender"]);
            profileDOB.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["EDOB"]);
            profileRegDate.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["RegisteredOn"]);
            profileWorkingDetails.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["WorkLocation"]);
            profileJoinDate.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["EDOJ"]);
            profileQualification.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["EEducation"]);
            profileEmail.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["EEmail"]);
            profileMobile.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["EMobile"]);
            profileUpdatedTime.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["LastUpdated"]);
            profileUserAbout.Text = string.Format("{0}", dsProfile.Tables["JVIEmp"].DefaultView[0]["JVIEmpAboutUser"]);
        }
        else
        {
            try
            {
            }
            catch (Exception ex)
            {
                lblShowError.Text = ex.ToString();
            }
        }
    }

    protected void btnSaveUserProfile_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            saveUserProfileAboutUser = "Update JVIEmp SET JVIEmpAboutUser=@abtUser Where EEmail=@UserEmail";
            cmd = new SqlCommand(saveUserProfileAboutUser, con);
            con.Open();
            cmd.Parameters.AddWithValue("@abtUser", profileUserAbout.Text.ToString());
            cmd.Parameters.AddWithValue("@UserEmail", profileEmail.Text.ToString());
            cmd.ExecuteNonQuery();
            con.Close();
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Details Updated Successfuly')</script>");
            Response.Redirect("Default.aspx");
        }            
        catch (Exception ex)
        { lblShowError.Text = ex.ToString();}
    }
}



