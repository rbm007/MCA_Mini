﻿Use JVIIT;
select EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName As EmpName,ELoginName,EFirstName,Epasskey from JVIEmp with(nolock)
create table User_Role (URoleID int primary key not null, URoleName varchar(50)Not Null);
insert into User_Role Values(3,'Employee');

alter table JVIEmp Add URoleID int references User_Role(URoleID);

SELECT * from JVIEmp with(nolock);
update JVIEmp Set URoleID=3 Where EID=1;
select * from UserTraining with(nolock);

Select TrefNo as TrainingNumber, TDateFromTime as TrainingDate, TTYpe as TrainingType, TTrainingCreatedDate as ScheduledOn,
ttrainingLocation As TrainingLocation  from UserTraining with(nolock)


Update Usertraining Set TTrainingNotes = 'Recruiter Training Online required' Where TID=2;

Alter Table UserTraining Add  TTrainingModifiedDate datetime default(CURRENT_TIMESTAMP);

Select EFirstName, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName AS FullName FROM jviemp;
create table JVIUserRequestForPassword(ID int identity(1,1), 
RequestDateTime datetime default(CURRENT_TIMESTAMP),
UserName varchar(50) Foreign Key References JVIEmp(ELoginName),
Email nvarchar(100),
Mobile nvarchar(20));

select * from JVIUserRequestForPassword;

Create Table UserGreviences(id int IDENTITY(1,1)NOT NULL,
GrPrefix varchar(10) default('UG') NOT NULL,
GrRefNo  As (GrPrefix+right('000000'+Convert([Varchar](10),[ID]),(10))) PERSISTED,
GrLoggedInDate datetime default(CURRENT_TIMESTAMP),
GrModifiedDate datetime default(CURRENT_TIMESTAMP),
ELoginName varchar(50) Foreign Key References JVIEmp(ELoginName),GrIssueTitle varchar(100),
GrRequestedUser varchar(50) not null,
GrAltContact varchar(max),
GrRequestedUserEmail nvarchar(150)not null,
GrCategory varchar(100)not null, 
GrType varchar(100)not null,
GrPriority NVarchar(50)not null,
GrIssueFrom Date not null,
GrDesc nVarchar(max), 
GrCompleted Date,GrStatus varchar(20),
);
alter table JVIEmp drop column Epassword;
alter table JVIEmp Add Epassword binary(100);
alter table JVIEmp alter column Epassword binary(64);
select * from JVIEmp;

Select EloginName, EPassKey, EEmail, Emobile from JVIEmp WITH(NOLOCK)

declare @pkey NVarchar(100)
update JVIEmp SET Epassword=HASHBYTES('ram@123',Epasskey) where EMobile=7977261158;

update JVIEmp SET Epasskey='ram@123' where EMobile=7977261158;

update JVIEmp Set Epassword= HashBytes('ram@123', Epasskey) where EMobile=7977261158;
select * from UserGreviences;
SELECT CONVERT(nvarchar, DecryptByPassphrase(Password, EncKey)) As PasswordValue from HC_Users with(nolock) Where Username='ram.mishra'; 
    AS 'Decrypted card number' FROM Sales.CreditCard   
    WHERE CreditCardID = '3681';  

Select ROW_NUMBER() OVER(ORDER BY ID ASC) AS 'Sr. No.','Issue In ' + GrCategory + ' ( ' + GrType + ' )' As 'Subject',
Format(GrLoggedInDate, 'dd-MMM-yyyy hh:mm:ss tt') as RequestedDate, EloginName AS UserName,GrPriority as Priority, GrRequestedUser as UserFullName,
GrAltContact as 'Alternate Contact',GrRequestedUserEmail As 'Email ID', GrIssueFrom as IssueFrom, GrDesc AS Description,
GrStatus as Status from UserGreviences;

Select ROW_NUMBER() OVER(ORDER BY ID ASC) AS 'Sr. No.','Feedbak for ' + FBType As 'Subject',FBUserFullName as UserName,Format(FBDateTime, 'dd-MMM-yyyy hh:mm:ss tt') as FeedBackDate,
FBComments as 'Feedback Description',FBRating as Rating From UserFeebacks with(nolock) Order By FBDateTime DESC;


declare @encrypt varbinary(200) 
select @encrypt = EncryptByPassPhrase('key', 'abc' )
Select Username, * from HC_Users with(nolock) Where Username='ram.mishra';

SELECT CAST(Password AS varchar(20)) AS Pass from HC_Users with(nolock) Where Username='ram.mishra';

Select ROW_NUMBER() OVER(ORDER BY id ASC) AS SrNo, GrRefNo As CaseID,Format(GrLoggedInDate, 'dd-MMM-yyyy hh:mm:ss tt') As 'Requeste Date',GrIssueTitle as SubjectTitle,
GrCategory + ' - ' + GrType as Category, GrPriority as Priority,GrIssueFrom as 'Issue From',GrCompleted as 'Resolved Date', GrDesc As IssueDescription,
GrStatus as Status from UserGreviences with(nolock) Where EloginName=@grLogin order by GrLoggedInDate desc;

Create Table UserLoginLog(id int identity(1,1) not null, LoginDateTime datetime default(CURRENT_TIMESTAMP),ELoginName varchar(50) Foreign Key References JVIEmp(ELoginName),PC_Name varchar(50) Not Null, BrowserName varchar(50));

Create Table UserFeebacks(
ID int identity(1,1) not null,
FBPrefix varchar(10) default('FB') NOT NULL,
FBRefNo  As (FBPrefix+right('0000'+Convert([Varchar](10),[ID]),(10))) PERSISTED,
FBUserEmail nvarchar(100)not null,
FBUserName varchar(50) Foreign Key References JVIEmp(ELoginName),
FBUserFullName varchar(50) not null,
FBUserLocation nvarchar(100)not null,
FBType varchar(20)NOT NULL, 
FBDateTime dateTime default(CURRENT_TIMESTAMP),
FBComments NVARCHAR(max)not null,
FBRating nvarchar(20) not null
);

DROP table UserFeebacks;

select * from UserFeebacks;
select * from issue
select * from UserLoginLog;
use master;
select * from Issues
Update Issues Set IssueTitle='Internet Browser Issue' WHERE id=26;
USE [master]
GO
CREATE DATABASE [SQLAuthority] ON
( FILENAME = N'C:\inetpub\wwwroot\IT Portal\IT Portal\App_Data\DB\JVIIT.mdf' ),
( FILENAME = N'C:\inetpub\wwwroot\IT Portal\IT Portal\App_Data\DB\JVIIT_log.ldf' )
 FOR ATTACH
GO;
DBCC CHECKPRIMARYFILE('C:\inetpub\wwwroot\IT Portal\IT Portal\App_Data\DB\JVIIT.mdf',2)
--Back up Data
DECLARE @name VARCHAR(50) -- database name  
DECLARE @path VARCHAR(256) -- path for backup files  
DECLARE @fileName VARCHAR(256) -- filename for backup  
DECLARE @fileDate VARCHAR(20) -- used for file name
 
-- specify database backup directory
SET @path = 'D:\'  
 
-- specify filename format
SELECT @fileDate = CONVERT(VARCHAR(20),GETDATE(),112) 
 
DECLARE ram_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM master.dbo.sysdatabases 
WHERE name IN ('JVIIT')  -- exclude these databases
 
OPEN db_cursor   
FETCH NEXT FROM ram_cursor INTO @name   
 
WHILE @@FETCH_STATUS = 0   
BEGIN   
   SET @fileName = @path + @name + '_' + @fileDate + '.BAK'  
   BACKUP DATABASE @name TO DISK = @fileName  
 
   FETCH NEXT FROM db_cur INTO @name   
END

CLOSE ram_cursor
DEALLOCATE ram_cursor

--Backup end



select * from JVIEmp;
create table Issues (id int not null IDENTITY(1,1),AddedOn datetime default(Current_TimeStamp),IssueTitle varchar(100)not null, IssueType varchar(50));
insert into SoftwareIssue(IssueTitle) Values('Portal Issue')
select * from Issues order By IssueTitle ASC;

Select IssueTitle from Issues with(nolock) Where IssueType='Software';
Insert into JVIIT.dbo.Issues(IssueTitle, IssueType) Select IssueTitle, IssueType from master.dbo.Issues;

exec sp_rename 'HireCraftIssue', 'Issues'
Alter Table HireCraftIssue Add IssueType varchar(50);
Update HardwareIssue set IssueType='Hardware';

alter Table JVIEmp Add JVIEmpAboutUser nvarchar(max);
Insert into JVIEmp(EPreFix,EFirstName,EMiddleName,ELastName,EGen,EDOB, EMaritalStatus,EMobile, EEmail, EJoinDate,EEducation,ELocation,
EDept,EDiv,EDesg,ELoginName,EPassword, ELoginCreatedDate, EWorkingStatus) VALUES('Mr.','Appaso','M','Katkar','Male','10-Mar-1981','Married',09833520852,
'support1@jvi-global.com','10-Apr-2003','Graduate-B.Com','Mumbai','IT-Hardware','Sakinaka','IT Administrator','a.katkar','katkar@123','15-Apr-2007','Working');

USE JVIIT;

ALTER DATABASE JVIIT SET READ_WRITE WITH NO_WAIT;
ALTER DATABASE JVIIT SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE JVIIT SET MULTI_USER
ALTER DATABASE JVIIT SET MULTI_USER WITH NO_WAIT
ALTER DATABASE JVIIT SET MULTI_USER WITH ROLLBACK IMMEDIATE



select * from JVIEmp;
select * from UserTraining;

Create Table UserCreationRequest
(
UCRID int identity(1,1)not null,
UCRPrefix varchar(10) default('UCR') NOT NULL,
UCRRefNo As ([UCRPrefix]+right('000000'+Convert([Varchar](10),[UCRID]),(10))) PERSISTED,
ELoginName varchar(50) Foreign Key References JVIEmp(ELoginName),
UCRRequestedDate dateTime default(CURRENT_TIMESTAMP),
UCRRequestedUser varchar(50) not null,
UCRRequestedUserEmail nvarchar(150)not null,
UCRNewUserTitle varchar(10)not null,
UCRNewUserFirstName varchar(50)not null,
UCRNewUserMiddleName varchar(50),
UCRNewUserLastName varchar(50)not null,
UCRNewUserEmailID nvarchar(150)UNIQUE NOT NULL,
UCRNewUserPhone numeric(20)Unique Not Null,
UCRNewUserHCID nvarchar(20)primary key not null,
UCRNewUserDesg varchar(50)not null,
UCRNewUserLocation varchar(50)not null,
UCRNewUserDivision varchar(50)not null,
UCRNewUserDeptName varchar(70)not null,
UCRNewUserTeam varchar(50)not null,
UCRNewUserJoinedDate date not null,
UCRNewUserCreationStatus varchar(20),
UCRNewUserCreationNewOld varchar(50),
UCRNewUserRemarks varchar(max)
)

drop table UserCreationRequest;

Alter table UserCreationRequest Alter Column UCRRequestedDate DateTime;
alter table UserCreationRequest drop column UCRRequestedDate;


Select Top 1 UCRRefNo,UCRNewUserCreationNewOld,UCRRequestedDate,UCRNewUserTitle+ ' ' + UCRNewUserFirstName + ' ' + UCRNewUserMiddleName + ' ' + UCRNewUserLastName
As NewUserFullName,UCRNewUserHCID,UCRNewUserDesg,UCRNewUserLocation+ ', ' + UCRNewUserDivision+ ' [ ' + UCRNewUserDeptName + ' - ' + UCRNewUserTeam + ' ] ' As WorkLocation,
UCRNewUserEmailID,UCRNewUserPhone,UCRNewUserRemarks
from UserCreationRequest with(nolock)

alter Table UserCreationRequest ADD UCRNewUserDeptName varchar(70);

Drop Table UserCreationRequest;
SELECT ELoginName,EEmail, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName + '( ' + Edesg + ' )' As EmpFullName from JVIEmp;

INSERT INTO UserCreationRequest(ELoginName,UCRRequestedUser,UCRRequestedUserEmail,UCRNewUserTitle,UCRNewUserFirstName,UCRNewUserMiddleName,UCRNewUserLastName,UCRNewUserEmailID,UCRNewUserPhone,
UCRNewUserHCID,UCRNewUserDesg,UCRNewUserLocation,UCRNewUserDivision,UCRNewUserTeam,UCRNewUserDeptName,UCRNewUserJoinedDate,UCRNewUserCreationStatus,
UCRNewUserRemarks,UCRNewUserCreationNewOld)
VALUES('ram.mishra','Mr. Ram B Mishra( IT Executive )','support2@jvi-global.com','Mr.','Pravin','R','Jadhav','mumpetro1@jvi-global.com',022491402529,'pravin.jadhav',
'Sr. Recruiter','Mumbai','JVC-Nariman Point','Projects And Construction','Recruitment Team','30-Oct-2017','In-Process','New ID','Please create new HireCraft ID');

Select * from UserCreationRequest;

truncate table UserCreationRequest;
CREATE TABLE UserTraining
(
	TID INT identity(1,1)not null,
	TPreFix varchar(10) default('JVI') not null,
	TRefNo As ([TPreFix]+right('000000'+CONVERT([varchar](7),[TID]),(7))) PERSISTED,
	ELoginName VARCHAR(50)Foreign Key References JVIEmp(ELoginName),
	TDateFromTime dateTime not null,
	TDateTillTime dateTime not null,
	TType varchar(50)not null,
	TTrainingCreatedDate date default(GetUTCDate()),
	TTrainerName varchar(max),
	TTrainingLocation varchar(50),
	TTrainingFeedBackScore int,
	TTrainingStatus varchar(50)Not Null,
	TUserLevel varchar(50),
);

Create Table JVIEmp
(
EID int identity(1,1)not null,
EPreFix varchar(5) not null,
EFirstName  varchar(max) not null,
EMiddleName varchar(max),
ELastName varchar(max) Not Null,
EGen varchar(10)not null,
EDOB date not null,
EMaritalStatus varchar(20),
EMobile numeric(20)Unique Not Null,
EEmail varchar(50)Unique Not Null,
EJoinDate date not null,
EEducation varchar(max),
ELocation varchar(max),
EDept varchar(max),
EDiv varchar(max),
EDesg varchar(max),
ELoginName varchar(50) Primary Key Not Null,
EPassword varchar(50) Not Null,
ELoginCreatedDate date,
EResignDate date,
EWorkingStatus Varchar(50)
);

select * from JVIEmp;
update JVIEmp SET JVIEmpAboutUser='I am graduate in Computer Science' Where EID=1;

ALTER TABLE JVIEmp ALTER COLUMN EmpCreatedDate DateTime;
default(CURRENT_TIMESTAMP);
Alter Table JVIEmp ALter Column EmpCreatedDate dateTime default(GetUTCDate());
,EmpModifiedDate date default(GetUTCDate());
select * from UserTraining;
Use JVIIT;
SELECT ELoginName, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName + '( ' + Edesg + ' )' As EmpFullName FROM JVIEMP;