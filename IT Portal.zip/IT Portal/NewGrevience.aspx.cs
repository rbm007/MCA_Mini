﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;


public partial class NewGrevience : System.Web.UI.Page
{
    con_properties newGR = new con_properties();
    SqlDataAdapter adp;
    DataSet ds;
    DataTable dt;
    string SoftwareIssues;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
                       //LoadSoftwareIssue();
            NewUserRequesterData();
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("errorMsg.aspx");
        }
    }
    protected void NewUserRequesterData()
    {
        try
        {
            string selectDt = "SELECT ELoginName,EEmail, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName As EmpFullName"
            + " From JVIEmp with(nolock) Where ELoginName=@Ugr";
            SqlDataAdapter adp = new SqlDataAdapter(selectDt, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
            adp.SelectCommand.Parameters.AddWithValue("@Ugr", Session["ELoginName"].ToString());
            ds = new DataSet();
            newGR.con_open();
            adp.Fill(ds, "JVIEmp");
            newGR.close_con();
            if (ds.Tables["JVIEmp"].Rows.Count > 0)
            {
                // Text Box Binding
                txtGrFullName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpFullName"]);
                txtGrUserName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["ELoginName"]);
                txtGrEmailID.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EEmail"]);

                // Lable Binding
                NWReqUserLogin.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["ELoginName"]);
                NWReqUserFullName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpFullName"]);
                NWReqUserEmail.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EEmail"]);

            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Session Expired. Kindly Re-Login to Schedule Training Error Code: 005')</script>");
            }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.ToString();
            //ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Session Expired. Kindly Re-Login to Schedule Training Error Code: 005')</script>");
            //Response.Redirect("Login.aspx");
        }
    }

    protected void sendUserGrevienceIntimationToITTeam()
    {

    }
    //protected void sendUserGreviencEmailConfirmation()
    //{
    //    string selectNewUserRequest;
    //    try
    //    {
    //        selectNewUserRequest = "Select Top 1 UCRRefNo,UCRNewUserCreationNewOld,UCRRequestedDate,UCRNewUserTitle+ ' ' + UCRNewUserFirstName + ' ' + "
    //        + "UCRNewUserMiddleName + ' ' + UCRNewUserLastName As NewUserFullName,UCRNewUserHCID,UCRNewUserDesg,UCRNewUserLocation+ ', ' + UCRNewUserDivision+"
    //        + "' [ ' + UCRNewUserDeptName + ' - ' + UCRNewUserTeam + ' ] ' As WorkLocation, UCRNewUserEmailID,UCRNewUserPhone,UCRNewUserRemarks"
    //        + " from UserCreationRequest with(nolock) Where EloginName=@EL order by UCRRequestedDate DESC";

    //        adp = new SqlDataAdapter(selectNewUserRequest, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
    //        adp.SelectCommand.Parameters.AddWithValue("@EL", Session["ELoginName"].ToString());
    //        newGR.con_open();
    //        adp.Fill(ds, "UserCreationRequest");
    //        newGR.close_con();
    //        if (ds.Tables["UserCreationRequest"].Rows.Count > 0)
    //        {
    //            NWReqNo.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRRefNo"]);
    //            NWHCNewOld.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRNewUserCreationNewOld"]);
    //            NWReqDate.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRRequestedDate"]);
    //            NWEmpFullName.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["NewUserFullName"]);
    //            NWHCID.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRNewUserHCID"]);
    //            NWDesg.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRNewUserDesg"]);
    //            NWLocationOfWork.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["WorkLocation"]);
    //            NWUserEmailAddress.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRNewUserEmailID"]);
    //            NWPhone.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRNewUserPhone"]);
    //            NWRemarks.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["UCRNewUserRemarks"]);

    //            MailMessage EmailMsg = new MailMessage();
    //            SmtpClient NewClient = new SmtpClient("smtpout.jvi-global.com");
    //            EmailMsg.From = new MailAddress("support2@jvi-global.com");
    //            EmailMsg.To.Add(txtNewUserCreationEmailID.Text.ToString().Trim());
    //            EmailMsg.CC.Add(txtNewUserEmailAddress.Text.ToString());
    //            EmailMsg.Subject = "Request Number " + NWReqNo.Text.ToString().Trim() + " for " + cmbNewUserLoginOption.Text.ToString();

    //            EmailMsg.Body = "<div class=emailContent><font family=arial size=4 color=blue>Dear " + txtNewUserCreationFullName.Text.ToString().Trim() + ",<br><br>Greetings! from Jerry Varghese International,"
    //            + "<br/><br><desc>We are glad to inform you that you request has been successfully registered on " + DateTime.Now + " with JVI-IT Team and it is In-Process.<br>"
    //            + "New HireCraft Login ID will be created based on the below details provided by you.<hr /></font><font color=white family=verdana size=4>"
    //            + "<table align=centre width=100% cellpadding=2 rowpadding=5 cellspacing=2 border=2 bordercolor=blue color=white><tr font family=verdana bgcolor=DeepSkyBlue>"
    //            + "<th>Sr.No.</th><th>Request Number</th><th>Request Title</th><th>Request Date</th><th>Employee Full Name</th><th>Work Location</th>"
    //            + "<th>Email ID</th><th>HireCraft ID*</th><th>Designation</th><th>Phone Number</th><th>Required Action</th></tr>"
    //            + "<tr align=center><td>1</td><td>" + NWReqNo.Text.ToString().Trim() + "</td><td>" + NWHCNewOld.Text.ToString().Trim() + "</td>"
    //            + "<td>" + NWReqDate.Text.ToString().Trim() + "</td><td>" + NWEmpFullName.Text.ToString().Trim() + ""
    //            + "</td><td>" + NWLocationOfWork.Text.ToString().Trim() + "</td>"
    //            + "<td>" + NWUserEmailAddress.Text.ToString().Trim() + "</td><td>" + NWHCID.Text.ToString().Trim() + "</td><td>" + NWDesg.Text.ToString().Trim() + "</td>"
    //            + "<td>" + NWPhone.Text.ToString().Trim() + "</td><td>" + NWRemarks.Text.ToString().Trim() + "</td></tr></table><br></font>"
    //            + "<font family=verdana size=4 color=black>Kindly make login again, If you wish to change the training schedule details.</font><br><hr><br>"
    //            + "<img src=http://103.231.41.110/Logo/Sign.png width=100% height=240px alt=Signature></div>";

    //            EmailMsg.IsBodyHtml = true;
    //            NewClient.Port = 25;
    //            NewClient.Credentials = new NetworkCredential("support2@jvi-global.com", "Hraf@923");
    //            NewClient.EnableSsl = false;
    //            NewClient.Send(EmailMsg);
    //            lblResult.Text = lblResult.Text.ToString() + ". Email has been sent successfully.";
    //        }
    //        else
    //        {
    //            try
    //            { }
    //            catch (Exception ex)
    //            {
    //                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Email not sent.')</script>");
    //                lblResult.Text = ex.ToString();
    //            }
    //        }
    //    }
    //    //ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
    //    catch (Exception ex)
    //    {
    //        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Email Couldn't be sent.')</script>");
    //        //lblResult.Text = ex.ToString();
    //        //string message = string.Format("Message: {0}\\n\\n", ex.Message);
    //        //message += string.Format("StackTrace: {0}\\n\\n", ex.StackTrace.Replace(Environment.NewLine, string.Empty));
    //        //message += string.Format("Source: {0}\\n\\n", ex.Source.Replace(Environment.NewLine, string.Empty));
    //        //message += string.Format("TargetSite: {0}", ex.TargetSite.ToString().Replace(Environment.NewLine, string.Empty));
    //        //ClientScript.RegisterStartupScript(this.GetType(), "Error Occured", "<script language='javascript'>alert(\"" + message + "\");", true);
    //    }
    //}
    protected void LoadSoftwareIssue()
    {
        try
        {
            SoftwareIssues = "Select IssueTitle from Issues with(nolock) order by IssueTitle ASC";
            SqlDataAdapter adp1 = new SqlDataAdapter(SoftwareIssues, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
            //adp1.SelectCommand.Parameters.AddWithValue("@i", cmbIssueCategory.Text.Trim().ToString());
            dt = new DataTable();
            newGR.con_open();
            adp1.Fill(dt);
            newGR.close_con();

            cmbGrIssueType.DataSource = dt;
            cmbGrIssueType.DataTextField = dt.Columns["IssueTitle"].ToString();
            cmbGrIssueType.DataValueField = dt.Columns["IssueTitle"].ToString();
            cmbGrIssueType.DataBind();
            cmbGrIssueType.Enabled = true;
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Failed to Load')</script>");
            lblResult.Text = ex.ToString();

        }

    }

    protected void cmbIssueType_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadSoftwareIssue();
    }



    protected void btnSubmitNewGrevience_Click(object sender, EventArgs e)
    {
        saveNewUserGrevience();
    }


    protected void saveNewUserGrevience()
    {
        string saveNewGrev;
        try
        {
            saveNewGrev = "INSERT INTO UserGreviences(ELoginName,GrRequestedUser,GrRequestedUserEmail,GrCategory,GrType,GrAltContact,GrIssueTitle,"
            + "GrPriority,GrIssueFrom,GrDesc) VALUES(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j)";

            adp = new SqlDataAdapter(saveNewGrev, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));

            //requester details : Convert.ToDateTime(txtNewuserDOJ.Text.Trim()).ToString("dd-MMM-yyyy"));

            adp.SelectCommand.Parameters.AddWithValue("@a", txtGrUserName.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@b", txtGrFullName.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@c", txtGrEmailID.Text.ToString().Trim());
            // User Details
            adp.SelectCommand.Parameters.AddWithValue("@d", cmbGrIssueCategory.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@e", cmbGrIssueType.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@f", txtGrAltContact.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@g", txtGrIssueTitle.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@h", cmbGrIssuePriority.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@i", Convert.ToDateTime(txtGrIssueDate.Text.Trim()).ToString("dd-MMM-yyyy"));
            adp.SelectCommand.Parameters.AddWithValue("@j", txtGrUserDecProblem.InnerText.ToString().Trim());

            ds = new DataSet();
            newGR.con_open();
            adp.Fill(ds, "UserGreviences");
            newGR.close_con();
            Response.Write("<script>alert('User Grevience has been registered successfully.Details has been sent on your email.')</script>");
           
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.ToString();
            //ClientScript.RegisterStartupScript(Page.GetType(), "Validation Failed", "<script language='javascript'>alert('You are not loggedIn. Kindly Re-Login.')</script>");
        }
    }
}