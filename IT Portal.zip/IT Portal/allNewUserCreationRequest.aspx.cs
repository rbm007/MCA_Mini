﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;
using System.Drawing;
using AjaxControlToolkit;

public partial class alltraining : System.Web.UI.Page
{

    con_properties con = new con_properties();
    SqlDataAdapter adap;
    DataSet ds;


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
            BindAllRequestList();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Session Expired. Kindly re-login')</script>");
            //ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("errorMsg.aspx");
            
        }

    }


    public void BindAllRequestList()
    {
        try
        {


            //string selectTrainings = "Select * from UserTraining with(nolock) Where ELoginName=@a";

            //string selectTrainings = "SELECT ROW_NUMBER() OVER(ORDER BY TRefNo ASC) AS SrNo,TRefNo as 'Ticket Number',"
            //+ "Format(TTrainingCreatedDate, 'dd-MMM-yyyy hh:mm tt') As 'Scheduled Date',TTrainingTitle as 'Training Subject',"
            //+ "Format(TdateFromTime, 'dd-MMM-yyyy hh:mm tt') As 'Start Date', Format(TDateTillTime, 'dd-MMM-yyyy hh:mm tt') As 'End Date',"
            //+ "TType as 'Training Type', TTrainerName AS 'Trainer Name',TTrainingLocation + ' ' + TTrainingVenue As 'Training Address',"
            //+ "TTrainingStatus as Status,TTrainingNotes as Remarks from UserTraining with(nolock) "
            //+ "Where ELoginName=@a";

            string selectNewUserRequest = "Select ROW_NUMBER() OVER(ORDER BY UCRRefNo ASC) AS SrNo,UCRRefNo As 'Req ID',UCRNewUserCreationNewOld As Title,"
            +"UCRRequestedDate As 'Request Date',UCRNewUserTitle+ ' ' + UCRNewUserFirstName + ' ' + UCRNewUserMiddleName + ' ' + UCRNewUserLastName "
            +" As 'User Name',UCRNewUserHCID As 'HC ID',UCRNewUserDesg As Designation,UCRNewUserLocation+ ', ' + UCRNewUserDivision + ' ' + ' [ ' + UCRNewUserDeptName + ' - '+"
            +"UCRNewUserTeam + ' ] ' As Location, UCRNewUserEmailID As Email,UCRNewUserPhone As Phone,UCRNewUserRemarks As Notes"
             + " from UserCreationRequest with(nolock) Where EloginName=@EL order by UCRRequestedDate ASC";

            adap = new SqlDataAdapter(selectNewUserRequest, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adap.SelectCommand.Parameters.AddWithValue("@EL", Session["ELoginName"].ToString());
            ds = new DataSet();
            con.con_open();
            adap.Fill(ds, "UserCreationRequest");
            con.close_con();
            if (ds.Tables["UserCreationRequest"].Rows.Count > 0)
            {
                ShowAllRequestList.DataSource = ds.Tables["UserCreationRequest"];
                ShowAllRequestList.DataBind();
            }
            else
            {
               
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('You have not submiited any request.')</script>");
                
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Error in loading training details.Try Again.')</script>");
            errmsg.Text = ex.ToString();
        }
    }
   
       
}