﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="NewTraining.aspx.cs" Inherits="Training" MasterPageFile="~/MasterPage.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ContentPlaceHolderID="MainHead" runat="server">
            <div class="HeadLogo" runat="server">
                <img src="images/logo.png" align="left" />
                <div class="welcomeUser" runat="server" id="welUname">
                    <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
                    <hr />                    <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
                </div>
            </div>
            <div class="clear">
            </div>
        </asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="clear" runat="server">    </div>   
     <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
                <div class="clear" runat="server"></div>
        <div class="clear" runat="server"></div>
        <div class="lblTrnTitle"><p>Schedule New Training</p>        </div>
        <div class="clear"></div>
<asp:Panel runat="server" class="frmSet" GroupingText="Enter Training Information here" ForeColor="#000099" Font-Bold="True">
        <div class="trainingBox" runat="server">
            <label class="left">User Name: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTrainingUserName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
            </div>
            <div class="clear"></div>
            <label class="left">Trainee Full Name: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTraineeFullName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
            </div>
            <div class="clear"></div>
            <label class="left">Trainee Email ID: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTraineeEmail" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox>
            </div>
            <div class="clear"></div>
            <label class="left">User Location: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtUserLocationInfo" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox>
            </div>
            <div class="clear"></div>
            <label class="left">Enter Training Title: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTrainingTitle" runat="server" class="fixLength"></asp:TextBox>
            </div>
            <div class="clear"></div>
            <label class="left">Training Location: </label>
            <div class="fixLength" runat="server">
                <asp:DropDownList ID="cmbTrainingLocation" runat="server" class="fixLength">
                    <asp:ListItem>Mumbai</asp:ListItem>
                    <asp:ListItem>Dubai</asp:ListItem>
                    <asp:ListItem>Chennai</asp:ListItem>
                    <asp:ListItem>Bangalore</asp:ListItem>
                    <asp:ListItem>Hyderabad</asp:ListItem>
                    <asp:ListItem>Delhi</asp:ListItem>
                    <asp:ListItem>Cochin</asp:ListItem>
                    <asp:ListItem>Baroda</asp:ListItem>
                    <asp:ListItem>Online Training</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="clear"></div>
            <label class="left">Training Venue: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTrainingVenue" runat="server" class="fixLength" ReadOnly="False"></asp:TextBox>
            </div>
            <div class="clear"></div>
            <label class="left">Training Type: </label>
            <div class="fixLength" runat="server">
                <asp:DropDownList ID="cmbTrainingType" runat="server" class="fixLength">
                    <asp:ListItem>HireCraft - Online</asp:ListItem>
                    <asp:ListItem>Skype Training</asp:ListItem>
                    <asp:ListItem>Module Training</asp:ListItem>
                    <asp:ListItem>Application Training</asp:ListItem>
                    <asp:ListItem>Outlook Training</asp:ListItem>
                    <asp:ListItem>Other Training</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="clear"></div>
            <label class="left">Training Date From: </label>
            <div class="fixLength" runat="server">

                <%--<cc1:MaskedEditExtender ID="dateFrom" runat="server" TargetControlID="dtFrom" Mask="99-LLL-9999 9:9" MaskType="DateTime" ClipboardEnabled="False" AutoComplete="False" UserDateFormat="DayMonthYear"></cc1:MaskedEditExtender>--%>
                <cc1:CalendarExtender TargetControlID="dtFrom" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy HH:mm"></cc1:CalendarExtender>
                <asp:TextBox ID="dtFrom" runat="server" Height="30" Width="163" ToolTip="eg. 15-Jan-2017 10:00am" ReadOnly="False" />
                To 
                <cc1:CalendarExtender TargetControlID="dtTo" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy HH:mm"></cc1:CalendarExtender>
                <%--<cc1:MaskedEditExtender ID="dateTo" runat="server" TargetControlID="dtTo" Mask="99/AAA/9999 99:99" MaskType="DateTime" UserDateFormat="DayMonthYear"></cc1:MaskedEditExtender>--%>
                <asp:TextBox ID="dtTo" runat="server" Height="30" Width="163" ToolTip="eg. 15-Jan-2017 05:00pm" ReadOnly="False" />
            </div>
            <div class="clear"></div>
            <label class="left">Trainer Name: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTrainerName" runat="server" Text="Mr. Ram B Mishra( JVI-IT, Mumbai )" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox>
            </div>
            <div class="clear"></div>

            <label class="left">HireCraft User Level: </label>
            <div class="fixLength" runat="server">
                <asp:DropDownList ID="cmbTrainingUserType" runat="server" class="fixLength">
                    <asp:ListItem>Fresher</asp:ListItem>
                    <asp:ListItem>Intermediate</asp:ListItem>
                    <asp:ListItem>Expert</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="clear"></div>
            <label class="left">Notes: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="txtTrainingNotes" runat="server" class="fixLength"></asp:TextBox>
            </div>
            <div class="clear"></div>
         
            <div class="LoginBtn" runat="server">
                <asp:Button ID="btnSubmit" Text="Submit" runat="server" class="LogBtn" OnClick="btnSubmit_Click" />
                <asp:Button ID="btnReset" Text="Clear" runat="server" class="LogBtn" />
            </div>
               </div>
</asp:Panel>
            <div>
                <asp:Label ID="lblResult" runat="server" Text=""></asp:Label>
            </div>
            <div class="NoShow" runat="server">
                <asp:Label ID="trainingEmailTrainingTitle" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingNumber" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailTType" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailDateTime" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailDateTimeTill" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailTrainingLocation" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailTrainingVenue" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailTraineeName" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="trainingEmailTrainerName" runat="server" Text="Label"></asp:Label>
            </div> 
        </div>
   </asp:Content>