﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="UserProfile.aspx.cs" Inherits="UserProfile" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>
<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear" runat="server"></div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTeamMembers" runat="server">
    <div class="container" runat="server">
        <h1 class="lblTrnTitle">Personal Details<br />
        </h1>
        <hr style="height: 2pt; background-color: deepskyblue; border: 0;" />

        <div class="ddList" runat="server">
            <asp:Panel GroupingText="Your Profile Information" Style="height:600px; text-align: left;" runat="server" Font-Bold="True">
                
                <label class="left">Full Name: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileFullName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

                <label class="left">Gender: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileGen" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

                 <label class="left">Date Of Birth: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileDOB" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>
                <label class="left">Registered Date: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileRegDate" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>
                <label class="left">Working Details: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileWorkingDetails" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

            <label class="left">Joining Date: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileJoinDate" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

                <label class="left">Qualification Details: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileQualification" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

                <label class="left">Registered Mobile: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileEmail" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

                <label class="left">Registered Email: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileMobile" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear"></div>

                <label class="left">Last Updated On: </label>
            <div class="fixLength" runat="server">
                <asp:TextBox ID="profileUpdatedTime" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF"></asp:TextBox></div>
            <div class="clear" runat="server"></div>

                <label class="left">Areas of Interests: </label>
            <div class="fixLength" runat="server" style="height:auto;">
                <asp:TextBox id="profileUserAbout" runat="server" class="fixLength"  TextMode="MultiLine" Height="100px" MaxLength="500" Wrap="true" ></asp:TextBox>
                </div>
                            <div class="clear"></div>
<hr />
                <div class="clear"></div>
                <div runat="server" style="text-align:center">
                <asp:Button ID="btnSaveUserProfile" runat="server" class="LogBtn" Text="Update" OnClick="btnSaveUserProfile_Click" />
                    </div>
            </asp:Panel>
            <asp:Label ID="lblShowError" class="pcInfo" runat="server">
            </asp:Label>
        </div>
        <div class="clear" runat="server"></div>
        <br />
        <br />
    </div>
</asp:Content>
