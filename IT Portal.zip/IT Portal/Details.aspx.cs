﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;


public partial class Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
          //try
        {
            SqlConnection con = new SqlConnection(@"Data Source=IT-6\SQLEXPRESS;Initial Catalog=weblogin;Integrated Security=True;Pooling=False");  
                con.Open();  
                SqlCommand cmd = new SqlCommand("Insert into UserDes (Subject, Description)" + " values (@Subject, @Description)", con);
                cmd.Parameters.AddWithValue("@Subject",TextBox3.Text);  
                cmd.Parameters.AddWithValue("@Description", TextBox4.Text);  
                cmd.ExecuteNonQuery();                 
                cmd.Dispose();
            
                //ShowMessage("Registered successfully......!");               
                //clear();  
               // GridView1();  
            }  
           // catch (MySqlException ex)  
            //{  
              //  ShowMessage(ex.Message);  
           //}
        //Finally;  
          //  {  
        //con.Close();  
        Response.Write("SAVE");
        TextBox3.Text = null ;
        TextBox4.Text = null; 
        //mbox("SAVE");
       

        //gridview

            }

    
}

    


