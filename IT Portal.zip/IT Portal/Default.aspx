﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="Home" MasterPageFile="~/MasterPage.master" %>

<asp:Content ContentPlaceHolderID="MainHead" runat="server">
            <div class="HeadLogo" runat="server">
                <img src="images/logo.png" align="left" />
                <div class="welcomeUser" runat="server" id="welUname">
                    <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
                    <hr />                    <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
                </div>
            </div>
            <div class="clear">
            </div>
        </asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">

    <div class="clear" runat="server">
    </div>
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div class="clear" runat="server"></div>
       <div class="clear" runat="server"></div>
        <div class="homePage" runat="server">
            <asp:Image ID="Image1" runat="server"  ImageUrl="~/images/homepage.png"/>
            
        </div>
        <br />
                        <div class="Welcm">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Welcome to JVI-IT Online Portal</div>
        <div class="intro" runat="server">
            <asp:Image ID="logoImg" runat="server" ImageUrl="~/images/icon.png" Height="30"/>
<p>Jerry Varghese's IT operations are firmly determined to provide support and technical help to make users more convenience to use recruitment application softwares. 
    We conduct training on our HireCraft Software to build your confidence to use our applications.
            For us, Users are first priority and we welcome users feedback, doubts, queries and issue related to the system. <br />
    JVI-IT Team is always available for support/training to user via Online/Offline. 
            Trainings play an vital role in any organization. So, JVI-IT provides training to the his users and allow them to schedule training online/offline using this portal. 
            We provide quick support and avail online content which is available in download section.
    If you came across certain issues in HireCraft Application, You can report errors and complaints regarding to us. You can track status of your complaints in real time. 
        </p>
    <h3>Here you can perform following tasks.</h3>        
        
            <ol class="sessionInfo"  runat="server">
                    <li style="color:blue; font-weight:600;">Contact IT Team for any issue related to HireCraft.</li>
                    <li style="color:blue; font-weight:600;">Online Request for HireCraft Application Training.</li>
                    <li style="color:blue; font-weight:600;">Online Request for HireCraft Account Management.</li>
                    <li style="color:blue; font-weight:600;">Online Access to e-content on your fingertips.</li>
                <li style="color:blue; font-weight:600;">Online Track/Manage of all your requests.</li>
            </ol>
                    <hr />
                                <p>
           <b>For any query, please feel free to call us </b></p>
            <p>Email ID: support2@jvi-global.com / hardeepk@jvi-global.com </p>
            <p>Telephone : 022-67241624 / 022-61241649 </p>
            </div>
        </div>


</asp:Content>


