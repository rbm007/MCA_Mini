﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Report.aspx.cs" Inherits="Report" MasterPageFile="~/MasterPage.master" %>


<asp:Content ContentPlaceHolderID="MainHead" runat="server">
            <div class="HeadLogo" runat="server">
                <img src="images/logo.png" align="left" />
                <div class="welcomeUser" runat="server" id="welUname">
                    <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
                    <hr />                    <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
                </div>
            </div>
            <div class="clear">
            </div>
        </asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div id="Div1" class="container" runat="server">
    
    <p>List of Training</p>
    <p>HireCraft Traning</p>
    <p>List of error raise</p>
    <%--<p>add downlist on select option shown data from database in gridview</p>--%>
</div>
</asp:Content>

<%--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
    </div>
    </form>
</body>
</html>--%>