﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="NewUserRegistration.aspx.cs" Inherits="NewUserRegistration" MasterPageFile="~/MasterPage.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <script src="scripts/jquery-ui.js"></script>
    <script src="scripts/jquery-ui.min.js"></script>
    <script src="scripts/jquery.js"></script>
    <div class="clear" runat="server">
    </div>
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div class="clear" runat="server"></div>
        <div class="clear" runat="server"></div>
        <div class="lblTrnTitle" runat="server">
            <p>:HireCraft User Activation/De-Activation Request: </p>
        </div>
        <div class="clear"></div>
        <%-- Requester Details --%>
        <div class="NewUserCreationSuper" runat="server">
            <asp:Panel class="frmSet" runat="server" GroupingText="Your Details" Direction="LeftToRight" CssClass="frmSet" ForeColor="#0033CC" Font-Bold="True">
                <div class="clear" runat="server"></div>
                <div class="trainingBox" runat="server">
                    <label class="left">Full Name: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtNewUserCreationFullName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
                    </div>
                    <label class="left">User Name: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtNewUserCreationUserName" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
                    </div>
                    <label class="left">Email ID: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="txtNewUserCreationEmailID" runat="server" class="fixLength" ReadOnly="True" BackColor="#CCFFFF" />
                    </div>
                </div>
            </asp:Panel>
            <%-- Request Details --%>
            <div class="clear" runat="server"></div>
            <br />
            <asp:Panel class="frmSet" CssClass="frmSet" runat="server" GroupingText="User Information (All fields are mandatory)" Direction="LeftToRight" ForeColor="#000099" Font-Bold="True">
                <div class="clear"></div><br />
                <%-- New User Name --%>
                <div class="fieldRow" runat="server" id="nUserName">
                    <label class="left">Enter First Name:</label>
                    <asp:DropDownList ID="cmbNewUserGen" runat="server" class="cmbBox" AutoPostBack="false">
                        <asp:ListItem Selected="True">Mr.</asp:ListItem>
                        <asp:ListItem>Ms.</asp:ListItem>
                        <asp:ListItem>Mrs.</asp:ListItem>
                    </asp:DropDownList>
                    <asp:TextBox ID="txtNewUserFirstName" Width="293px" runat="server" class="txtBoxNewUser" ToolTip="Enter First Name"></asp:TextBox>
                </div>
                <div class="clear"></div>
                <%-- Middle & Last Name --%>
                <div class="fieldRow" runat="server" id="Div2">
                    <label class="left">Middle & Last Name:</label>
                    <asp:TextBox ID="txtNewUserMiddleName" runat="server" class="txtBoxNewUser" ToolTip="Enter Middle Name"></asp:TextBox>
                    <asp:TextBox ID="txtNewUserLastName" Width="200px" runat="server" class="txtBoxNewUser" ToolTip="Enter Last Name"></asp:TextBox>
                </div>
                <div class="clear"></div>
                <%-- Email Address --%>
                <div class="fieldRow" runat="server" id="Div1">
                    <label class="left">Email Address:</label>
                    <asp:TextBox ID="txtNewUserEmailAddress" Width="350px" runat="server" class="txtBoxNewUser" ToolTip="Enter Email Address"></asp:TextBox>
                </div>
                <div class="clear"></div>
                <%-- Phone Number--%>
                <div class="fieldRow" runat="server" id="Div3">
                    <label class="left">Phone Number:</label>
                    <asp:TextBox ID="txtNewUserPhoneNo" Width="350px" runat="server" class="txtBoxNewUser" ToolTip="Enter Phone Number"></asp:TextBox>
                </div>
                <div class="clear"></div>
                <%-- HC Login ID--%>
                <div class="fieldRow" runat="server" id="Div4">
                    <label class="left">HireCraft ID:</label>
                    <asp:TextBox ID="txtNewUserLoginHCId" Width="350px" runat="server" class="txtBoxNewUser" ToolTip="Enter HireCraft Login Name"></asp:TextBox>
                </div>
                <div class="clear" runat="server"></div>
                <%--Designation--%>
                <div class="fieldRow" runat="server" id="Div5">
                    <label class="left">Designation:</label>
                    <asp:TextBox ID="txtNewUserDesignation" Width="350px" runat="server" class="txtBoxNewUser" ToolTip="Enter HireCraft Login Name"></asp:TextBox>
                </div>
                <%--Location--%>
                <div class="clear" runat="server"></div>
                <div class="fieldRow" runat="server" id="Div6">
                    <label class="left">Location & Division:</label>
                    <asp:DropDownList ID="cmbNewUserLocation" runat="server" class="fixLength" Width="170">
                        <asp:ListItem Selected="True" Enabled="true">Mumbai</asp:ListItem>
                        <asp:ListItem>Dubai</asp:ListItem>
                        <asp:ListItem>Chennai</asp:ListItem>
                        <asp:ListItem>Bangalore</asp:ListItem>
                        <asp:ListItem>Hyderabad</asp:ListItem>
                        <asp:ListItem>Delhi</asp:ListItem>
                        <asp:ListItem>Cochin</asp:ListItem>
                        <asp:ListItem>Baroda</asp:ListItem>
                    </asp:DropDownList>
                    <asp:DropDownList ID="cmbNewUserDivision" runat="server" class="fixLength" Width="178px" Style="margin-left: 2px;">
                        <asp:ListItem Selected="True" Enabled="true">Select</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="clear"></div>
                <%--Team Name--%>
                <div class="fieldRow" runat="server" id="Div7">
                    <label class="left">Department & Team:</label>
                    <asp:DropDownList ID="cmbNewUserTeamName" runat="server" class="fixLength" Width="170px">
                        <asp:ListItem Selected="True" Enabled="true">Recruitment</asp:ListItem>
                        <asp:ListItem>VISA Processing</asp:ListItem>
                        <asp:ListItem>Data Entry Operator</asp:ListItem>
                    </asp:DropDownList>
                    <asp:DropDownList ID="cmbNewUserDeptName" runat="server" class="fixLength" Width="178px" Style="margin-left: 2px;">
                        <asp:ListItem Selected="True" Enabled="true">Oil & Gas</asp:ListItem>
                        <asp:ListItem>Power & Utility</asp:ListItem>
                        <asp:ListItem>Healthcare</asp:ListItem>
                        <asp:ListItem>Manufacturing</asp:ListItem>
                        <asp:ListItem>Projects</asp:ListItem>
                        <asp:ListItem>Petrochemical</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="clear" runat="server"></div>
                <%--Joining Date--%>
                <div class="fieldRow" runat="server">
                    <label class="left">Joining Date :</label>
                    <div class="fixLength" runat="server">
                        <cc1:CalendarExtender TargetControlID="txtNewuserDOJ" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy dddd" PopupPosition="TopRight"></cc1:CalendarExtender>
                        <asp:TextBox ID="txtNewuserDOJ" runat="server" Height="30"  CssClass="fixLength" ToolTip ="Enter Joining Date"/>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <%--HC Login Type--%>
                <div class="fieldRow" runat="server" id="Div9">
                    <label class="left">HireCraft Login:</label>
                    <div class="fixLength" runat="server">
                        <asp:DropDownList ID="cmbNewUserLoginOption" runat="server" class="fixLength">
                            <asp:ListItem Selected="True" Enabled="true">HireCraft New Login</asp:ListItem>
                            <asp:ListItem>Update Old Login</asp:ListItem>
                            <asp:ListItem>Replace Old Login</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <%--User Remarks--%>
                <div class="fieldRow" runat="server" id="Div10">
                    <label class="left">Enter Remarks:</label>
                    <textarea id="txtNewUserRemarks" class="fixLength" runat="server" style="height: 80px;" maxlength="300" dir="auto">
                    </textarea>
                </div>
                <div class="clear"></div>
            </asp:Panel>
            <div class="LoginBtn" runat="server">
                <asp:Button ID="btnSubmitNewUserRequest" Text="Submit" runat="server" class="LogBtn" OnClick="BtnSubmitNewUserRequest_Click" />
                <asp:Button ID="btnResetForm" Text="Clear" runat="server" class="LogBtn" />
            </div>
        </div>
        <div class="clear"></div>

        <div>
            <asp:Label ID="lblResult" runat="server" Text="" ForeColor="#FF3300" Font-Size="Small"></asp:Label>
        </div>
        <div class="NoShow" runat="server">

            <asp:Label ID="NWReqUserFullName" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWReqUserLogin" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWReqUserEmail" runat="server" Text=""></asp:Label>

            <asp:Label ID="NWReqNo" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWReqTitle" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWReqDate" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWReqType" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWEmpFullName" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWLocationOfWork" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWUserEmailAddress" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWHCID" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWHCNewOld" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWDesg" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWPhone" runat="server" Text=""></asp:Label>
            <asp:Label ID="NWRemarks" runat="server" Text=""></asp:Label>
        </div>
    </div>

    <script>
        $(function () {
            $('#txtNewuserDOJ').datetimepicker
            ({
                inline: true
            });
        })
    </script>
</asp:Content>
