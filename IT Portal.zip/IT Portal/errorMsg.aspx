﻿
<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="errorMsg.aspx.cs" Inherits="sessionGotExpired" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>
<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
        <div class="clear" runat="server"></div>
    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="MyMenu" runat="server"></asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTeamMembers" runat="server">
    <div class="ErrorContainer" runat="server">
        <h1 class="lblTrnTitle">Session has been expired.<br />
        </h1>
        <div class="clear" runat="server"></div>
        <br />
        <div class="ddList" runat="server">
            <img src="~/images/sessionExpired.jpg" style="height: 200px; width: 300px; align: centre;" runat="server" />
            <asp:Panel GroupingText="Session Expired Information" Style="height: 600px; text-align: left;" runat="server" Font-Bold="True">
                <h2 style="color: red;" runat="server">You need to re-login. You session has been suspended due to following:</h2>
                <div class="clear"></div>

                <ol class="sessionInfo" runat="server">
                    <li>Session has been expired to due a lack of acitivity.</li>
                    <li>You double clicked on button.</li>
                    <li>You may pressed Refresh button multiple times.</li>
                    <li>Our system encountered obstacle.</li>
                    <li>Page was on idle for long time.</li>
                </ol>
                <hr />

                <div class="clear"></div>
                <div runat="server" style="text-align: left">
                    <label runat="server">Click the Re-Login button to make login again </label>
                    <asp:Button ID="btnRelogin" runat="server" class="LogBtn" Text="Re-Login" OnClick="btnRelogin_Click" />
                </div>
            </asp:Panel>
            <asp:Label ID="lblShowError" class="pcInfo" runat="server">
            </asp:Label>
        </div>
        <div class="clear" runat="server"></div>
        <br />
        <br />
    </div>
</asp:Content>
