﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="doLogin.aspx.cs" Inherits="doLogin" %>

<%-- Add content controls here --%>


<asp:Content ID="mainLogin" ContentPlaceHolderID="pageDataContainer" runat="server">

    <div runat="server" class="ForgotLoginBox" id="loginRegion">


        <hr />
        <h2>Welcome to HR-Live Portal</h2>

    </div>

</asp:Content>