﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="alltraining.aspx.cs" Inherits="alltraining" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTrainingList" runat="server">
    <style type="text/css">
        .tableBackground {
            background-color: silver;
            opacity: 0.7;
        }
    </style>
    <div class="container" runat="server">
        <h1 class="lblTrnTitle">List of All Scheduled Training<br />
        </h1>
        <br />
        <div class="ScheduleTrainingData" runat="server">
            <div class="clear"></div>
                                <asp:GridView ID="ShowAllTrainingList" DataKeyNames="TrainingNumber" runat="server" CssClass="ScheduleTrainingData" AutoGenerateColumns="False" AlternatingItemStyle-HorizontalAlign="NotSet" AlternatingItemStyle-VerticalAlign="NotSet" AlternatingItemStyle-BorderStyle="None" AllowPaging="True" AllowSorting="True" BackColor="#DEBA84" HeaderStyle-BorderStyle="Ridge" HeaderStyle-Height="35" ItemStyle-HorizontalAlign="Left" PageSize="20" SelectedItemStyle-BackColor="#6600CC" HeaderStyle-ForeColor="White" HeaderStyle-BackColor="#990099" HeaderStyle-HorizontalAlign="Center" HeaderStyle-VerticalAlign="Middle" PagerSettings-Mode="Numeric" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="3" CellSpacing="2" EnableModelValidation="True">
                    <%--<asp:GridView ID="ShowAllTrainingList" runat="server" CssClass="ScheduleTrainingData" RowStyle-Height="30" HeaderStyle-Height="40" HeaderStyle-ForeColor="#CCFFFF" HeaderStyle-BackColor="#003300">--%>



                    <Columns>
                        <asp:TemplateField HeaderText="Select">
                            <ItemTemplate>
                                <input name="tr" id="btnOpenUpdateWindow" type="radio" value='<%# Eval("TrainingNumber") %>' />
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="TrainingNumber" HeaderText="Training Number" />
                        <asp:BoundField DataField="TrainingDate" HeaderText="Training Date" />
                        <asp:BoundField DataField="TrainingType" HeaderText="Training Type" />
                        <asp:BoundField DataField="ScheduledOn" HeaderText="Training Schedule Date" />
                        <asp:BoundField DataField="TrainingLocation" HeaderText="Training Location" />
                    </Columns>
                    <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />

                    <HeaderStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#A55129" BorderStyle="Ridge" ForeColor="White" Height="35px" Font-Bold="True"></HeaderStyle>
                    <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                    <RowStyle BackColor="#FFF7E7" ForeColor="#8C4510" />
                    <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" ForeColor="White" />
                </asp:GridView>

            <div class="TrainingUpdateBtn" runat="server">
                    <asp:Button ID="btnUpdateTrainingInfo" CssClass="LogBtn" Text="Update Training" runat="server" AutoPostBack="false" OnClick="btnUpdateTrainingInfo_Click" />
                    </div>
                <cc1:ModalPopupExtender BehaviorID="forgotPwd" ID="trainingUpdatorBox" runat="server"
                    PopupControlID="updatePanel" TargetControlID="btnUpdateTrainingInfo" CancelControlID="btnLginAgain"
                    BackgroundCssClass="ForgotLoginBox">
                </cc1:ModalPopupExtender>
                <asp:Panel ID="updatePanel" runat="server" BackColor="White" Height="600px" Width="60%" Style="display: block">
                    <div class="WelcomeForgotPanel" runat="server">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Update Training Details</div>
                    <div class="clear" runat="server"></div>
                    <div class="forgotPanelControlContainer" runat="server">
                        <div class="ForgotLoginRow" runat="server">

                            <asp:Label Text="Enter User name* " runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" runat="server" ID="txtTrainingNumber" AutoPostBack="false"></asp:TextBox>
                        </div>
                        <div class="clear" runat="server"></div>
                        <div class="ForgotLoginRow" runat="server">

                            <asp:Label Text="Registered Email Address *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" runat="server" ID="txtTrainingDate" AutoPostBack="false"></asp:TextBox>
                        </div>
                        <div class="clear" runat="server"></div>
                        <div class="ForgotLoginRow" runat="server">
                            <asp:Label Text="Registered Mobile Number *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" ID="txtTrainingType" runat="server" AutoPostBack="false" AutoCompleteType="HomePhone"></asp:TextBox>
                            <div class="clear" runat="server"></div>
                        </div>
                        <div class="clear" runat="server"></div>
                        <div class="ForgotLoginRow" runat="server">
                            <asp:Label Text="Registered Mobile Number *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" ID="txtTraingScheduleDate" runat="server" AutoPostBack="false" AutoCompleteType="HomePhone"></asp:TextBox>
                            <div class="clear" runat="server"></div></div>

                         <div class="clear" runat="server"></div>
                        <div class="ForgotLoginRow" runat="server">
                            <asp:Label Text="Registered Mobile Number *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" ID="txtTraingLocation" runat="server" AutoPostBack="false" AutoCompleteType="HomePhone"></asp:TextBox>
                            <div class="clear" runat="server"></div></div>

                        <hr style="height: 2px; background-color: deepskyblue; width: 100%; border: none;" />
                        <div class="ForgotPwdLoginBtn" runat="server">
                        <asp:Button ID="btnUpdateTrainingData" CssClass="LogBtn" runat="server" Text="Update" />
                            <asp:Button ID="btnCancelUpdateTraining" CssClass="LogBtn" runat="server" Text="Update" />
                        </div>
                        <div class="clear" runat="server"></div>

                        <p class="pcInfo" id="pcData" runat="server"></p>
                        <asp:Label ID="pnError" runat="server"></asp:Label>
                    </div>
                </asp:Panel>

            </div>
           
    <div class="clear"></div>
    <hr>
    <br />
    <asp:Label ID="errmsg" runat="server" Text="" BackColor="Yellow" ForeColor="Red" Font-Size="Small">
    </asp:Label>
    </div>
    <script type="text/javascript">
        var launch = false;
        function launchModal() {
            launch = true;
        }
    </script>
    <script>
        function pageLoad() {
            if (launch) {
                $find("trainingUpdatorBox").show();
            }
        }
    </script>

</asp:Content>
