﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;
using System.Drawing;
using AjaxControlToolkit;

public partial class loginHistory : System.Web.UI.Page
{

    con_properties logCon = new con_properties();
    SqlDataAdapter adap;
    DataSet ds;


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
            ShowLoginLog();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("Login.aspx");
        }

    }


    public void ShowLoginLog()
    {
        try
        {


            //string selectTrainings = "Select * from UserTraining with(nolock) Where ELoginName=@a";

            string selectTrainings = "Select ROW_NUMBER() OVER(ORDER BY LoginDateTime DESC) AS SrNo, Format(LoginDateTime, 'dddd, dd-MMM-yyyy hh:mm:ss tt')as 'Logged On', isnull(Upper(PC_Name),'')as 'Computer Name',"
            + "BrowserName As 'Internet Browser Name' from UserLoginLog with(nolock) WHERE ELoginName=@ac";

            adap = new SqlDataAdapter(selectTrainings, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adap.SelectCommand.Parameters.AddWithValue("@ac", Session["ELoginName"].ToString());
            ds = new DataSet();
            logCon.con_open();
            adap.Fill(ds, "UserLoginLog");
            logCon.close_con();

            if (ds.Tables["UserLoginLog"].Rows.Count > 0)
            {
                GrdLoginLoader.DataSource = ds.Tables["UserLoginLog"];
                GrdLoginLoader.DataBind();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Log Not Found')</script>");

            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Connection to server has been failed.')</script>");
            errmsg.Text = ex.ToString();
        }
    }



}