﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;
using System.Drawing;
using AjaxControlToolkit;

public partial class newGRList : System.Web.UI.Page
{

    con_properties GRList = new con_properties();
    SqlDataAdapter adap;
    DataSet ds;


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
            ShowUserGrevienceDetails();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("errorMsg.aspx");
        }

    }


    public void ShowUserGrevienceDetails()
    {
        try
        {


            //string selectTrainings = "Select * from UserTraining with(nolock) Where ELoginName=@a";

            string selectGrevience= "Select ROW_NUMBER() OVER(ORDER BY ID ASC) AS 'Sr. No.','Issue In ' + GrCategory + ' ( ' + GrType + ' )' As 'Subject',"
+"Format(GrLoggedInDate, 'dd-MMM-yyyy hh:mm:ss tt') as RequestedDate, EloginName AS UserName,GrPriority as Priority, GrRequestedUser as UserFullName,"
+"GrAltContact as 'Alternate Contact',GrRequestedUserEmail As 'Email ID', GrIssueFrom as IssueFrom, GrDesc AS Description,"
+"GrStatus as Status from UserGreviences with(nolock)Where EloginName = @grLogin order by GrLoggedInDate desc";


            //    "Select ROW_NUMBER() OVER(ORDER BY id ASC) AS SrNo,isnull(Upper(HC_USERS.FirstName),'')as FirstName,"
            //+"HC_USERS.JobTitle As 'Job Title',HCD.DivisionTitle + ' ( ' + HCL.LocationTitle + ' )' as 'Location', HCT.TeamTitle As Department,"
            //+"lower(HC_USERS.EmailID) As Email,HC_USERS.Mobile from HC_USERS with(nolock) Join HCM_LOCATIONS HCL ON HC_USERS.LocationID=HCL.RID "
            //+ "Join HCM_DIVISIONS HCD On HC_USERS.DivisionID=HCD.RID Join HCM_Team HCT On HC_USERS.TeamID=HCT.RID  Where HC_USERS.Status=0 order by HC_USERS.UserName asc;";

            adap = new SqlDataAdapter(selectGrevience, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adap.SelectCommand.Parameters.AddWithValue("@grLogin", Session["ELoginName"].ToString());
            ds = new DataSet();
            GRList.con_open();
            adap.Fill(ds, "UserGreviences");
            GRList.close_con();
            if (ds.Tables["UserGreviences"].Rows.Count > 0)
            {
                ShowAllGrevienceList.DataSource = ds.Tables["UserGreviences"];
                ShowAllGrevienceList.DataBind();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('No Grevience found')</script>");

            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Connection to server has been failed.')</script>");
            errmsg.Text = ex.ToString();
        }
    }



}