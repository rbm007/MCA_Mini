﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="ContactUs.aspx.cs" Inherits="ContactUs" %>


<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
                <img src="images/logo.png" align="left" />
                <div class="welcomeUser" runat="server" id="welUname">
                    <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
                    <hr />                    <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
                </div>
            </div>
            <div class="clear">
            </div>
</asp:Content>

<asp:Content ID="headerArea" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="clear"></div>
    <div class="ContactUsContainer" runat="server">
        <div class="clear"></div>
        <div class="desc" runat="server">
            <div class="lblTrnTitle">
                <p>We are happy to help you :) </p>
            </div>
            <div class="clear"></div>
            <div class="ConImg">
                <img src="images/contact-us.png" height="70" width="300" />
            </div>
            <div>
                <h1 class="ConHead" runat="server">Contact Us</h1>
            </div>
            
            <div class="clear"></div>
            <hr />
<div class="conUs" runat="server">
            <div class="contactUsInfo" runat="server">
                <p><b>We are happy to answer your calls, Emails and Feedbacks. <br />Please write us on below contact details.</b></p>
                <hr />
                <h2>Contact Details : 1</h2>
                <table class="MyTable" border="1" cellspacing="4" rowspacing="6" cellpadding="5" rowpadding="0" bordercolor="Blue">
                    <tr><th>Contact Name</th><th>:</th><td>Mr. Ram B Mishra ( IT Executive )</td></tr>
                    <tr><th>Tele Phone</th><th>:</th><td>+91 22 6724 1624</td></tr>
                    <tr><th>Email ID</th><th>:</th><td>support2@jvi-global.com</td></tr>
                    <tr><th>Skype ID</th><th>:</th><td>jvi_training</td></tr>
                    <tr><th>Mobile No.</th><th>:</th><td>+91 797 726 1158</td></tr>
                    <tr><th>Office Address</th><th>:</th><td>Jerry Varghese Executive Search Services 6th floor,'A' Wing,<br>Gundecha Onclave, Khairani Road,
                Saki-Naka,<br />Andheri (E), Mumbai - 400 072</td></tr>
                </table>

                <h2>Contact Details : 2</h2>
                <table class="MyTable" border="1" cellspacing="4" rowspacing="6" cellpadding="5" rowpadding="0" bordercolor="Blue">
                    <tr><th>Contact Name</th><th>:</th><td>Ms. Hardeep Kaur( IT Programmer )</td></tr>
                    <tr><th>Tele Phone</th><th>:</th><td>+91 22 6724 1649</td></tr>
                    <tr><th>Email ID</th><th>:</th><td>hardeepk@jvi-global.com</td></tr>
                    <tr><th>Skype ID</th><th>:</th><td>hardeep_jvi kaur</td></tr>
                    <tr><th>Mobile No.</th><th>:</th><td>+91 22 6724 1600</td></tr>
                    <tr><th>Office Address</th><th>:</th><td>Jerry Varghese Executive Search Services 6th floor,'A' Wing,<br />Gundecha Onclave, Khairani Road,
                Saki-Naka,<br />Andheri (E), Mumbai - 400 072</td></tr>

                </table>
                <h2>Contact Details : 3</h2>
                <table class="MyTable" border="1" cellspacing="4" rowspacing="6" cellpadding="5" rowpadding="0" bordercolor="Blue">
                    <tr><th>Contact Name</th><th>:</th><td>Mr. Appaso Katkar( IT Administrator )</td></tr>
                    <tr><th>Tele Phone</th><th>:</th><td>+91 22 6724 1668</td></tr>
                    <tr><th>Email ID</th><th>:</th><td>support1@jvi-global.com</td></tr>
                    <tr><th>Skype ID</th><th>:</th><td>appaso_jvi</td></tr>
                    <tr><th>Mobile No.</th><th>:</th><td>+91 9833052838</td></tr>
                    <tr><th>Office Address</th><th>:</th><td>Jerry Varghese Executive Search Services 6th floor,'A' Wing,<br />Gundecha Onclave, Khairani Road,
                Saki-Naka,<br />Andheri (E), Mumbai - 400 072</td></tr>

                </table>

                <h2>Contact Details : 4</h2>
                <table class="MyTable" border="1" cellspacing="4" rowspacing="6" cellpadding="5" rowpadding="0" bordercolor="Blue">
                    <tr><th>Contact Name</th><th>:</th><td>Mr. Jesu D (EDP Supervisor (JVIT-Powai))</td></tr>
                    <tr><th>Tele Phone</th><th>:</th><td>+ 91 22 67341750</td></tr>
                    <tr><th>Email ID</th><th>:</th><td>support@jvi-global.com</td></tr>
                    <tr><th>Skype ID</th><th>:</th><td>jesu23dec</td></tr>
                    <tr><th>Mobile No.</th><th>:</th><td>+91 9920427763</td></tr>
                    <tr><th>Office Address</th><th>:</th><td>Jerry Varghese International Ltd.<br />206 Gateway Plaza, Hiranandani Gardens, Powai,<br /> Mumbai - 400 076.
</td></tr>
                </table>
            </div>
            <%--<div class="contactUsLogo" runat="server">
                <img src="images/icon.jpg" height="270" width="200" />
            </div>--%>
        </div>
            </div>
    </div>
</asp:Content>
