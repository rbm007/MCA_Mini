﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="trainingVideos.aspx.cs" Inherits="trainingVideos" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>

<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear" runat="server"></div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTeamMembers" runat="server">
    <div class="container" runat="server">
        <h1 class="lblTrnTitle">Training Videos<br />
        </h1>
        <hr style="height: 2pt; background-color: deepskyblue; border: 0;" />
        <div class="ContactData" runat="server">
            <asp:Panel GroupingText="Useful Videos" runat="server" Font-Bold="True">
                <object width="300" height="300" data="https://www.youtube.com/embed/JvvDTuosJyY" title="Write Professional Emails"></object>
                <object width="300" height="300" data="https://www.youtube.com/embed/sErI3d2E4P4"></object>
                <object width="300" height="300" data="https://www.youtube.com/embed/dKzl_82PbU4"></object>
                <object width="300" height="300" data="https://www.youtube.com/embed/TD884Dl-kLc"></object>
                <object width="300" height="300" data="https://www.youtube.com/embed/DHDrj0_bMQ0"></object>
                <object width="300" height="300" data="https://www.youtube.com/embed/h01GcsTeHpc"></object>
            </asp:Panel>
        </div>
    </div>
</asp:Content>
