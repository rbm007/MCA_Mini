﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Details.aspx.cs" Inherits="Details" %>--%>
<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Details.aspx.cs" Inherits="Details"%>

 
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Untitled Page</title>
    <style type="text/css">
        .style1
        {
            width: 412px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        </div>
        <div align=center><img src="images/logo.png" />
</div>
        
        <div></div>
        <div style="height: 90px; width: 973px">
        
        <panel>
                    <table style="width:100%;">  
                  
                <tr>  
                    <td class="style1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Messages</strong></td>  
                    <td>  
 </td>  
                    <td>  
 </td>  
                </tr>  
                <tr>  
                    <td align=left>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
Subject:</td>  
                    <td>  
                        <asp:TextBox ID="TextBox3" runat="server" 
                            style="margin-left: 0px; width: 128px;" Width="298px"></asp:TextBox>  
                    </td>  
                    <td>  
                        &nbsp;</td>  
                </tr>  
                <tr>  
                    <td class="style1">  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
Description:</td>  
                    <td>  
                        <asp:TextBox ID="TextBox4" runat="server" Height="109px" Width="343px" ></asp:TextBox>  
                    </td>  
                    <td>  
                          
                    </td>  
                </tr>  
                <tr>  
                    <td class="style1">  
 </td>  
                    <td>  
                        &nbsp;</td>  
                    <td>  
 </td>  
                </tr>  
                <tr>  
                    <td class="style1">  
 </td>  
                    <td>  
                       <asp:Button ID="Button2" runat="server" Text="Submit" onclick="Button2_Click" /><br />
                    </td>  
                    <td>  
                        
                    </td>  
                </tr>  
            </table>
            </panel>
        </div>
        <div style="height: 90px; width: 973px">
        
            <%--<asp:GridView ID="GridView1" runat="server" 
                onselectedindexchanged="GridView1_SelectedIndexChanged">
            </asp:GridView>--%>
        
        </div>
        
            <p>  
 </p>  
            <p>  
                <asp:Label ID="Label1" runat="server"></asp:Label>  
            </p>  
            <p>  
                <%--<asp:Button ID="Button1" runat="server" Height="47px" onclick="Button1_Click" Text="Logout" Width="92px" />  --%>
                
            </p> 
            <panel>
            <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="false" AllowPaging="true"
    PageSize="10">
    <%--OnPageIndexChanging="OnPageIndexChanging" PageSize="10">--%>
    <Columns>
        <asp:BoundField ItemStyle-Width="150px" DataField="Username" HeaderText="Username"/>
        <asp:BoundField ItemStyle-Width="150px" DataField="subject" HeaderText="Subject"/>
        <asp:BoundField ItemStyle-Width="150px" DataField="despcrition" HeaderText="Despcrition"/>
        <asp:BoundField ItemStyle-Width="150px" DataField="status" HeaderText="Status"/>
    </Columns>
</asp:GridView>
            </panel> 
            <div>
            </div>
            <div align=center>
             <p>Jerry Varghese International Ltd. All rights reserved.</p>
</div>
    </form>
</body>
</html>
