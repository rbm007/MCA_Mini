﻿<%@ Page Language="C#" AutoEventWireup="true" MasterPageFile="~/MasterPage.master" CodeFile="Login.aspx.cs" Inherits="Login" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<asp:Content ContentPlaceHolderID="MyMenu" runat="server"></asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="wrapper" runat="server">
        <div class="container" runat="server">
            <div class="clear" runat="server"></div>
            <div class="loginBox" runat="server">
                <div class="Welcm" runat="server">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Welcome!</div>
                <div class="clear" runat="server"></div>
                                <div class="clear"> </div>
                <div id="uname" class="loginRow" runat="server">
                    <asp:Label Text="Username *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                    <asp:TextBox ID="txtUserName" CssClass="txtBoxLogin" runat="server" onpaste="return false;" />
                </div>
                <div id="Div2" class="clear" runat="server"></div>
                <div id="Div1" class="loginRow" runat="server">
                    <asp:Label ID="Label2" Text="Password *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                    <asp:TextBox ID="txtPWD" CssClass="txtBoxLogin" runat="server" TextMode="Password" onpaste="return false;" />
                </div>
                <div class="clear" runat="server">
                    <asp:Label ID="lblError" runat="server" ForeColor="Red"></asp:Label>
                    <asp:Label ID="UFullName" runat="server" Visible="false"></asp:Label>
                </div>
                <div class="clear"></div>
                <hr style="height: 2px; background-color: deepskyblue; width: 100%; border: none;" />
                <div class="LoginBtn" runat="server">
                    <asp:Button ID="btnLogin" Text="Login" runat="server" class="LogBtn" OnClick="btnLogin_Click" />&nbsp;
                    <asp:Button ID="btnReset" Text="Clear" runat="server" class="LogBtn" OnClick="btnReset_Click" />
                </div>
                <div class="clear"></div>
                <hr style="height: 2px; background-color: deepskyblue; width: 100%; border: none;" />
                <div id="Div3" class="ForgotPWDloginRow" runat="server">
                    <asp:LinkButton ID="lblForgot" runat="server" OnClick="lblForgot_Click" PostBackUrl="~/Login.aspx">Forgot Password</asp:LinkButton>
                    <asp:LinkButton ID="lblLogAssist" runat="server">Login Assistant</asp:LinkButton>
                </div>
        </div>
        <%-- Popup Window Starts --%>
        <cc1:ModalPopupExtender BehaviorID="forgotPwd" ID="forgotPwd" runat="server"
            PopupControlID="forgotPwdPanel" TargetControlID="lblForgot" CancelControlID="btnLginAgain"
            BackgroundCssClass="ForgotLoginBox">
        </cc1:ModalPopupExtender>
        <asp:Panel ID="forgotPwdPanel" align="center" runat="server" Style="display: none; min-width: 40%; width: auto;" class="ForgotLoginBox" GroupingText="Recover your password" HorizontalAlign="Center" Font-Size="Medium" Font-Bold="True" ForeColor="DeepSkyBlue">

            <div class="WelcomeForgotPanel" runat="server">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login Assistant Manager</div>
            <div class="clear" runat="server"></div>
            <div class="forgotPanelControlContainer" runat="server">
                <div class="ForgotLoginRow" runat="server">

                    <asp:Label Text="Enter User name* " runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" runat="server" ID="forgotUserName" AutoPostBack="false"></asp:TextBox>
                </div>
                <div class="clear" runat="server"></div>
                <div class="ForgotLoginRow" runat="server">

                    <asp:Label Text="Registered Email Address *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" runat="server" ID="forgotEmailAddress" AutoPostBack="false"></asp:TextBox>
                </div>
                <div class="clear" runat="server"></div>
                <div class="ForgotLoginRow" runat="server">
                    <asp:Label Text="Registered Mobile Number *" runat="server" Class="lblData"></asp:Label>&nbsp;&nbsp;&nbsp;
                            <asp:TextBox CssClass="txtBoxLogin" ID="forgotPwdMobile" runat="server" AutoPostBack="false" AutoCompleteType="HomePhone"></asp:TextBox>
                    <div class="clear" runat="server"></div>
                </div>
                <hr style="height: 2px; background-color: deepskyblue; width: 100%; border: none;" />


                <div class="ForgotPwdLoginBtn" runat="server">
                    <asp:Button ID="btnSubmitRetrievePWD" CssClass="LogBtn" Text="Get Password" runat="server" AutoPostBack="false" OnClick="btnSubmitRetrievePWD_Click" />
                    <asp:Button ID="btnLginAgain" CssClass="LogBtn" runat="server" Text="Login" OnClick="btnLginAgain_Click" PostBackUrl="~/Login.aspx" />
                </div>
                <div class="clear" runat="server"></div>

                <p class="pcInfo" id="pcData" runat="server"></p>
                <asp:Label ID="pnError" runat="server"></asp:Label>
            </div>

        </asp:Panel>
        <asp:Label ID="Label1" runat="server" Font-Names="Verdana" Font-Size="Small" ForeColor="Red"></asp:Label>

        <%-- Pop Window End Here --%>
        <div class="clear"></div>
        <br />
        <div style="height: auto; width: auto; padding: 5pt;">
            <h2 align="left" style="background-color: deepskyblue; padding: 7pt; color: white;">Your System Details</h2>
            <asp:Label ID="ipAddress" runat="server" CssClass="pcInfo"></asp:Label>
            <h3>
                <asp:Label ID="lblIP" runat="server"></asp:Label></h3>
            <asp:Label ID="lblUName" runat="server"></asp:Label>
        </div>
    </div>
    </div>
    <div runat="server" visible="false">
        <asp:Label ID="forName" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forEmail" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forPass" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forMobile" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forUName" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="ForDateTime" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forFirstName" Visible="false" runat="server"></asp:Label>
    </div>
</asp:Content>
