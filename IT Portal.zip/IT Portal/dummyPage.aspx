﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="dummyPage.aspx.cs" Inherits="dummyPage" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ContactUsContainer" runat="server">
        <asp:Button ID="ClientButton" runat="server" Text="Launch Modal Popup (Client)" />
           
    <asp:Panel ID="ModalPanel" runat="server" Width="500px">
 ASP.NET AJAX is a free framework for quickly creating a new generation of more 
 efficient, more interactive and highly-personalized Web experiences that work 
 across all the most popular browsers.<br />
 <asp:Button ID="OKButton" runat="server" Text="Close" />
</asp:Panel>
    <asp:Button ID="ServerButton" runat="server" Text="Launch Modal Popup (Server)"  OnClick="ServerButton_Click" />
    <cc1:ModalPopupExtender ID="mpe" runat="server" TargetControlId="ClientButton"  PopupControlID="ModalPanel" OkControlID="OKButton" />

    </div>
    <script type="text/javascript">
        var launch = false;
        function launchModal() 
        {
            launch = true;
        }
        </script>
<script>
   function pageLoad() 
 {
 if (launch) 
 {
 $find("mpe").show();
 }
 }
</script>

</asp:Content>