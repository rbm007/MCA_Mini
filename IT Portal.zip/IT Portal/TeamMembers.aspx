﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="TeamMembers.aspx.cs" Inherits="TeamMembers" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>



<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear" runat="server">    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTeamMembers" runat="server">
   <div class="container" runat="server">
        <h1 class="lblTrnTitle">Meet the JVI - IT Team<br />
        </h1>
        <br />
        <p class="desc">
            We are individuals with different skills, passions, and cultures.We are dedicated team players who bring energy, 
            ideas and pride to our work. Our team aim is provide full support and help wherever you required. 
            JVI-IT is comprised of ultra-talented and experienced designers, developers and programmers. 
            <br />
            Learn more about each person by reading their descriptions below:
        </p>
    <div class="TeamMembers" runat="server" id="teamDes">
        <h2>Our Team Members</h2>
        <hr style="height:2pt; background-color:deepskyblue; border:0;" />
        <div class="aboutMember" runat="server">
            <img src="images/rampic.jpg" alt="Ram B Mishra" height="160px" class="imgPic">
            <b>Mr. Ram B. Mishra<br />IT Executive</b><br />
            He is IT Executive. He has good knowledge of DataBase, Programming and Application Designing. He is post graduated in Computer Application and good exeprience in IT field.
                He takes care of HireCraft Application, Support Users, Provides Training to the users.Responsible for Overall changes, developement and implementation of HireCraft Software.
                His main area of intrests are Computer Application, DataBase Administration, Cloud Computing and Application Development.<br />
            <div class="clear" runat="server"></div>
            <br />
            <hr style="height:1pt; background-color:deepskyblue; border:0;" />
            <br />
            <img src="images/ak.png" alt="Katkar" height="160px" class="imgPic">
            <b>Mr. Appaso Katkar<br />
                IT Administrator</b><br />

            He is Hardware Engineer. He has good knowledge of Computer Troubleshooting, PC Maintenance And Networking. He is graduated in IT and good exeprience in Hardware & Networking.
                He takes care of PC, Mail Services and DataBase Activity, Support Users. Responsible for Overall changes in HardWare.
            His main area of intrests are Computer Networking, IT Administration.
                <br />
              <div class="clear" runat="server"></div>
            <br />
            <hr style="height:1pt; background-color:deepskyblue; border:0;" />
            <br />
            
            <img src="images/hardeep.jpg" alt="Hardeep Kaur" height="160px" class="imgPic">
            <b>Ms. Hardeep Kaur<br />IT Programmer</b><br />
            She is IT Programmer. She has good knowledge of Programming and Designing of Web Sites. She is post graduated in Computer Application.
                SHe takes care of Our <a href="http://www.jerryvarghese.com/home-page/index.aspx" target="jviPortal">Jerry Varghese Portal</a> Support Users and Candidates.
                            Her main area of intrests are Web Designing, Application Developement.<br />
            <div class="clear" runat="server"></div>
            <br />
        </div>
    </div>
    </div>
</asp:Content>
