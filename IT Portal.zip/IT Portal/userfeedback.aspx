﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="userfeedback.aspx.cs" Inherits="userfeedback" %>


<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>

<asp:Content ID="headerArea" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="clear"></div>
    <div class="ContactUsContainer" runat="server">
        <div class="clear"></div>
        <div class="lblTrnTitle">
            <p>Your feedback is Important for us</p>
        </div>
        <div class="clear"></div>
        <div class="clear" runat="server"></div>
        <hr />
        <br />
        <asp:Panel runat="server" class="frmSet" GroupingText="Enter Feedback details here" ForeColor="#000099" Font-Bold="True">
            <div class="trainingBox" runat="server">
                <%-- Feedback Provider Details --%>
                <div runat="server" class="feedRow">
                    <label class="left">Full Name:</label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="lblFBUserFullName" runat="server" CssClass="fixLength" ReadOnly="true" BackColor="LightGray"></asp:TextBox>
                    </div>
                </div>
                <div runat="server" class="feedRow">
                    <label class="left">Email Address:</label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="lblFeedBackEmail" runat="server" CssClass="fixLength" ReadOnly="true" BackColor="LightGray"></asp:TextBox>
                    </div>
                </div>

                <div runat="server" class="feedRow">
                    <label class="left">User ID:</label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="lblFBUserName" runat="server" CssClass="fixLength" ReadOnly="true" BackColor="LightGray"></asp:TextBox>
                    </div>
                </div>

                <div runat="server" class="feedRow">
                    <label class="left">Location: </label>
                    <div class="fixLength" runat="server">
                        <asp:TextBox ID="lblFeedbackLocDept" runat="server" CssClass="fixLength" ReadOnly="true" BackColor="LightGray"></asp:TextBox>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <div class="feedRow" runat="server" id="Div3">
                    <label class="left">Feedback about: </label>
                    <div class="fixLength" runat="server">
                        <asp:DropDownList ID="cmbFeedbackType" runat="server" class="fixLength">
                            <asp:ListItem Text="Training" Selected="True"></asp:ListItem>
                            <asp:ListItem Text="Support"></asp:ListItem>
                            <asp:ListItem Text="System Audit"></asp:ListItem>
                            <asp:ListItem Text="IT Team"></asp:ListItem>
                            <asp:ListItem Text="HireCraft"></asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>

                <div class="clear" runat="server"></div>

                <div class="feedRow" runat="server" id="Div1">
                    <label class="left">Ratings: </label>
                    <div class="fixLength" runat="server">
                        <asp:DropDownList ID="cmbUserFeedbackRating" runat="server" class="fixLength">
                            <asp:ListItem Text="1-Very Poor" Selected="True"></asp:ListItem>
                            <asp:ListItem Text="2-Poor"></asp:ListItem>
                            <asp:ListItem Text="3-Average"></asp:ListItem>
                            <asp:ListItem Text="4-Good"></asp:ListItem>
                            <asp:ListItem Text="5-Very Good"></asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <div class="feedRow" runat="server" id="Div2">
                    <label class="left">Write Comments: </label>
                    <div class="fixLength" runat="server" style="height: auto;">
                        <asp:TextBox ID="txtUserFeedbackComments" runat="server" class="fixLength" TextMode="MultiLine" Height="200px" MaxLength="2000" Wrap="true"></asp:TextBox>
                    </div>
                </div>
                <div class="clear" runat="server"></div>
                <hr />
                <div runat="server" style="text-align: center">
                    <asp:Button ID="btnSaveUserFeedback" runat="server" class="LogBtn" Text="Submit" OnClick="btnSaveUserFeedback_Click" />
                </div>
            </div>
        </asp:Panel>
    </div>
    <div>
        <asp:Label ID="lblResult" runat="server" Text="" ForeColor="#FF3300" Font-Size="Small"></asp:Label>
    </div>
    <div class="NoShow" runat="server">
                <asp:Label ID="FBNumber" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="FBUserEmail" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="FBType" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="FBDateTime" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="FBRatings" runat="server" Text="Label"></asp:Label>
                <asp:Label ID="FBComments" runat="server" Text="Label"></asp:Label>
            </div>
</asp:Content>
