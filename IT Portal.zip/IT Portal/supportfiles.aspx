﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="supportfiles.aspx.cs" Inherits="supportfiles" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>



<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear" runat="server"></div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTeamMembers" runat="server">
    <div class="container" runat="server">
        <h1 class="lblTrnTitle">Important Download for Users<br />
        </h1>
        <hr style="height: 2pt; background-color: deepskyblue; border: 0;" />

        <div class="ddList" runat="server">
            <asp:Panel GroupingText="Utilities Downloads" Style="text-align: left;" runat="server" Font-Bold="True">
                <li><a href="https://download.teamviewer.com/download/TeamViewerQS.exe" target="TV">Team Viewer Quick Support</a></li>
                <li><a href="https://drive.google.com/open?id=12UmpkNqTzTE9sDoZLg18vspZ5Ef0JWem" target="HCManual">Ammyy Admin 3.6</a></li>
                <li><a href="https://anydesk.com/download" target="HCManual">AnyDesk Remote Application</a></li>
                <li><a href="https://www.skype.com/en/download-skype/skype-for-windows/downloading/" target="HCManual">Skype Online Calling</a></li>
            </asp:Panel>
        </div>
        <div class="clear" runat="server"></div>
        <br />
        <br />
    </div>
</asp:Content>
