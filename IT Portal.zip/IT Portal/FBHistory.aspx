﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="FBHistory.aspx.cs" Inherits="FBHistory" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>
<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTrainingList" runat="server">
    <div class="container" runat="server">
        <h1 class="lblTrnTitle">Your FeedBacks History<br />
        </h1>
        <br />
        <div class="ContactData" runat="server">

            <asp:GridView ID="ShowFBList" runat="server" class="ContactData" RowStyle-Height="30" HeaderStyle-Height="40" HeaderStyle-ForeColor="#CCFFFF" HeaderStyle-BackColor="#003300" PageIndex="2" PagerSettings-Mode="NextPreviousFirstLast" PagerSettings-Position="TopAndBottom" PagerStyle-HorizontalAlign="NotSet" Height="300">
            </asp:GridView>
        </div>
        <br />
        <asp:Label ID="errmsg" runat="server" Text="" BackColor="Yellow" ForeColor="Red" Font-Size="Small">
        </asp:Label>
    </div>
</asp:Content>
