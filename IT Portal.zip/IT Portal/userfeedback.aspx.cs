﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;

public partial class userfeedback : System.Web.UI.Page
{
    con_properties newFeed = new con_properties();
    SqlDataAdapter adp;
    DataSet ds;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            loadFeedbackUserDetails();
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("errorMsg.aspx");
        }
    }
    public void loadFeedbackUserDetails()
    {
        try
        {
            string selectDt = "SELECT EEmail,ELoginName as UserNm, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName As EmpFullName," +
                "EDept + ' ' + EDiv +  ' [ ' + Elocation + ' ]' As EmpLocation From JVIEmp with(nolock) Where ELoginName=@eFeed";
            SqlDataAdapter adp = new SqlDataAdapter(selectDt, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
            adp.SelectCommand.Parameters.AddWithValue("@eFeed", Session["ELoginName"].ToString());
            ds = new DataSet();
            newFeed.con_open();
            adp.Fill(ds, "JVIEmp");
            newFeed.close_con();
            if (ds.Tables["JVIEmp"].Rows.Count > 0)
            {

                lblFBUserFullName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpFullName"]);
                lblFeedBackEmail.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EEmail"]);
                lblFBUserName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["UserNm"]);
                lblFeedbackLocDept.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpLocation"]);
            }
            else
            { }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.ToString();
            //       ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Kindly Login to Schedule Training Error Code: 005')</script>");
        }
    }

    protected void saveUserFeedback()
    {
        try
        {
            string getUserFbBak = "INSERT INTO UserFeebacks(FBUserEmail,FBUserName,FBUserFullName,FBType,FBComments,FBUserLocation,FBRating)Values(@a,@b,@c,@d,@e,@f,@g)";
            adp = new SqlDataAdapter(getUserFbBak, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));

            adp.SelectCommand.Parameters.AddWithValue("@a", lblFeedBackEmail.Text.ToString());
            adp.SelectCommand.Parameters.AddWithValue("@b", lblFBUserName.Text.ToString());
            adp.SelectCommand.Parameters.AddWithValue("@c", lblFBUserFullName.Text.ToString());
            adp.SelectCommand.Parameters.AddWithValue("@d", cmbFeedbackType.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@e", txtUserFeedbackComments.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@f", lblFeedbackLocDept.Text.ToString());
            adp.SelectCommand.Parameters.AddWithValue("@g", cmbUserFeedbackRating.Text.ToString().Trim());
            
            ds = new DataSet();
            newFeed.con_open();
            adp.Fill(ds, "UserFeebacks");
            newFeed.close_con();
            Response.Write("<script>alert('Thank you for your valuable feedback.')</script>");
            sendThankYouEmail();
            sendFeedBackToIT();
            Response.Redirect("FBHistory.aspx");

        }catch(Exception ex)
        {
            Response.Write("<script>alert('" + Server.HtmlEncode(ex.Message) + "')</script>");
            lblResult.Text = ex.ToString();
        }
    }
    protected void sendThankYouEmail()
    {
        string selectFeedBackForEmail;
        try
        {
            selectFeedBackForEmail = "Select Top 1 * from UserFeebacks with(nolock) Where FBUserName=@FBLog order by FBDateTime DESC";
            adp = new SqlDataAdapter(selectFeedBackForEmail, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adp.SelectCommand.Parameters.AddWithValue("@FBLog", Session["ELoginName"].ToString());
            ds = new DataSet();
            newFeed.con_open();
            adp.Fill(ds, "UserFeebacks");
            newFeed.close_con();
            if (ds.Tables["UserFeebacks"].Rows.Count > 0)
            {

                FBNumber.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBRefNo"]);
                FBUserEmail.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBUserEmail"]);
                FBType.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBType"]);
                FBDateTime.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBDateTime"]);
                FBRatings.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBRating"]);
                FBComments.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBComments"]);
   


                MailMessage msgFB = new MailMessage();
                SmtpClient clientFB = new SmtpClient("smtpout.jvi-global.com");
                msgFB.From = new MailAddress("support2@jvi-global.com");
                msgFB.To.Add("ramji.mishra@outlook.com,support2@jvi-global.com");
                msgFB.Subject = "New Feedback Ref No: " + FBNumber.Text.ToString();
                msgFB.Body = "<div class=emailContent><font family=Verdana size=4 color=blue>Dear " + lblFBUserFullName.Text.ToString() + ",<br>Greetings! from Jerry Varghese International,"
                + "<br/><br><desc>Thank you for providing your valuable feedback to us.<br>For your information we have shared your feedback details below:<hr /></font>"
                + "<font color=white family=verdana size=4><table align=centre width=100% cellpadding=2 rowpadding=5 cellspacing=2 border=1 bordercolor=green><tr font family=verdana bgcolor=purple>"
                + "<th>Sr. No.</th><th>Feedback Ref. No.</th><th>Feedback Title</th><th>Feedback Date</th><th>Reason of Feedback</th><th>Ratings</th><th>Feedback Description</th></tr>"
                + "<tr align=center><td>1</td><td>" + FBNumber.Text.ToString() + "</td><td>Feedback for " + FBType.Text.ToString() + "</td>"
                + "<td>" + FBDateTime.Text.ToString() + "</td><td>" + FBType.Text.ToString() + "</td>"
                + "<td>" + FBRatings.Text.ToString() + "</td><td>" + FBComments.Text.ToString() + "</td></tr></table></div>"
                + "<br></font><font family=verdana size=4 color=black>Kindly make login again, If you wish to see your feedbacks.</font><br><hr><br>"
                + "<img src=http://103.231.41.110/Logo/Sign.png width=100% height=240px alt=Signature></div>";
                msgFB.IsBodyHtml = true;
                //client.Port = 465;
                clientFB.Port = 25;
                clientFB.Credentials = new NetworkCredential("support2@jvi-global.com", "Hraf@923");
                clientFB.EnableSsl = false;
                clientFB.Send(msgFB);
            }
            else
            { }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
        }
    }
    protected void sendFeedBackToIT()
    {
        string selectFeedBackForConfirmation;
        try
        {
            selectFeedBackForConfirmation = "Select Top 1 * from UserFeebacks with(nolock) Where FBUserName=@ELIT order by FBDateTime DESC";
            adp = new SqlDataAdapter(selectFeedBackForConfirmation, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adp.SelectCommand.Parameters.AddWithValue("@ELIT", Session["ELoginName"].ToString());
            newFeed.con_open();
            adp.Fill(ds, "UserFeebacks");
            newFeed.close_con();
            if (ds.Tables["UserFeebacks"].Rows.Count > 0)
            {
                FBNumber.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBRefNo"]);
                FBUserEmail.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBUserEmail"]);
                FBType.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBType"]);
                FBDateTime.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBDateTime"]);
                FBRatings.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBRating"]);
                FBComments.Text = string.Format("{0}", ds.Tables["UserFeebacks"].DefaultView[0]["FBComments"]);


                MailMessage msgFbIT = new MailMessage();
                SmtpClient clientFBIT = new SmtpClient("smtpout.jvi-global.com");
                msgFbIT.From = new MailAddress("support2@jvi-global.com");
                msgFbIT.To.Add("support2@jvi-global.com");
                msgFbIT.Subject = "Feedback Ref No: " + FBNumber.Text.ToString();
                msgFbIT.Body = "<div class=emailContent><font family=Verdana size=4 color=blue>Dear IT Team,<br>Greetings! from Jerry Varghese International,"
                + "<br/><br><desc>There is feedback from below User with the following information.<br><br>User feedback has been saved. Login o to review the details.<hr>"
                + "<font color=white family=verdana size=4><table align=centre width=100% cellpadding=2 rowpadding=5 cellspacing=2 border=1 bordercolor=green><tr font family=verdana bgcolor=purple>"
                + "<th>Sr. No.</th><th>Feedback Ref. No.</th><th>Feedback Title</th><th>Feedback Date</th><th>Reason of Feedback</th><th>Ratings</th><th>Feedback Description</th></tr>"
                + "<tr align=center><td>1</td><td>" + FBNumber.Text.ToString() + "</td><td>Feedback for " + FBType.Text.ToString() + "</td>"
                + "<td>" + FBDateTime.Text.ToString() + "</td><td>" + FBType.Text.ToString() + "</td>"
                + "<td>" + FBRatings.Text.ToString() + "</td><td>" + FBComments.Text.ToString() + "</td></tr></table></div>";


                msgFbIT.IsBodyHtml = true;
                //client.Port = 465;
                clientFBIT.Port = 25;
                clientFBIT.Credentials = new NetworkCredential("support2@jvi-global.com", "Hraf@923");
                clientFBIT.EnableSsl = false;
                clientFBIT.Send(msgFbIT);
            }
            else
            { }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
        }
    }
    protected void btnSaveUserFeedback_Click(object sender, EventArgs e)
    {

        if (txtUserFeedbackComments.Text != null)
        {
            saveUserFeedback();
        }
        else
        {
            Response.Write("<script>alert('Please enter comments'</script>");
        }
    }
}