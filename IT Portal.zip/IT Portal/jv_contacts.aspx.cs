﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;
using System.Drawing;
using AjaxControlToolkit;
using System.ComponentModel;
using System.Data.OleDb;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Security.Cryptography;
using System.IO;
public partial class staffDetails : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection("Data Source=103.231.41.112;Initial Catalog=HIRECRAFTLIVE;User ID=sa;PWD=Jv_HC#321");
    SqlDataAdapter adap;
    DataSet ds;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
            }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("Login.aspx");
        }

    }
    public void ShowJVIConDetails(object sender, EventArgs e)
    {
        try
        {
            //string selectTrainings = "Select Username, convert(varchar(100),DecryptByPassPhrase('Password', @encrypt ))Password from HC_Users with(nolock) Where Username='ram.mishra'";

            string selectTrainings = "Select ROW_NUMBER() OVER(ORDER BY HC_USERS.UserName ASC) AS SrNo,isnull(Upper(HC_USERS.FirstName),'')as FirstName,"
            + "HC_USERS.JobTitle As 'Job Title',HCD.DivisionTitle + ' ( ' + HCL.LocationTitle + ' )' as 'Location', HCT.TeamTitle As Department,"
            + "lower(HC_USERS.EmailID) As Email,HC_USERS.Mobile from HC_USERS with(nolock) Join HCM_LOCATIONS HCL ON HC_USERS.LocationID=HCL.RID "
            + "Join HCM_DIVISIONS HCD On HC_USERS.DivisionID=HCD.RID Join HCM_Team HCT On HC_USERS.TeamID=HCT.RID  Where HC_USERS.Status=0 order by HC_USERS.UserName asc;";

            adap = new SqlDataAdapter(selectTrainings, con);
            adap.SelectCommand.Parameters.AddWithValue("@a", Session["ELoginName"].ToString());
            ds = new DataSet();
            con.Open();
            adap.Fill(ds, "HC_USERS");
            con.Close();
            if (ds.Tables["HC_USERS"].Rows.Count > 0)
            {
                ShowAllTrainingList.DataSource = ds.Tables["HC_USERS"];
                ShowAllTrainingList.DataBind();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('No Contact found')</script>");

            }
        }catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Connection to server has been failed.')</script>");
            errmsg.Text = ex.ToString();
        }
    }

public void ShowJviEmpByName(object sender, EventArgs e)
    {
 try
            {
            if (txtFindName.Text.Length > 0)
            {

                //string selectTrainings = "Select Username, convert(varchar(100),DecryptByPassPhrase('Password', @encrypt ))Password from HC_Users with(nolock) Where Username='ram.mishra'";

                string selectTrainings = "Select ROW_NUMBER() OVER(ORDER BY HC_USERS.UserName ASC) AS SrNo,isnull(Upper(HC_USERS.FirstName),'')as FirstName,"
                + "HC_USERS.JobTitle As 'Job Title',HCD.DivisionTitle + ' ( ' + HCL.LocationTitle + ' )' as 'Location', HCT.TeamTitle As Department,"
                + "lower(HC_USERS.EmailID) As Email,HC_USERS.Mobile from HC_USERS with(nolock) Join HCM_LOCATIONS HCL ON HC_USERS.LocationID=HCL.RID "
                + "Join HCM_DIVISIONS HCD On HC_USERS.DivisionID=HCD.RID Join HCM_Team HCT On HC_USERS.TeamID=HCT.RID  Where HC_USERS.Status=0 And HC_USERS.FirstName like @jviName "
                + " ORDER by HC_USERS.UserName asc;";

                adap = new SqlDataAdapter(selectTrainings, con);
                adap.SelectCommand.Parameters.AddWithValue("@a", Session["ELoginName"].ToString());
                adap.SelectCommand.Parameters.AddWithValue("@jviName", '%' + txtFindName.Text.Trim().ToString() + '%');
                ds = new DataSet();
                con.Open();
                adap.Fill(ds, "HC_USERS");
                con.Close();
                if (ds.Tables["HC_USERS"].Rows.Count > 0)
                {
                    ShowAllTrainingList.DataSource = ds.Tables["HC_USERS"];
                    ShowAllTrainingList.DataBind();
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('No Contact found')</script>");
                    ShowAllTrainingList.Dispose();
                    ShowAllTrainingList.DataSource = null;
                }
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Wrong Input", "<script language='javascript'>alert('Please enter minimum one character to search')</script>");
            }}
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Connection to server has been failed.')</script>");
                errmsg.Text = ex.ToString();
            }
    }

}