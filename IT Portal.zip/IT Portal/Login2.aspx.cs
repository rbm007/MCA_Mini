﻿using System;
using System.Diagnostics;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;

public partial class Login2 : System.Web.UI.Page
{
    con_properties LCon = new con_properties();
    //SqlConnection LoginCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HCUserLogin"].ToString());
    DataSet dtSet;
    SqlDataAdapter da;
    string strLoginQuery;

    public void getIPAddress(object sender, EventArgs e)
    {
        string pcIPSrc = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (string.IsNullOrEmpty(pcIPSrc))
        {
            pcIPSrc = Request.ServerVariables["REMOTE_ADDR"];

        }
        else
        {
            lblIP.Text = "Your IP: " + pcIPSrc;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        pcData.InnerText = "*Your password will be sent your registered email address if entered details matched in the system.";

        getIPAddress(null, null);
        string hostname = Request.UserHostName;
        OperatingSystem os = Environment.OSVersion;
        String subKey = @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion";
        RegistryKey key = Registry.LocalMachine;
        HttpBrowserCapabilities browser = Request.Browser;
        RegistryKey skey = key.OpenSubKey(subKey);
        //var pc = new PerformanceCounter("Mono Memory", "Total Physical Memory");
        System.Web.HttpContext context = System.Web.HttpContext.Current;
        //string clientIPAdd = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        //string clientIPAdd = context.Request.ServerVariables["REMOTE_ADDRESS"];
        //string IP = Dns.GetHostEntry(Dns.GetHostName()).Ad‌​dressList[1].ToStrin‌​g();



        ipAddress.Text = "<b>Your Computer Name: </b>" + Environment.MachineName.ToString()
            + "<br><b>Your Windows Version:</b>" + Environment.OSVersion.ToString()
            + "<br><b>Logged Username: </b>" + Environment.UserName.ToString()
            + "<br><b>You Are using: </b>" + browser.Browser.ToString() + " Brower"
            + "<br><b>Computer Date And Time: </b>" + DateTime.Now
            + "<br><b>Operating System: </b>" + skey.GetValue("ProductName").ToString();
    }
    public void LoginLogUser()
    {
        try
        {
            string insertUserLoginLog;
            HttpBrowserCapabilities browser = Request.Browser;
            insertUserLoginLog = "INSERT INTO UserLoginLog(ELoginName,PC_Name,BrowserName)Values(@e,@pc,@br)";
            da = new SqlDataAdapter(insertUserLoginLog, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            da.SelectCommand.Parameters.AddWithValue("@e", Session["ELoginName"].ToString());
            da.SelectCommand.Parameters.AddWithValue("@pc", Environment.MachineName.ToString());
            da.SelectCommand.Parameters.AddWithValue("@br", browser.Browser.ToString());

            dtSet = new DataSet();
            LCon.con_open();
            da.Fill(dtSet, "UserLoginLog");
            LCon.con_open();
            ipAddress.Text = ipAddress.Text + ".<br>Authentication Successful.";
        }
        catch (Exception ec)
        {
            lblError.Text = ec.ToString();
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {

        if (txtUserName.Text != null && txtPWD.Text != null)
        {
            try
            {
                strLoginQuery = "select EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName As EmpName,ELoginName,EFirstName,EPassword from JVIEmp with(nolock) where ELoginName=@U and Epasskey=@P";
                //strLoginQuery = "select FirstName + ' ' + LastName As EmpName, UserName AS ELoginName, Password from HC_USERS with(nolock) Where Status=0 And UserName=@U And Password=@P";
                da = new SqlDataAdapter(strLoginQuery, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
                dtSet = new DataSet();
                da.SelectCommand.Parameters.AddWithValue("@U", txtUserName.Text.ToString());
                da.SelectCommand.Parameters.AddWithValue("@P", Convert.ToString(txtPWD.Text));
                LCon.con_open();
                da.Fill(dtSet, "JVIEmp");
                LCon.close_con();
                if (dtSet.Tables["JVIEmp"].Rows.Count > 0)
                {
                    Session["ELoginName"] = txtUserName.Text.ToString();
                    LoginLogUser();
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    //lblError.Text = "Invalid username And Password";
                    Response.Write("<script>alert('Invalid Username And Password')</script>");
                    lblError.Text = "";
                    btnReset_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Web Connection Failed')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Please enter username/password')</script>");

        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        txtUserName.Text = "";
        txtPWD.Text = "";
        txtUserName.Focus();
    }

    protected void lblForgot_Click(object sender, EventArgs e)
    {
        forgotPwd.Show();
    }


    public void readyLogin()
    {
        forgotUserName.Text = null;
        forgotEmailAddress.Text = null;
        forgotPwdMobile.Text = null;
        forgotUserName.Focus();
        pcData.InnerText = "";

    }

    protected void getUserPassword()
    {
        try
        {
            string LoginInfoPwd;
            LoginInfoPwd = "Select ELoginName, EPassKey, EEmail, Emobile from JVIEmp WITH(NOLOCK) Where ELoginName=@Elg AND Emobile=@mobile AND EEmail=@email";
            da = new SqlDataAdapter(LoginInfoPwd, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));

            da.SelectCommand.Parameters.AddWithValue("@Elg", forgotUserName.Text.ToString().Trim());
            da.SelectCommand.Parameters.AddWithValue("@mobile", forgotPwdMobile.Text.ToString().Trim());
            da.SelectCommand.Parameters.AddWithValue("@email", forgotEmailAddress.Text.ToString().Trim());

            dtSet = new DataSet();
            LCon.con_open();
            da.Fill(dtSet, "JVIEmp");
            LCon.close_con();

            if (dtSet.Tables["JVIEmp"].Rows.Count > 0)
            {
                
                sendUserNamePwd();
                LoginRequestLog();
                //Response.Write("<script>alert('Congratulations! Login details has been sent on your registred email</br>You will be redirected to Login Page')</script>");
                pnError.Text = "Login Details has bee forwarded your registered Email Address.";
                readyLogin();
            }
            else
            {
                Response.Write("<script>alert('No records matched. Please verify your details again')</script>");
                forgotPwd.Show();

            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Invalid Data Entered. Unable to process your request. Please try after sometime')</script>");
            forgotPwd.Show();
            pnError.Text = ex.ToString();
        }
    }

    protected void sendUserNamePwd()
    {
        string selectTicket;
        try
        {
            selectTicket = "Select EPreFix + ' ' + EFirstName As FN, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName AS FullName, ELoginName, EPassKey, EEmail,"
                + "Emobile from JVIEmp WITH(NOLOCK) WHERE Emobile=@mob And EEmail=@eid And ELoginName=@ss";
            da = new SqlDataAdapter(selectTicket, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
            da.SelectCommand.Parameters.AddWithValue("@mob", forgotPwdMobile.Text.ToString().Trim());
            da.SelectCommand.Parameters.AddWithValue("@eid", forgotEmailAddress.Text.ToString().Trim());
            da.SelectCommand.Parameters.AddWithValue("@ss", forgotUserName.Text.ToString().Trim());
            dtSet = new DataSet();
            LCon.con_open();
            da.Fill(dtSet, "JVIEmp");
            LCon.close_con();
            if (dtSet.Tables["JVIEmp"].Rows.Count > 0)
            {
                forName.Text = string.Format("{0}", dtSet.Tables["JVIEmp"].DefaultView[0]["FullName"]);
                forEmail.Text = string.Format("{0}", dtSet.Tables["JVIEmp"].DefaultView[0]["EEmail"]);
                forPass.Text = string.Format("{0}", dtSet.Tables["JVIEmp"].DefaultView[0]["EPassKey"]);
                forMobile.Text = string.Format("{0}", dtSet.Tables["JVIEmp"].DefaultView[0]["Emobile"]);
                forUName.Text = string.Format("{0}", dtSet.Tables["JVIEmp"].DefaultView[0]["ELoginName"]);
                forFirstName.Text = string.Format("{0}", dtSet.Tables["JVIEmp"].DefaultView[0]["FN"]);

                MailMessage msgGETPWD = new MailMessage();
                SmtpClient clientPWD = new SmtpClient("smtpout.jvi-global.com");
                msgGETPWD.From = new MailAddress("support2@jvi-global.com");
                msgGETPWD.To.Add(forgotEmailAddress.Text.ToString());
                msgGETPWD.Subject = "Login ID and Password";

                msgGETPWD.Body = "<html><body bgcolor=honeydew width=80% font-family=verdana>"
                + "<div style=width:60%;>Dear " + forFirstName.Text.ToString() + ",<br><br>Greetings! from Jerry Varghese - IT Team,"
                + "<br><br><desc>We have received Login Assistant request from you. Please find below your Login Information.<br><br>"
                + "If you did not request for password, Kindly Call IT Team or send Email on <b>support2@jvi-global.com</b> ASAP.<br><hr/><br>"
                + "<table style=padding:10px; font-family=verdana; font-size=10px; font-color=white; align=left width=100% cellpadding=2 rowpadding=3 cellspacing=2 border=2 bordercolor=black>"
                + "<tr><td bgcolor=DeepSkyBlue font-color=white>Complete Name: </td><td>" + forName.Text.ToString() + "</td></tr>"
                + "<tr><td bgcolor=DeepSkyBlue font-color=white>Registered Email ID: </td><td>" + forEmail.Text.ToString() + "</td></tr>"
                + "<tr><td bgcolor=DeepSkyBlue font-color=white>Login Username: </td><td>" + forUName.Text.ToString() + "</td></tr>"
                + "<tr><td bgcolor=DeepSkyBlue font-color=white>Your Password: </td><td><b>" + forPass.Text.ToString() + "</b></td></tr>"
                + "<tr><td bgcolor=DeepSkyBlue font-color=white>Registered Mobile: </td><td>" + forMobile.Text.ToString() + "</td></tr>"
                + "<tr><td bgcolor=DeepSkyBlue font-color=white>Requested On: </td><td>" + DateTime.Now + "</td></tr>"
                + "<tr><td colspan=2><big>Kindly make login again, If you wish to provide feedback or to use other online services.</big></b></td></tr></table></div></body></html>"
                + "<br><hr><img src=http://103.231.41.110/Logo/Sign.png width=100% height=280px alt=Signature>";
                msgGETPWD.IsBodyHtml = true;
                //client.Port = 465;
                clientPWD.Port = 25;
                clientPWD.Credentials = new NetworkCredential("support2@jvi-global.com", "Hraf@923");
                clientPWD.EnableSsl = false;
                clientPWD.Send(msgGETPWD);
            }
            else
            { }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message.ToString();
        }
    }

    protected void btnSubmitRetrievePWD_Click(object sender, EventArgs e)
    {
        if (forgotEmailAddress.Text == "" | forgotPwdMobile.Text == "" | forgotUserName.Text == "")
        {
            Response.Write("<script>alert('Please Enter Username/Email/Email for login assistance')</script>");
            lblForgot_Click(null,null);

        }
        else
        {
            getUserPassword();
            Response.Write("<script>alert('Login details has been sent your Email Address successfully')</script>");
        }
    }
    protected void LoginRequestLog()
    {
        try
        {
            string saveUserRequest = "INSERT INTO JVIUserRequestForPassword(Username,Email,Mobile) VALUES (@u,@e,@m)";
            da = new SqlDataAdapter(saveUserRequest, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
            da.SelectCommand.Parameters.AddWithValue("@u", forgotUserName.Text.ToString().Trim());
            da.SelectCommand.Parameters.AddWithValue("@e", forgotEmailAddress.Text.ToString().Trim());
            da.SelectCommand.Parameters.AddWithValue("@m", forgotPwdMobile.Text.ToString().Trim());
            dtSet = new DataSet();
            LCon.con_open();
            da.Fill(dtSet, "JVIUserRequestForPassword");
            LCon.close_con();
            //Response.Write("<script>alert('Request sent successfully')</script>");
        }
        catch (Exception ex)
        {
            lblError.Text = ex.ToString();
        }
    }
    protected void btnLginAgain_Click(object sender, EventArgs e)
    {
        forgotPwd.Hide();
        //Response.Redirect("~/Login.aspx");
    }
}