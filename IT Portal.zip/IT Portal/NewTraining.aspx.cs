﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;

public partial class Training : System.Web.UI.Page
{
    con_properties newCon = new con_properties();
    SqlDataAdapter adp;
    DataSet ds;

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("Login.aspx");
        }

        loadDataFromEmp();
    }
    protected void loadDataFromEmp()
    {
        try
        {
            string selectDt = "SELECT ELoginName,EEmail, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName + '( ' + Edesg + ' )' As EmpFullName," +
                "EDept + ' ' + EDiv +  ' [ ' + Elocation + ' ]' As EmpLocation From JVIEmp with(nolock) Where ELoginName=@eLog";
            SqlDataAdapter adp = new SqlDataAdapter(selectDt, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
            adp.SelectCommand.Parameters.AddWithValue("@eLog", Session["ELoginName"].ToString());
            ds = new DataSet();
            newCon.con_open();
            adp.Fill(ds, "JVIEmp");
            newCon.close_con();
            if (ds.Tables["JVIEmp"].Rows.Count > 0)
            {
                txtTrainingUserName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["ELoginName"]);
                txtTraineeFullName.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpFullName"]);
                txtUserLocationInfo.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpLocation"]);
                txtTraineeEmail.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EEmail"]);
            }
            else
            { }
        }
        catch (Exception ex)
        {
//            lblResult.Text = ex.ToString();
        ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Session Expired. Kindly Re-Login to Schedule Training Error Code: 005')</script>");
        Response.Redirect("Login.aspx");
        }
    }
    protected void sendTrainingEmailConfirmation()
    {
        string selectTicket;
        try
        {
            selectTicket = "Select Top 1 * from UserTraining with(nolock) Where EloginName=@EL order by TTrainingCreatedDate DESC";
            adp = new SqlDataAdapter(selectTicket, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adp.SelectCommand.Parameters.AddWithValue("@EL", txtTrainingUserName.Text.ToString());
            newCon.con_open();
            adp.Fill(ds, "UserTraining");
            newCon.close_con();
            if (ds.Tables["UserTraining"].Rows.Count > 0)
            {

                trainingNumber.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TRefNo"]);
                trainingEmailTrainingTitle.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TTrainingTitle"]);
                trainingEmailTType.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TType"]);
                trainingEmailDateTime.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TDateFromTime"]);
                trainingEmailDateTimeTill.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TDateTillTime"]);
                trainingEmailTrainingLocation.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TTrainingLocation"]);
                trainingEmailTrainingVenue.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TTrainingVenue"]);
                trainingEmailTraineeName.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["EloginName"]);
                trainingEmailTrainerName.Text = string.Format("{0}", ds.Tables["UserTraining"].DefaultView[0]["TTrainerName"]);


                MailMessage msg = new MailMessage();
                SmtpClient client = new SmtpClient("smtpout.jvi-global.com");
                msg.From = new MailAddress("support2@jvi-global.com");
                msg.To.Add(txtTraineeEmail.Text.ToString());
                msg.Subject = txtTrainingTitle.Text.ToString();
                msg.Body = "<div class=emailContent><font family=arial size=4 color=blue>Dear User,<br>Greetings! from Jerry Varghese International,"
                + "<br/><br><desc>We are glad to inform you that you have successfully scheduled a <u>" + trainingEmailTType.Text.ToString() +"</u> training for you. Your training will be conducted by IT department soon. <br/><br>Please find below your training Program<hr /></font>"
                + "<font color=white family=verdana size=4><table align=centre width=100% cellpadding=2 rowpadding=5 cellspacing=2 border=2 bordercolor=blue><tr font family=verdana bgcolor=purple>"
                + "<th>Sr.No.</th><th>Training Name</th><th>Training Ticket No.</th><th>Training From Date</th><th>Training Till Date </th><th>Training Location</th><th>Training Venue</th><th>Trainee UserName</th><th>Trainer Name</th></tr>"
                + "<tr align=center><td>1</td><td>" + trainingEmailTType.Text.ToString() + "</td><td>" + trainingNumber.Text.ToString() + "</td>"
                + "<td>" + trainingEmailDateTime.Text.ToString() + "</td><td>" + trainingEmailDateTimeTill.Text.ToString() + "</td>"
                + "<td>" + trainingEmailTrainingLocation.Text.ToString() + "</td><td>" + trainingEmailTrainingVenue.Text.ToString() + "</td>"
                + "<td>" + trainingEmailTraineeName.Text.ToString() + "</td><td>" + trainingEmailTrainerName.Text.ToString() + "</td></tr></table></div>"
                + "<br></font><font family=verdana size=4 color=black>Kindly make login again, If you wish to change the training schedule details.</font><br><hr><br>"
                + "<img src=http://103.231.41.110/Logo/Sign.png width=100% height=240px alt=Signature></div>";
                msg.IsBodyHtml = true;
                //client.Port = 465;
                client.Port = 25;
                client.Credentials = new NetworkCredential("support2@jvi-global.com", "Hraf@923");
                client.EnableSsl = false;
                client.Send(msg);
            }
            else
            { }
        }
        catch (Exception ex)
        {
            lblResult.Text = ex.Message.ToString();
        }
    }
    protected void saveNewTraining()
    {
        string saveQuery;
        DateTime FromTrainingDate = DateTime.ParseExact(dtFrom.Text, "dd-MMM-yyyy HH:mm", System.Globalization.CultureInfo.InvariantCulture);
        DateTime ToTrainingDate = DateTime.ParseExact(dtTo.Text, "dd-MMM-yyyy HH:mm", System.Globalization.CultureInfo.InvariantCulture);
        try
        {
            if (txtTrainingUserName.Text != null)
            {
                saveQuery = "INSERT INTO UserTraining(ELoginName,TDateFromTime, TDateTillTime,TType,TTrainerName,TTrainingLocation,TUserLevel,TTrainingVenue,TTrainingNotes,TTrainingTitle)"
    + "VALUES('" + txtTrainingUserName.Text.ToString().Trim() + "','" + FromTrainingDate + "',"
    + "'" + ToTrainingDate + "','" + cmbTrainingType.Text.ToString().Trim() + "','" + txtTrainerName.Text.ToString().Trim() + "','" + cmbTrainingLocation.Text.ToString().Trim() + "',"
    + "'" + cmbTrainingUserType.Text.ToString().Trim() + "','" + txtTrainingVenue.Text.ToString().Trim() + "',"
    + "'" + txtTrainingNotes.Text.ToString().Trim() + "','" + txtTrainingTitle.Text.ToString().Trim() + "')";

                adp = new SqlDataAdapter(saveQuery, (ConfigurationManager.ConnectionStrings["JVIITString"].ToString()));
                ds = new DataSet();
                newCon.con_open();
                adp.Fill(ds, "UserTraining");
                newCon.close_con();
                Response.Write("<script language='javascript'>alert('New Training has been scheduled successfully. Details will be sent on your email ID.')</script>");
                sendTrainingEmailConfirmation();
                Response.Redirect("Default.aspx");
            }

            else
            {
                Response.Redirect("errorMsg.aspx");

            }

        }
        catch (Exception ex)
        {

            lblResult.Text = ex.ToString();
            //string message = string.Format("Message: {0}\\n\\n", ex.Message);
            //message += string.Format("StackTrace: {0}\\n\\n", ex.StackTrace.Replace(Environment.NewLine, string.Empty));
            //message += string.Format("Source: {0}\\n\\n", ex.Source.Replace(Environment.NewLine, string.Empty));
            //message += string.Format("TargetSite: {0}", ex.TargetSite.ToString().Replace(Environment.NewLine, string.Empty));
            //ClientScript.RegisterStartupScript(Page.GetType(), "Error Occured", "<script language='javascript'>alert('\"" + message + "\"');", true);
            //ClientScript.RegisterStartupScript(Page.GetType(), "Validation Failed", "<script language='javascript'>alert('You are not loggedIn. Kindly Re-Login.')</script>");

        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            saveNewTraining();
            
        }
        catch (Exception ex)
        { lblResult.Text = ex.ToString(); }
    }
}
