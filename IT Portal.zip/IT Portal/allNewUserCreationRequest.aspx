﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="allNewUserCreationRequest.aspx.cs" Inherits="alltraining" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajx" %>
<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="images/logo.png" align="left" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTimeOffset.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" ID="allTrainingList" runat="server">
    <style type="text/css">
        .tableBackground {
            background-color: silver;
            opacity: 0.7;
        }
    </style>
    <div class="container" runat="server">
        <h1 class="lblTrnTitle">List of All Requests<br />
        </h1>
        <br />
        <div class="UserRegReqData" runat="server">


            <asp:GridView ID="ShowAllRequestList" runat="server" CssClass="UserRegReqData" RowStyle-Height="30" HeaderStyle-Height="40" HeaderStyle-ForeColor="#CCFFFF" HeaderStyle-BackColor="#003300" HeaderStyle-HorizontalAlign="Center" HeaderStyle-VerticalAlign="Middle" HeaderStyle-Wrap="True">
            </asp:GridView>

            <%--<asp:GridView ID="ShowAllTrainingListOld" DataKeyNames="TRefNo" runat="server" CssClass="ScheduleTrainingData" AutoGenerateColumns="False" AlternatingItemStyle-HorizontalAlign="NotSet" AlternatingItemStyle-VerticalAlign="NotSet" AlternatingItemStyle-BorderStyle="None" AllowPaging="True" AllowSorting="True" BackColor="#DEBA84" HeaderStyle-BorderStyle="Ridge" HeaderStyle-Height="35" ItemStyle-HorizontalAlign="Left" PageSize="20" SelectedItemStyle-BackColor="#6600CC" HeaderStyle-ForeColor="White" HeaderStyle-BackColor="#990099" HeaderStyle-HorizontalAlign="Center" HeaderStyle-VerticalAlign="Middle" PagerSettings-Mode="Numeric" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="3" CellSpacing="2" EnableModelValidation="True">
               <Columns>
                    <asp:TemplateField HeaderText="Select">
                        <ItemTemplate>
                            <%--<input id="MyRadioButton" type="radio" value='<%# Eval("TrefNo") %>' />--%>
            <%--<input id="MyRadioButton" type="radio" value='<%# Eval("TRefNo") %>' />

                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="TrefNo" HeaderText="Training Number" />
                    <asp:BoundField DataField="TTrainingTitle" HeaderText="Training Subject" />
                    <asp:BoundField DataField="TTRainingLocation" HeaderText="Training Location" />
                    <asp:BoundField DataField="TUserLevel" HeaderText="User Level" />
                    <asp:BoundField DataField="TTrainingNotes" HeaderText="Training Remarks" />

                </Columns>
                <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />

                <HeaderStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#A55129" BorderStyle="Ridge" ForeColor="White" Height="35px" Font-Bold="True"></HeaderStyle>
                <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                <RowStyle BackColor="#FFF7E7" ForeColor="#8C4510" />
                <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" ForeColor="White" />
            </asp:GridView>--%>
            <div class="clear"></div>
            <hr>
            <br />
            <asp:Label ID="errmsg" runat="server" Text="" BackColor="Yellow" ForeColor="Red" Font-Size="Small">
            </asp:Label>
        </div>
        </div>
</asp:Content>
