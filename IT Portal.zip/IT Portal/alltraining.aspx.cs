﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;
using System.Drawing;
using AjaxControlToolkit;

public partial class alltraining : System.Web.UI.Page
{

    con_properties con = new con_properties();
    SqlDataAdapter adap;
    DataSet ds;


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            UNameText.Text = "Welcome! " + Session["ELoginName"].ToString();
            BindAllScheduledTraining();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            Response.Redirect("Login.aspx");
        }

    }


    public void BindAllScheduledTraining()
    {
        try
        {
            string selectTrainings = "Select TrefNo as TrainingNumber, Format(TDateFromTime, 'ddd dd-MMM-yyy hh:mm:ss tt') As TrainingDate, TTYpe as TrainingType, Format(TTrainingCreatedDate, 'ddd dd-MMM-yyy hh:mm:ss tt') as ScheduledOn,"
+ "ttrainingLocation As TrainingLocation from UserTraining with(nolock) Where ELoginName=@a";
            //string selectTrainings = "SELECT ROW_NUMBER() OVER(ORDER BY TRefNo ASC) AS SrNo,TRefNo,"
            //+ "Format(TTrainingCreatedDate, 'dd-MMM-yyyy hh:mm tt') As 'Scheduled Date',TTrainingTitle,"
            //+ "Format(TdateFromTime, 'dd-MMM-yyyy hh:mm tt') As 'Start Date', Format(TDateTillTime, 'dd-MMM-yyyy hh:mm tt') As 'End Date',"
            //+ "TType as 'Training Type', TTrainerName AS 'Trainer Name',TTrainingLocation + ' ' + TTrainingVenue As 'Training Address',"
            //+ "TTrainingStatus as Status,TTrainingNotes as Remarks from UserTraining with(nolock) "
            //+ "Where ELoginName=@a";

            adap = new SqlDataAdapter(selectTrainings, ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
            adap.SelectCommand.Parameters.AddWithValue("@a", Session["ELoginName"].ToString());
            ds = new DataSet();
            con.con_open();
            adap.Fill(ds, "UserTraining");
            con.close_con();
            if (ds.Tables["UserTraining"].Rows.Count > 0)
            {
                ShowAllTrainingList.DataSource = ds.Tables["UserTraining"];
                ShowAllTrainingList.DataBind();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('You have not scheduled any training.')</script>");
                
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Error in loading training details.Try Again.')</script>");
            errmsg.Text = ex.ToString();
        }
    }


    protected void modelPopup_Click(object sender, EventArgs e)
    {
        updatePanel.Visible = true;
  
    }
    protected void lnkEdit_Click(object sender, EventArgs e)
    {
        //LinkButton btnsubmit = sender as LinkButton;
        //GridViewRow gRow = (GridViewRow)btnsubmit.NamingContainer;
        //lblTrainingNumber.Text = ShowAllTrainingList.DataKeys[gRow.RowIndex].Value.ToString();
        //lblTrainingSubject.Text = gRow.Cells[0].Text;
        //lblTrainingLoc.Text = gRow.Cells[1].Text;
        //txtUserLevel.Text = gRow.Cells[2].Text;
        //lblTrainingRemarks.Text = gRow.Cells[3].Text;
        //updatePanel.Visible = true;
    }
    protected void btnModity_Click(object sender, EventArgs e)
    {
        this.trainingUpdatorBox.Show();
    }



    protected void btnUpdateTrainingInfo_Click(object sender, EventArgs e)
    {
        LinkButton btnUpdateTrain = sender as LinkButton;
        GridViewRow gRow = (GridViewRow)btnUpdateTrain.NamingContainer;
        txtTrainingNumber.Text = ShowAllTrainingList.DataKeys[gRow.RowIndex].Value.ToString();
        txtTrainingDate.Text = gRow.Cells[0].Text;
        txtTrainingType.Text = gRow.Cells[1].Text;
        txtTraingScheduleDate.Text = gRow.Cells[2].Text;
        txtTraingLocation.Text = gRow.Cells[3].Text;
        updatePanel.Visible = true;
    }
}