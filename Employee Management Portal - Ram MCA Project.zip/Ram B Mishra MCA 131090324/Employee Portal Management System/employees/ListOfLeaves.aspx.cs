﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Globalization;
using System.Net;
using System.Net.Mail;


public partial class comman_pages_leaveRecords : System.Web.UI.Page
{
    con_properties LLC = new con_properties();
    SqlDataAdapter sdaLeave;
    DataSet dst;
    string UpdatePassword;
    string getEmpCode;
    string strLoadAllQueries;
    string myQueries;
    int countrow;
    string UserNameFullName;
    string UpdateLeaveStatus;

        protected void Page_Load(object sender, EventArgs e)
    {
        LoadAllLeaveRecords();
    }

    public void LoadAllLeaveRecords()
    {
        if (!this.IsPostBack)
        {
            try
            {
                strLoadAllQueries = "SELECT  EL.RID As 'Leave Code', EL.LeaveRefEmpRID As 'Employee Code', HR.EmpTitle + ' ' + HR.EmpFirstName + ' ' + HR.EmpMiddleName + ' ' + HR.EmpLastName As 'Employee Name', HR.EmpDept As 'Department',"
                + "HR.EmpDesignation As 'Designation', EL.dtLeaveApplied As 'Application Date', Convert(DateTime, EL.dtLeaveStartDate,105) As 'Leave From', Convert(DateTime,EL.dtLeaveEndDate,105) As 'Leave Till', EL.TotalAppliedDays As 'Total Days',"
                + "EL.LeaveApprovedDate As LastModifiedDate, EL.ReasonForLeave As 'Leave Reason', EL.LeaveStatus As LeaveStatus  from EmpAppliedLeave EL LEFT OUTER JOIN  HRA_Employee HR ON "
                + "EL.LeaveRefEmpRID = hr.EmpCode Where HR.EmpEmail=@EmEmail Order By EL.dtLeaveApplied ASC";

                sdaLeave = new SqlDataAdapter(strLoadAllQueries, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sdaLeave.SelectCommand.Parameters.AddWithValue("@EmEmail", Session["EmEmail"].ToString());
                LLC.con_open();
                dst = new DataSet();
                sdaLeave.Fill(dst, "EmpAppliedLeave");
                LLC.close_con();
                countrow = dst.Tables["EmpAppliedLeave"].Rows.Count;
                if (countrow > 0)
                {
                    grdViewLeaveRecords.AutoGenerateColumns = false;
                    grdViewLeaveRecords.DataMember = "EmpAppliedLeave";
                    grdViewLeaveRecords.DataSource = dst;
                    grdViewLeaveRecords.DataBind();
                    grdViewLeaveRecords.Visible = true;
                }

                else
                {
                    lblErrorEmpLeaveRecord.Text = " There is no leave application found";
                }
            }
            catch (Exception ex)
            {
                lblErrorEmpLeaveRecord.Text = ex.Message.ToString();
            }
        }
    }

    protected void grdViewLeaveRecords_SelectedIndexChanged(object sender, EventArgs e)
    {

        try
        {
            ELeaveCodeNumber.Text = (grdViewLeaveRecords.SelectedRow.FindControl("lblLeaveCodeGrd") as Label).Text;
            ECodeLeaveDetails.Text = (grdViewLeaveRecords.SelectedRow.FindControl("lblEmpCodeGrd") as Label).Text;
            ENameLeaveDetails.Text = (grdViewLeaveRecords.SelectedRow.FindControl("lblEmpNameGrd") as Label).Text;
            ECodeLeaveAppliedOn.Text = (grdViewLeaveRecords.SelectedRow.FindControl("lblLeaveAppDateGrd") as Label).Text;
            ECodeLeaveStartDt.Text = (grdViewLeaveRecords.SelectedRow.FindControl("lblLeaveStartDtGrd") as Label).Text;
            ECodeLeaveEndDt.Text = (grdViewLeaveRecords.SelectedRow.FindControl("lblLeaveEndDtGrd") as Label).Text;

            BindLeaveAndEmpDetails();
            empLeaveDetailsWindows.Show();
        }
        
                catch (SqlException ex)
        {
            if (ex.Number == 1205)
            {
                lblErrorEmpLeaveRecord.Text = ex.Message.ToString();
            }
            else
            {
                lblErrorEmpLeaveRecord.Text = "Data Error: Check your network setting";
            }
        }
    }

    public void BindLeaveAndEmpDetails()
    {
        //if (!this.IsPostBack)
        //{
        try
        {
            strLoadAllQueries = "SELECT EL.RID As 'Leave Code', EL.LeaveRefEmpRID As 'Employee Code', HR.EmpTitle + ' ' + HR.EmpFirstName + ' ' + HR.EmpMiddleName + ' ' + HR.EmpLastName As 'Employee Name',"
            + "HR.EmpDept As 'Department',HR.EmpDesignation As 'Designation', EL.dtLeaveApplied As 'Application Date', EL.dtLeaveStartDate As 'Leave From',HR.EmpLocation As Location, EL.LeaveStatus As LeaveStatus,"
            + "EL.dtLeaveEndDate As 'Leave Till', EL.TotalAppliedDays As 'TotalDays',el.ReasonForLeave As 'LeaveReason', EL.LeaveType As LeaveType, EL.LeaveRejectReason As LeaveRejAppReason, El.LeaveApprovedDate"
            + " As LastModifiedDate, HR.Balance_Leave As BalLeave from EmpAppliedLeave EL "
            + "LEFT OUTER JOIN  HRA_Employee HR ON EL.LeaveRefEmpRID = hr.EmpCode WHERE EL.RID=@RID";

            sdaLeave = new SqlDataAdapter(strLoadAllQueries, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            sdaLeave.SelectCommand.Parameters.AddWithValue("@EmpE", Session["EmpEmail"].ToString());
            sdaLeave.SelectCommand.Parameters.AddWithValue("@RID", ELeaveCodeNumber.Text.ToString());
            LLC.con_open();
            dst = new DataSet();
            sdaLeave.Fill(dst, "EmpAppliedLeave");
            countrow = dst.Tables["EmpAppliedLeave"].Rows.Count;

            if (countrow > 0)
            {
                EDeptLeaveDetails.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["Department"]);
                EDesgLeaveDetails.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["Designation"]);
                ELocationLeaveDetails.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["Location"]);
                ELeaveTotalDays.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["TotalDays"]);
                ELeaveReason.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LeaveReason"]);
                drpLeaveStatus.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LeaveStatus"]);
                ECodeLeaveType.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LeaveType"]);
                txtLeaveRemarksNotes.InnerText = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LeaveRejAppReason"]);
                lblTotalBalanceLeave.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["BalLeave"]);
            }
        }
        catch (Exception ex)
        { lblErrorEmpLeaveRecord.Text = ex.Message.ToString(); }
        LLC.close_con();
    }

    //}

    public void UpdateEmployeeLeaveDt()
    {
        DateTime dtValue = DateTime.Now;
        Label lblSessionName = new Label();
        lblSessionName.Text = Session["EmpName"].ToString();
        String SelectLeaveAndEMail;
        try
        {
           
                Label lblReject = new Label();
                lblReject.Text = txtLeaveRemarksNotes.InnerText.ToString();

                UpdateLeaveStatus = "Update EmpAppliedLeave SET LeaveApprovedBy=@a, LeaveApprovedDate=@b, LeaveRejectReason=@c , LeaveStatus = @d Where RID=@e;";
                sdaLeave = new SqlDataAdapter(UpdateLeaveStatus, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            sdaLeave.SelectCommand.Parameters.AddWithValue("@a", Session["EmpName"].ToString());
                sdaLeave.SelectCommand.Parameters.AddWithValue("@b", (dtValue.ToString("dd-MMM-yyyy hh:mm:ss tt")));
                sdaLeave.SelectCommand.Parameters.AddWithValue("@c", lblReject.Text.ToString());
                sdaLeave.SelectCommand.Parameters.AddWithValue("@d", drpLoadLeaveStatus.Text.ToString());
                sdaLeave.SelectCommand.Parameters.AddWithValue("@e", ELeaveCodeNumber.Text.ToString());

                dst = new DataSet();
                LLC.con_open();
                sdaLeave.Fill(dst, "EmpAppliedLeave");
                LLC.close_con();
                Response.Write("<script>alert('Leave application is updated')</script>");

                // Update Employee Leave

                myQueries = "Update HRA_Employee SET Balance_Leave=@bleave Where EmpCode=@ECD;";
                double appliedLeave = Convert.ToDouble(ELeaveTotalDays.Text);
                double balanceLeave = Convert.ToDouble(lblTotalBalanceLeave.Text);
                double rem_leaveBal = Convert.ToDouble(balanceLeave - appliedLeave);

                sdaLeave = new SqlDataAdapter(myQueries, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sdaLeave.SelectCommand.Parameters.AddWithValue("@bleave", string.Format("{0}", rem_leaveBal.ToString()));
                sdaLeave.SelectCommand.Parameters.AddWithValue("@ecd", string.Format("{0}", ECodeLeaveDetails.Text.ToString()));
                dst = new DataSet();
                LLC.con_open();
                sdaLeave.Fill(dst, "HRA_Employee");
                LLC.close_con();

                // Send EMail to Employee

                DateTime utc = DateTime.Now;
                SelectLeaveAndEMail = "Select Top 1 HR.EmpTitle + ' ' + HR.EmpFirstName + ' ' + HR.EmpLastName As 'Employee', L.Leaveid As LCode, L.LeaveRefEmpRID As ECode, L.LeaveType LT, L.dtLeaveApplied as LeaveAppDate,L.dtLeaveStartDate As LeaveFrom,"
            + "L.dtLeaveEndDate As LEnd, L.TotalAppliedDays as LDays, L.LeaveStatus as LStatus, L.LeaveApprovedBy As AppManager, L.LeaveApprovedDate As ApprovedOn, L.LeaveNotesForEmp As Notes, HR.EmpEmail As Em "
            + "From EmpAppliedLeave L LEFT OUTER JOIN  HRA_Employee HR ON L.LeaveRefEmpRID = hr.EmpCode WHERE L.RID=@RID";

                sdaLeave = new SqlDataAdapter(SelectLeaveAndEMail, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sdaLeave.SelectCommand.Parameters.AddWithValue("@RID", ELeaveCodeNumber.Text.ToString());
                LLC.con_open();
                sdaLeave.Fill(dst, "EmpAppliedLeave");
                LLC.close_con();
                countrow = dst.Tables["EmpAppliedLeave"].Rows.Count;

                if (countrow > 0)
                {
                    EmailEmpName.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["Employee"]);
                    EmailLeaveCode.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LCode"]);
                    EmailEmpCode.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["ECode"]);
                    EmailLeaveType.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LT"]);
                    EmailLeaveAppDate.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LeaveAppDate"]);
                    EmailLeaveStDate.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LeaveFrom"]);
                    EmailLeaveEndDate.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LEnd"]);
                    EmailLeaveTotalDays.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LDays"]);
                    EmailLeaveStatus.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["LStatus"]);
                    EmailApprovalMgr.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["AppManager"]);
                    EmailLeaveApproveDate.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["ApprovedOn"]);
                    EmailLeaveRemarks.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["Notes"]);
                    EmailLeaveEmailTo.Text = string.Format("{0}", dst.Tables["EmpAppliedLeave"].DefaultView[0]["Em"]);


                    var fromAddress = new MailAddress("ramji.mishra@outlook.com", "HR Connect Portal");
                    var toAddress = new MailAddress(EmailLeaveEmailTo.Text.ToString(), EmailEmpName.Text.ToString());
                    const string fromPassword = "Mishra@007";
                    const string subject = "Leave Application Status";
                    string body = "<html><body width=100% font-family=verdana>"
                    + "<div style=width:70%; border:1pt solid orangered; padding:5pt;>"
                    + "<font family=Verdana size=4 color=white> Dear " + EmailEmpName.Text.ToString() + ",<br>Greetings! from HR Connect Portal,"
                    + "<br/><br><desc>Your Leave Application status is <b>" + EmailLeaveStatus.Text.ToString() + "</b>.<br> <b>Leave Application details are given below for your kind information</b>"
                    + "<table align=center width=40%  cellpadding=4 rowspacing=15 cellspacing=10  border=1 bgcolor=orangered><tr bgcolor=DodgerBlue><th colspan=2>Leave Details</th></tr>"
                    + "<tr><th>Leave Code</th><td>" + EmailLeaveCode.Text.ToString() + "</td></tr> <tr><th>Employee Code</th><td>" + EmailEmpCode.Text.ToString() + " </td></tr>"
                    + "<tr><th>Employee Name</th><td>" + EmailEmpName.Text.ToString() + "</td></tr> <tr><th>Leave Application Date</th><td>"
                    + "<tr><th>Leave Application Status</th><td>" + EmailLeaveStatus.Text.ToString() + "</td></tr> <tr><th>Leave Type</th><td>" + EmailLeaveType.Text.ToString() + "</td></tr>"
                    + EmailLeaveAppDate.Text.ToString() + " </td></tr> <tr><th>Leave Start Date </th><td>" + EmailLeaveStDate.Text + "</td></tr>"
                    + "<tr><th>Leave End Date </th><td>" + EmailLeaveEndDate.Text + "</td></tr>"
                    + "<tr><th>Leave Approved/Rejected On</th><td>" + EmailLeaveApproveDate.Text + "</td></tr>"
                    + "<tr><th>Leave Approved/Rejected By </th><td>" + EmailApprovalMgr.Text.ToString() + "</td></tr> <tr><th>Leave Notes</th><td>" + EmailLeaveRemarks.Text.ToString() + "</td></tr>"
                    + "</table></div><br><font family=Verdana size=10 color=orangeRed>Please make login to HR Connect Portal see the details of other leave applications.</font><br><hr><br>"
                    + "<div style=width:70%; border:1pt solid orangered; padding:5pt;><img src=http://103.231.41.110/Logo/Sign.png width=auto height=auto alt=Signature></div>"
                    + "<br><hr><br><br><b>Regards</b><br>HR Connect Portal Team<br><br></div></body></html>";

                    var smtp = new SmtpClient
                    {
                        Host = "smtp-mail.outlook.com",
                        Port = 587,
                        EnableSsl = true,
                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        UseDefaultCredentials = true,
                        Credentials = new NetworkCredential("ramji.mishra@outlook.com", "Mishra@007")
                    };
                    using (var message = new MailMessage(fromAddress, toAddress)
                    {
                        IsBodyHtml = true,
                        Subject = subject,
                        Body = body,
                    })
                    {
                        smtp.Send(message);
                        lblErrorEmpLeaveRecord.ForeColor = System.Drawing.Color.Green;
                        lblErrorEmpLeaveRecord.Text = "Leave Application Status Email sent to employee.";
                    }
                }
        }catch (Exception ex)
        {
            lblErrorEmpLeaveRecord.Text = ex.ToString();
            empLeaveDetailsWindows.Show();
        }
            ////Response.Redirect(@"~/hrs/ListOfLeaves.aspx", false);
            //empLeaveDetailsWindows.Show();
    }
    protected void btnUpdateLeaveStatus_Click(object sender, EventArgs e)
    {
        UpdateEmployeeLeaveDt();
    }

    protected void drpLoadLeaveStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpLoadLeaveStatus.Items.Add("Pending");
        drpLoadLeaveStatus.Items.Add("InProcess");
        drpLoadLeaveStatus.Items.Add("OnHold");
        drpLoadLeaveStatus.Items.Add("Approved");
        drpLoadLeaveStatus.Items.Add("Rejected");
    }
}