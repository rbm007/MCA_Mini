﻿<%@ Page Title="" Language="C#" MasterPageFile="~/employees/EmployeeMasterPage.master" AutoEventWireup="true" CodeFile="generate_employee_payslip.aspx.cs" Inherits="add_new_employee_data" %>

<%@ Register Assembly="Microsoft.ReportViewer.WebForms, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" Namespace="Microsoft.Reporting.WebForms" TagPrefix="rsweb" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">New Employee Registration</div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="clkFirstProfileTab" class="EmpProfileTabPD tahHead" onclick="showhide3()" style="cursor: pointer;" title="Click to show information">Basic Information
            <span itemid="ram" class="right active"></span></h4>
                <table id="tblProperties" style="display: none !important; width: 100%; box-sizing: border-box !important; margin: 0 !important;">
                    <tbody style="width: 100%">
                        <tr>
                            <td colspan="3" style="text-align: center !important;">
                                <div style="border-bottom: 2pt solid orangered; display: flex; padding: 5pt !important;">
                                    <div style="width: 45% !important">
                                        <asp:Image ID="imgEmpProfile" ImageUrl="/../images/PP.png" Height="150px" Width="100px" runat="server" Style="border-radius: 50%; width: auto; border: dotted 1pt orangered;" />
                                        <br />
                                        <br />
                                        <asp:Label CssClass="ErrorMsg" Font-Bold="true" runat="server">Employee Photograph</asp:Label>
                                    </div>
                                    <div style="width: 45% !important; align-self: center;">
                                        <asp:Label runat="server" Font-Bold="true" Font-Size="Medium" ForeColor="OrangeRed" Text="Upload/Update Employee Latest Picture"></asp:Label>
                                        <asp:FileUpload class="EmpProfileTabPD" Style="padding: 3%;" ID="EmpProfilePic" runat="server" />
                                        <br />
                                        <br />
                                        <asp:Button class="LogBtn" ID="btnSaveImage" runat="server" Text="Save" Style="width: 85px; height: 30px !important" />
                                        <asp:Button class="LogBtn" ID="btnPreview" runat="server" Text="Preview" Style="width: 85px; height: 30px !important" />
                                        <asp:Label ID="Label1" runat="server" />
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>
                                <rsweb:ReportViewer ID="rptViewPaySlip" runat="server" Width="100%"></rsweb:ReportViewer>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <table id="tblSubmitArea" style="display: block; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td colspan="3">
                                <asp:Label ID="lblAddEmpErrorMsg" CssClass="ErrorMsg" runat="server"></asp:Label>
                                <asp:ValidationSummary ID="errorValidation" runat="server" ShowMessageBox="True" HeaderText="Please Enter following below details" ToolTip="Error: Mandatory Information" ShowSummary="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="3" style="text-align: center; width: 100% !important;">

                                <asp:Button ID="btnSaveEmpRegistration" Text="Confirm and Save" runat="server" class="LogBtn" />&nbsp;
                                <asp:Button ID="btnResetRegistrationData" Text="Reset Data" runat="server" class="LogBtn" />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <hr />
            </div>
        </div>
    </div>
    <div style="visibility: hidden; display: none;">
        // Employee Name, LeaveCode, EmpCode, Type, AppDate, StartDate, EndDate, TotalDays, Status, ApprovedBy, ApprovedDate, Remarks
        <asp:Label ID="EmailEmpName" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveCode" runat="server"></asp:Label>
        <asp:Label ID="EmailEmpCode" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveType" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveAppDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveStDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveEndDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveTotalDays" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveStatus" runat="server"></asp:Label>
        <asp:Label ID="EmailApprovalMgr" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveApproveDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveRemarks" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveEmailTo" runat="server"></asp:Label>
    </div>
</asp:Content>
<%-- Add content controls here --%>
