﻿<%@ Page Title="" Language="C#" MasterPageFile="~/employees/EmployeeMasterPage.master" AutoEventWireup="true" CodeFile="list_of_forms.aspx.cs" Inherits="comman_pages_leaveRecords" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div class="formMjr" style="width: 98% !important; padding: 2pt !important;" runat="server">
                        <table style="width: 100%; padding: 0 !important; margin: 0 !important; padding-top:1pt !important; padding-bottom:5pt !important; box-shadow: 0 10px 10px -8px #333 !important; height:20px;">
            <tbody>
<tr>
<td colspan="3" style="margin-bottom: 1%; font-size: 100%;  width: 150%; background-color: orangered;  color: white; text-align: center;  font-weight: 700;height: 30pt; font-size-adjust: 0.80;">List of Leave Applications</td>
                        </tr>
                </tbody>
            </table>
                
            <div class="clear"></div>
            <asp:GridView ID="grdViewLeaveRecords" Style="font-size: 12px; font-size-adjust: 0.88 !important;" CssClass="LeaveRecordsList" runat="server" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="3" CellSpacing="2" EnableModelValidation="True" OnSelectedIndexChanged="grdViewLeaveRecords_SelectedIndexChanged">
                <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                <HeaderStyle BackColor="orangered" Font-Bold="True" ForeColor="White" />
                <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                <RowStyle BackColor="white" ForeColor="orangered" />
                <SelectedRowStyle BackColor="cornsilk" Font-Bold="True" ForeColor="#fc4508" />
                <Columns>
                    <asp:TemplateField HeaderText="Leave No.">
                        <ItemTemplate>
                            <asp:Label ID="lblLeaveCodeGrd" runat="server" Text='<%#Eval("Leave Code")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Emp. Code">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpCodeGrd" runat="server" Text='<%#Eval("Employee Code")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Full Name">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpNameGrd" runat="server" Text='<%#Eval("Employee Name")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Applied On">
                        <ItemTemplate>
                            <asp:Label ID="lblLeaveAppDateGrd" runat="server" Text='<%# Eval("Application Date", "{0:dd MMM yyyy hh:mm:ss tt}") %>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <Columns>
                    <asp:TemplateField HeaderText="From">
                        <ItemTemplate>
                            <asp:Label ID="lblLeaveStartDtGrd" runat="server" Text='<%#Eval("Leave From", "{0:dd MMM yyyy}")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="To">
                        <ItemTemplate>
                            <asp:Label ID="lblLeaveEndDtGrd" runat="server" Text='<%#Eval("Leave Till", "{0:dd MMM yyyy}")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Updated On">
                        <ItemTemplate>
                            <asp:Label ID="lblLeaveModifiedDtGrd" runat="server" Text='<%#Eval("LastModifiedDate", "{0:dd MMM yyyy hh:mm:ss tt}")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <asp:Label ID="lblLeaveStatusGrd" runat="server" Text='<%#Eval("LeaveStatus")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:ButtonField Text="View" ControlStyle-Font-Underline="true" ControlStyle-ForeColor="Blue" ButtonType="Link" CommandName="Select" HeaderText="Actions" />
                </Columns>
            </asp:GridView>

            <asp:LinkButton Text="" ID="lblViewSelectedGridData" runat="server">
            </asp:LinkButton>
           
           
        </div>
    </div>
    <%-- Pop Up for Leave details --%>
    <cc1:ModalPopupExtender ID="empLeaveDetailsWindows" runat="server" OkControlID="btnBack" PopupControlID="pnlLeaveRecordDetails" TargetControlID="lblViewSelectedGridData">
    </cc1:ModalPopupExtender>
    <%--Style="display: none;"--%>
    <asp:Panel ID="pnlLeaveRecordDetails" runat="server" Class="LeaveDetailsPanel" Style="display: none;">
            <div class="formMjr multiAccordion" style="width:95% !important; padding-top: 5% !important; padding: 0;">
                    <table id="tblProperties" class="tableDt" style="width: 100% !important; margin: 0 auto !important; display: inline-block;">
                        <tbody>
                            <tr>
                                <td colspan="10" style="width: 100%; background-color: orangered; color: white; text-align: center; font-weight: 700; box-shadow: 0 10px 10px -8px #333;">

                                    <%=Convert.ToString("Leave Application Of: " + Session["EmpName"].ToString())%>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                            </tr>
                            <tr>

                                <td class="tableTDFields">Leave Code</td>
                                <td>
                                    <asp:Label ID="ELeaveCodeNumber" runat="server"></asp:Label></td>
                            </tr>

                            <tr>
                                <td class="tableTDFields">Employee Code</td>
                                <td>
                                    <asp:Label ID="ECodeLeaveDetails" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Employee Name</td>
                                <td>
                                    <asp:Label ID="ENameLeaveDetails" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Employee Department</td>
                                <td>
                                    <asp:Label ID="EDeptLeaveDetails" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Employee Designation</td>
                                <td>
                                    <asp:Label ID="EDesgLeaveDetails" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>

                            </tr>
                            <tr>
                                <td class="tableTDFields">Employee Location</td>
                                <td>
                                    <asp:Label ID="ELocationLeaveDetails" runat="server"></asp:Label></td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Leave Application Date</td>
                                <td>
                                    <asp:Label ID="ECodeLeaveAppliedOn" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Leave Start Date</td>
                                <td>
                                    <asp:Label ID="ECodeLeaveStartDt" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Leave End Date</td>
                                <td>
                                    <asp:Label ID="ECodeLeaveEndDt" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Leave Type</td>
                                <td>
                                    <asp:Label ID="ECodeLeaveType" runat="server"></asp:Label></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Total Leave Days</td>
                                <td>
                                    <asp:Label ID="ELeaveTotalDays" runat="server"></asp:Label>
                                    <asp:Label ID="Label1" runat="server"> Days</asp:Label>
                                </td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Balance Leave Days</td>
                                <td>
                                    <asp:Label ID="lblTotalBalanceLeave" runat="server"></asp:Label>
                                    <asp:Label ID="Label3" runat="server"> Days</asp:Label>
                                </td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Reason For Leave</td>
                                <td>
                                    <asp:Label ID="ELeaveReason" runat="server"></asp:Label>

                                </td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Current Leave Status</td>
                                <td>
                                    <asp:Label Style="font-weight: 700; font-size: medium; color: orangered;" ID="drpLeaveStatus" runat="server"></asp:Label>

                                </td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Update Leave Status</td>
                                <td style="width: 65%">
                                    <asp:DropDownList runat="server" ID="drpLoadLeaveStatus" Style="float: left; position: inherit; cursor: pointer;" class="fixLength" OnSelectedIndexChanged="drpLoadLeaveStatus_SelectedIndexChanged">
                                        <asp:ListItem>Pending</asp:ListItem>
                                        <asp:ListItem>InProcess</asp:ListItem>
                                        <asp:ListItem>OnHold</asp:ListItem>
                                        <asp:ListItem>Approved</asp:ListItem>
                                        <asp:ListItem>Rejected</asp:ListItem>
                                    </asp:DropDownList>
                                </td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="tableTDFields">Leave Remarks / Notes</td>
                                <td>
                                    <textarea id="txtLeaveRemarksNotes" cols="20" rows="3" runat="server" style="resize: none; width: 100% !important;"></textarea>
                                </td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="width: 100%; color: white; text-align: center; font-weight: 700;" colspan="4">
                                    <asp:Button ID="btnUpdateLeaveStatus" runat="server" Text="Update Leave Status" CssClass="LogBtn" OnClick="btnUpdateLeaveStatus_Click" />&nbsp;&nbsp;
                                    <asp:Button ID="btnBack" runat="server" Text="Back To Leave Records" CssClass="LogBtn" />
                                </td>
                            </tr>
                           
                            <tr>
                                <td colspan="10">
                                    <asp:Label ID="lblErrorEmpLeaveRecord" Visible="true" CssClass="ErrorMsg" runat="server">
                                    </asp:Label></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

        <div style="visibility: hidden; display: none;">
            // Employee Name, LeaveCode, EmpCode, Type, AppDate, StartDate, EndDate, TotalDays, Status, ApprovedBy, ApprovedDate, Remarks
        <asp:Label ID="EmailEmpName" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveCode" runat="server"></asp:Label>
            <asp:Label ID="EmailEmpCode" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveType" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveAppDate" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveStDate" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveEndDate" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveTotalDays" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveStatus" runat="server"></asp:Label>
            <asp:Label ID="EmailApprovalMgr" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveApproveDate" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveRemarks" runat="server"></asp:Label>
            <asp:Label ID="EmailLeaveEmailTo" runat="server"></asp:Label>
         

        </div>
    </asp:Panel>
</asp:Content>
<%-- Add content controls here --%>
