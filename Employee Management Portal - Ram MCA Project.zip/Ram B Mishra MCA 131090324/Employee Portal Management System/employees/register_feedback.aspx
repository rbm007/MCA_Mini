﻿<%@ Page Title="" Language="C#" MasterPageFile="~/employees/EmployeeMasterPage.master" AutoEventWireup="true" CodeFile="register_feedback.aspx.cs" Inherits="comman_pages_applyleave" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="applyLeaveSalContain" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Employee Leave Application Registration</div>
        <div class="formMjr multiAccordion">
            <div class="empProfileSummary" runat="server">
                <table id="paytblProperties" style="width: 100%; padding: 3% !important; box-sizing:border-box !important; margin: 0 !important;">
                    <tbody style="width: 100%">
                        <tr>
                            <td colspan="3" style="box-shadow: 0 10px 10px -8px #333; margin-bottom: 1%; font-size: 100%; width: 150%; background-color: orangered; color: white; text-align: center; font-weight: 700;">New Leave Application
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                        </tr>

                        <tr>
                            <td class="tableTDFields">Employee Code</td>
                            <td>:</td>
                            <td>
                                <asp:Label ID="lblLeaveEmpCode" runat="server"></asp:Label></td>
                           
                        </tr>
                        <tr>
                            <td class="tableTDFields">Employee Name</td>
                            <td>:</td>
                            <td>
                                <asp:Label ID="lblLeaveEmpName" runat="server"></asp:Label></td>
                        </tr>
                        <tr>

                            <td class="tableTDFields">Total Balance Paid Leave(s)</td>
                            <td>:</td>
                            <td style="font-weight: 600 !important;">
                                <asp:Label ID="lblBalancePL" runat="server"></asp:Label></td>
                        </tr>
                        <tr>
                            <td class="tableTDFields">Total Balance Cumulative Leave(s)</td>
                            <td>:</td>
                            <td style="font-weight: 600 !important;">
                                <asp:Label ID="lblBalanceCL" runat="server"></asp:Label></td>
                        </tr>
                        <tr>
                            <td class="tableTDFields">Leave Type</td>
                            <td>:</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="cmbLeaveType" runat="server" class="fixLength">
                                        <asp:ListItem>Basic Leave</asp:ListItem>
                                        <asp:ListItem>Paid Leave</asp:ListItem>
                                        <asp:ListItem>Cumulative Leave</asp:ListItem>
                                        <asp:ListItem>Sick Leave</asp:ListItem>
                                        <asp:ListItem>Emergency Leave</asp:ListItem>
                                        <asp:ListItem>Planned Leave</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="tableTDFields">Start Date of Leave</td>
                            <td>:</td>
                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="dtStartLeave" runat="server" Height="30" Width="80%" ToolTip="Select Start Date for Leave" ReadOnly="False" />
                                    <asp:RequiredFieldValidator ID="LStartDt" runat="server" ErrorMessage="Please Enter Start Date of Leave.." ControlToValidate="dtStartLeave" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>

                            </td>
                        </tr>
                        <tr>
                            <td class="tableTDFields">End Date of Leave</td>
                            <td>:</td>
                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="dtEndLeave" runat="server" Height="30" Width="80%" ToolTip="Select End Date for Leave" ReadOnly="False" />
                                    <asp:RequiredFieldValidator ID="ELastDt" runat="server" ErrorMessage="Please Enter End Date of Leave." ControlToValidate="dtEndLeave" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr runat="server" id="HDFD">
                            <td class="tableTDFields">Do you want apply with halfday
                            </td>
                            <td>:</td>
                            <td style="cursor: pointer">
                                <asp:RadioButton runat="server" Text="Full Day Leave" Style="cursor: pointer !important;" ID="rdoFullDay" GroupName="leaveCont" Checked="true" CssClass="EmpProfileTabPD" />
                                &nbsp;
                                <asp:RadioButton runat="server" Text="Half Day Leave" Style="cursor: pointer !important;" ID="rdoHalfDay" GroupName="leaveCont" Checked="false" CssClass="EmpProfileTabPD" />
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>
                                <asp:HyperLink class="btnCountLeaveDays" ID="btnCt" Text="Count Leave Days" runat="server" OnClick="btnCt_Click" /></td>
                        </tr>
                        <tr id="hideRow" runat="server">
                            <td class="tableTDFields">Applying leave for total </td>
                            <td>:</td>
                            <td>
                                <asp:Label Style="color: orangered !important; font-weight: 600;" ID="lblCountLeaveDys" runat="server"></asp:Label>
                                <asp:Label Text="Days" Style="color: orangered !important; font-weight: 600;" ID="Label1" runat="server"></asp:Label>
                            </td>
                        </tr>
                        <tr>

                            <td class="tableTDFields">Last Date of Working</td>
                            <td>:</td>
                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox ID="dtLastWorkDay" class="setCalender" runat="server" Height="30" Width="80%" ToolTip="Select Last Working Date" ReadOnly="False" />
                                    <asp:RequiredFieldValidator ID="LDWorking" runat="server" ErrorMessage="Please Enter Last Date of Working." ControlToValidate="dtLastWorkDay" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>

                        </tr>
                        <tr>
                            <td class="tableTDFields">Reason for Leave</td>
                            <td>:</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:TextBox ID="txtLeaveReason" runat="server" class="fixLength" TextMode="SingleLine" />
                                    <asp:RequiredFieldValidator ID="leaveRes" runat="server" ErrorMessage="Please Enter relevant reason  for Leave." ControlToValidate="txtLeaveReason" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="tableTDFields">Mobile Number while on Leave</td>
                            <td>:</td>
                            <td>
                                <asp:TextBox ID="txtLeaveMobile" runat="server" class="fixLength" />
                                <asp:RequiredFieldValidator ID="leavMob" runat="server" ErrorMessage="Please Enter Mobile Number reason  for Leave." ControlToValidate="txtLeaveReason" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td class="tableTDFields">Email CC of Leave Application To</td>
                            <td>:</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpLeaveEmailCC" AutoPostBack="true" runat="server" Style="cursor: pointer;" class="fixLength" OnSelectedIndexChanged="drpLeaveEmailCC_SelectedIndexChanged">
                                    </asp:DropDownList>
                                    <asp:RequiredFieldValidator ID="LeaveEmailCC" runat="server" ErrorMessage="Please Select relevant contact name for Leave." ControlToValidate="drpLeaveEmailCC" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td></td>
                            <td>
                                <asp:Label ID="lblLeaveCCEmailAddress" runat="server"></asp:Label></td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <asp:Label ID="lblLeaveErrorMsg" CssClass="ErrorMsg" runat="server"></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center !important;">

                                <asp:Button ID="btnApplyNewLeave" Text="Apply For Leave" runat="server" OnClick="btnApplyNewLeave_Click" class="LogBtn" />&nbsp;
                                <asp:Button ID="btnResetLeaveData" Text="Clear Data" runat="server" class="LogBtn" OnClick="btnResetLeaveData_Click" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <hr />
            <asp:Label ID="LeaveError" runat="server" CssClass="ErrorMsg"></asp:Label>
        </div>
    </div>
</asp:Content>
