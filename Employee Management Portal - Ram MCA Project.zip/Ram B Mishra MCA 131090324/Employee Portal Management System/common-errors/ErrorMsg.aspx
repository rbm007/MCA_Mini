﻿<%@ Page Title="" Language="C#" MasterPageFile="~/common-errors/CustomeErrorMaster.master" AutoEventWireup="true" CodeFile="ErrorMsg.aspx.cs" Inherits="common_errors_ErrorMsg" %>

<asp:Content ID="Content1" ContentPlaceHolderID="sessionExpiredErr" Runat="Server">
            <div class="ErrorMsg" runat="server">
            <div class="ntraining" style="top:25%; text-align:center !important; font-size:100%; padding:20px; margin-top:10% !important;">

            <table style="width:100%;">

                <tr>
                    <td>

                    </td>
                </tr>
                <tr>
                    <td style="width:100% !important; font-size:100% !important; font-size-adjust:0.70 !important;" class="EmpProfileTabPD" >Your session has been expired.</td>
                </tr>
            <tr>
            <td style="text-align:center; padding:20px; width:80%; margin:0 auto;">
            <br />
            <br />
            <h3>
            <a class="ErrorMsg" style="text-decoration:underline; font-size:100% !important; font-size-adjust:0.70 !important;" href="/../welcome/Login.aspx">Click Here to Login again.</a> 
            </h3>
            </td>
            </tr>
                <tr>
                    <td>
                        <asp:Image ImageUrl="/../images/sessionExpiredImg.png" AlternateText="Session Expired"  runat="server"/>
                    </td>
                </tr>
            </table>
                </div>
            </div>

</asp:Content>

