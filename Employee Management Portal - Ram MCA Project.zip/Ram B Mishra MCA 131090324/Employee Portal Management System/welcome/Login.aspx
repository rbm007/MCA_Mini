﻿<%@ Page Language="C#" AutoEventWireup="true" MasterPageFile="~/welcome/MasterPage.master" CodeFile="Login.aspx.cs" Inherits="employee_portal_login" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ContentPlaceHolderID="MyMenu" runat="server"></asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="container" runat="server">
        <div id="LogBox" class="loginBox" runat="server" style="width: 50% !important">
            <table runat="server" id="tblForgotLogin" style="width: 100%; margin: 0 auto;">
                <tr style="text-align: center; height: auto;">
                    <td colspan="3" style="padding: 0 !important; margin: 0 !important;">
                        <h1 class="WelcomeLogin" style="box-shadow: 0 10px 10px -8px #333;">Staff Member Login</h1>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                </tr>
                <tr style="text-align: center;">
                    <td style="text-align: center;" colspan="2">
                        <asp:TextBox ID="txtLoginUserName" placeholder="emailaddres@mail.com"
                            Style="height: auto !important; padding-bottom: 3% !important; padding-right: 3% !important; padding-top: 3% !important;" CssClass="txtBoxLogin setUTxtIcon" runat="server" onpaste="return false;" MaxLength="75" />
                        <asp:RequiredFieldValidator Display="none" ID="reqValidLogin" ControlToValidate="txtLoginUserName" SetFocusOnError="true"
                            runat="server" ErrorMessage="Enter Username"></asp:RequiredFieldValidator>
                    </td>
                </tr>
                <tr style="text-align: center;">
                    <td style="text-align: center;" colspan="2">
                        <asp:TextBox ID="txtLoginPassword" placeholder="your password"
                            Style="height: auto !important; padding-bottom: 3% !important; padding-right: 3% !important; padding-top: 3% !important;" CssClass="txtBoxLogin setPTxtIcon" runat="server" TextMode="Password" onpaste="return false;" MaxLength="75" />
                        <asp:RequiredFieldValidator Display="none" ID="reqValidLoginPwd" ControlToValidate="txtLoginPassword" SetFocusOnError="true"
                            runat="server" ErrorMessage="Enter Password"></asp:RequiredFieldValidator>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: left;">
                        <asp:Label ID="lblError" runat="server" ForeColor="Red"></asp:Label>
                        <asp:Label ID="UFullName" runat="server" Visible="false"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;" colspan="3">
                        <asp:Button ID="btnLogin" Text="Login" runat="server" class="LogBtn" OnClick="btnLogin_Click" />
                        <asp:Button ID="btnReset" Text="Clear" runat="server" class="LogBtn" OnClick="btnReset_Click" />
                        <asp:Button ID="btnSubmitForgotPassword" Text="Forgot Password" runat="server" class="LogBtn" OnClick="btnSubmitForgotPassword_Click" /></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: left;"></td>
                </tr>
            </table>
        </div>
        <asp:ValidationSummary ID="errSumm" ShowMessageBox="true" ShowSummary="false" DisplayMode="BulletList" EnableTheming="true" BackColor="OrangeRed"
            ForeColor="White" BorderStyle="Solid" runat="server" HeaderText="Please enter below details" />
    </div>
    <div runat="server" visible="false">
        <asp:Label ID="forName" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forEmail" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forPass" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forMobile" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forUName" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="ForDateTime" Visible="false" runat="server"></asp:Label>
        <asp:Label ID="forFirstName" Visible="false" runat="server"></asp:Label>
    </div>
</asp:Content>