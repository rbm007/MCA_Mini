﻿using System;
using System.Diagnostics;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;

public partial class employee_portal_login : System.Web.UI.Page
{
    con_properties LCon = new con_properties();
    //SqlConnection LoginCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HCUserLogin"].ToString());
    DataSet dtSet;
    SqlDataAdapter da;
    DataTable dt;
    SqlCommand cmd;
    string strLoginQuery;
    string LogUser;
    string loggedUserFullName;
    string logPwd;
    int rowcount;

    protected void Page_Load(object sender, EventArgs e)
    {
        Session.RemoveAll();
        readyLogin();
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        tryLogin();
    }

    public void tryLogin()
    {
        string un = txtLoginUserName.Text;
        string pwd = txtLoginPassword.Text;

        if (txtLoginUserName.Text != null && txtLoginPassword.Text != null)
        {
            try
            {
                strLoginQuery = "select EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName As EmpName,EmpCode,EmpEmail,EmpPassword,EmpRoleID from HRA_Employee with(nolock) where EmpEmail=@U and EmpPassword=@P";
                da = new SqlDataAdapter(strLoginQuery, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                da.SelectCommand.Parameters.AddWithValue("@U", un.ToString());
                da.SelectCommand.Parameters.AddWithValue("@P", pwd.ToString());
                LCon.con_open();
                dtSet = new DataSet();
                da.Fill(dtSet, "HRA_Employee");
                LCon.close_con();
                rowcount = dtSet.Tables["HRA_Employee"].Rows.Count;

                LogUser = dtSet.Tables["HRA_Employee"].Rows[0]["EmpEmail"].ToString();
                logPwd = dtSet.Tables["HRA_Employee"].Rows[0]["EmpPassword"].ToString();
                loggedUserFullName = dtSet.Tables["HRA_Employee"].Rows[0]["EmpName"].ToString();

                if (LogUser == txtLoginUserName.Text.ToString() && logPwd == txtLoginPassword.Text.ToString())
                {
                    Session["EmpEmail"] = LogUser.ToString();
                    Session["EmpName"] = loggedUserFullName.ToString();
                    //1  Employee
                    //2. HR
                    //3. Managers
                    //4. Admins 

                    if (dtSet.Tables["HRA_Employee"].Rows[0]["EmpRoleID"].ToString() == "1")
                        Response.Redirect(@"~/employees/Default.aspx", false);
                    else if (dtSet.Tables["HRA_Employee"].Rows[0]["EmpRoleID"].ToString() == "2")
                        Response.Redirect(@"~/hrs/Default.aspx", false);
                    else if (dtSet.Tables["HRA_Employee"].Rows[0]["EmpRoleID"].ToString() == "3")
                        Response.Redirect(@"~/managers/Default.aspx", false);
                    else if (dtSet.Tables["HRA_Employee"].Rows[0]["EmpRoleID"].ToString() == "4")
                        Response.Redirect(@"~/admins/Default.aspx", false);
                }
                else
                {
                    lblError.Text = "Invalid Username And Password";
                    Response.Redirect(@"~/welcome/Login.aspx");
                    btnReset_Click(null, null);
                }

            }
            catch (Exception ex)
            {


                lblError.Text = "Unable to connect to server. Please try again.<br/>" + ex.Message.ToString();
                lblError.Visible = true;
            }
        }
        else
        {
            Response.Write("<script>alert('Please enter valid username/password')</script>");
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        readyLogin();
    }

    public void readyLogin()
    {

        txtLoginUserName.Focus();
        lblError.Text = null;
        

    }
  

    protected void sendUserNamePwd()
    {
        string selectTicket;

        try
        {
            selectTicket = "select top 1 EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName As EmpName,EmpFirstName,"
                + " EmpCode, EmpEmail, EmpPassword, EmpMobile from HRA_Employee with(nolock) WHERE EmpEmail=@eid";


            da = new SqlDataAdapter(selectTicket, (ConfigurationManager.ConnectionStrings["HRAString"].ToString()));
            da.SelectCommand.Parameters.AddWithValue("@eid", txtLoginUserName.Text.ToString());
            dtSet = new DataSet();
            LCon.con_open();
            da.Fill(dtSet, "HRA_Employee");


            if (dtSet.Tables["HRA_Employee"].Rows.Count > 0)
            {
                forName.Text = string.Format("{0}", dtSet.Tables["HRA_Employee"].DefaultView[0]["EmpName"]);
                forEmail.Text = string.Format("{0}", dtSet.Tables["HRA_Employee"].DefaultView[0]["EmpEmail"]);
                forPass.Text = string.Format("{0}", dtSet.Tables["HRA_Employee"].DefaultView[0]["EmpPassword"]);
                forMobile.Text = string.Format("{0}", dtSet.Tables["HRA_Employee"].DefaultView[0]["EmpMobile"]);
                forUName.Text = string.Format("{0}", dtSet.Tables["HRA_Employee"].DefaultView[0]["EmpCode"]);
                forFirstName.Text = string.Format("{0}", dtSet.Tables["HRA_Employee"].DefaultView[0]["EmpFirstName"]);




                var fromAddress = new MailAddress("ramji.mishra@outlook.com", "HR Connect Portal");
                var toAddress = new MailAddress(txtLoginUserName.Text.ToString(), forFirstName.Text.ToString());
                const string fromPassword = "Mishra@007";
                const string subject = "HR Connect : Login ID and Password";
                string body = "<html><body width=100% font-family=verdana>"
                + "<div style=width:auto; color:black;>Dear " + forFirstName.Text.ToString() + ",<br><br>Greetings! from HR Connect Portal,"
                + "<br><br><desc>We have received Login Assistant request from you. Please find below your Login details.<br><br>"
                + "If you did not request for password, Kindly Call IT Team or <a href=mailto:hrconnectportal@gmail.com> Send Email <b>  to hrconnectportal@gmail.com</b> ASAP.<br><br>"
                + "<table style=padding:10px; font-family=verdana; font-size=10px; align=left width=100% cellpadding=2 rowpadding=3 cellspacing=2 border=2 bordercolor=black>"
                + "<tr><td font-color=white><b>Your Name: </b></td><td>" + forName.Text.ToString() + "</td></tr>"
                + "<tr><td font-color=white><b>Registered Email ID: </b></td><td>" + forEmail.Text.ToString() + "</td></tr>"
                + "<tr><td font-color=white><b>Login Username: </b></td><td>" + forUName.Text.ToString() + "</td></tr>"
                + "<tr><td font-color=white><b>Your Password: </b></td><td><b><i>" + forPass.Text.ToString() + "</i></b></td></tr>"
                + "<tr><td font-color=white><b>Registered Mobile: </b></td><td>" + forMobile.Text.ToString() + "</td></tr>"
                + "<tr><td font-color=white><b>Password Requested On: </b></td><td>" + DateTime.Now.ToString() + "</td></tr>"
                + "<tr><td colspan=2><big>Kindly make login again, If you wish to provide feedback or to use other online services.</big></b></td></tr></table>"
                + "<br><hr><br><br><b>Regards</b><br>HR Connect Portal Team<br><br></div></body></html>";
                
                var smtp = new SmtpClient
                {
                    Host = "smtp-mail.outlook.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = true,
                    Credentials = new NetworkCredential("ramji.mishra@outlook.com", "Mishra@007")
                };
                using (var message = new MailMessage(fromAddress, toAddress)
                {
                    IsBodyHtml = true,
                    Subject = subject,
                    Body = body,
                })
                {
                    smtp.Send(message);
                    lblError.ForeColor = System.Drawing.Color.Green;
                    lblError.Text = "Login credentials have been senet to your registred Email ID.";
                }

                //MailMessage msg = new MailMessage();
                //SmtpClient client = new SmtpClient("smtp.gmail.com");
                //msg.From = (new MailAddress("hrconnectportal@gmail.com"));
                //client.UseDefaultCredentials = false;
                //client.Port = 587;
                //client.Credentials = new NetworkCredential();
                //msg.To.Add(txtLoginUserName.Text.ToString());
                //msg.Subject = "Login ID and Password for Employee Code :" + txtLoginUserName.Text.ToString();
                //msg.IsBodyHtml = true;
                //client.EnableSsl = true;    
                //client.Send(msg);
        }
      
            else
            {
                lblError.Text = "Details not matched. Please try with correctdetails";
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.ToString();
        }
        LCon.close_con();
    }

    //{
    //    //Host = ConfigurationManager.AppSettings["smtpServer"],
    //    //Port = Convert.ToInt32(ConfigurationManager.AppSettings["smtpPort"]),
    //    EnableSsl = true,
    //    //DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network,
    //    //UseDefaultCredentials = false,
    //    //Credentials = new NetworkCredential(ConfigurationManager.AppSettings["smtpUser"], ConfigurationManager.AppSettings["smtpPass"])
    //};
    protected void btnSubmitForgotPassword_Click(object sender, EventArgs e)
    {
        if (txtLoginUserName.Text.ToString() != null)
        {
            sendUserNamePwd();  
        }
        else
        {
            lblError.Text = "Please Enter Email ID to recieve Password";
            txtLoginUserName.Focus();
            txtLoginPassword.Text = "";
            txtLoginUserName.Text = "";
        }
    }
}