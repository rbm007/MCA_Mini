﻿<%@ Page Title="" Language="C#" MasterPageFile="~/managers/ManagerMasterPage.master" AutoEventWireup="true" CodeFile="leaveRecords.aspx.cs" Inherits="comman_pages_leaveRecords" %>

<%-- Add content controls here --%>
