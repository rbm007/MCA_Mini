﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Security.Cryptography;


public partial class Home : System.Web.UI.Page
{

    string _UNameText;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (Session["ELoginName"] != null && Convert.ToString(Session["ELoginName"]) != "")
                {
                    _UNameText = Convert.ToString(Session["ELoginName"]);
                    Session["ELoginName"] = _UNameText;
                    UNameText.Text = "<font color=black>Logged As : </font> [ " + _UNameText.ToString() + " ]";
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
                Session.Clear();
                Response.Redirect("~/Login.aspx");
            }
        }
    }
}