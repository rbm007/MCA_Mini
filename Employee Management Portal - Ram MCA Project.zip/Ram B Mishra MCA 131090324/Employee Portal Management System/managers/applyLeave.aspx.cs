﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class comman_pages_applyleave : System.Web.UI.Page
{

    string _UNameText;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (Session["ELoginName"] != null && Convert.ToString(Session["ELoginName"]) != "")
                {
                    _UNameText = Convert.ToString(Session["ELoginName"]);
                    Session["ELoginName"] = _UNameText;
                    UNameText.Text = "Welcome! " + _UNameText.ToString();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
                Response.Redirect("Login.aspx");
            }
        }
    }
}