﻿<%@ Page Title="" Language="C#" MasterPageFile="~/managers/ManagerMasterPage.master" AutoEventWireup="true" CodeFile="myprofile.aspx.cs" Inherits="comman_pages_myprofile" %>

<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="/../images/logonew.jpg" align="left" height="50" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="#fc4508"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTime.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>
<asp:Content ContentPlaceHolderID="pageDataContainer" runat="server" Visible="true" ID="empProfile">
    <div class="ntraining" runat="server">
        <div class="profileTopBanner" runat="server">Employee Profile System Manager</div>
        
        <div class="clear"></div>
        
        <div class="empProfileSideBar" runat="server" id="empPSideBar">
            <table>
                <tr>
                    <td>Overview</td>
                </tr>
                <tr>
                    <td>Personal Details</td>
                </tr>
                <tr>
                    <td>Contact Details</td>
                </tr>
                <tr>
                    <td>Employement Details</td>
                </tr>
                <tr>
                    <td>Leaves</td>
                </tr>
                <tr>
                    <td>Basic Information</td>
                </tr>
                <tr>
                    <td>Settings</td>
                </tr>
            </table>
        </div>

    </div>

</asp:Content>
<%-- Add content controls here --%>
