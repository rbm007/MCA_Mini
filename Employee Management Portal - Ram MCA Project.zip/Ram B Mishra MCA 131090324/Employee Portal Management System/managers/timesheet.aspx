﻿<%@ Page Title="" Language="C#" MasterPageFile="~/managers/ManagerMasterPage.master" AutoEventWireup="true" CodeFile="timesheet.aspx.cs" Inherits="comman_pages_timesheet" %>

<%-- Add content controls here --%>
