﻿<%@ Page Title="" Language="C#" MasterPageFile="~/managers/ManagerMasterPage.master" AutoEventWireup="true" CodeFile="leaveApprovals.aspx.cs" Inherits="managers_leaveApprovals" %>

<%-- Add content controls here --%>
