﻿<%@ Page Title="" Language="C#" MasterPageFile="~/managers/ManagerMasterPage.master" AutoEventWireup="true" CodeFile="payslips.aspx.cs" Inherits="comman_pages_payslips" %>

<%-- Add content controls here --%>
