﻿<%@ Page Title="" Language="C#" MasterPageFile="~/managers/ManagerMasterPage.master" AutoEventWireup="true" CodeFile="applyleave.aspx.cs" Inherits="comman_pages_applyleave" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>


<asp:Content ContentPlaceHolderID="MainHead" runat="server">
    <div class="HeadLogo" runat="server">
        <img src="/../images/logonew.jpg" align="left" height="50" />
        <div class="welcomeUser" runat="server" id="welUname">
            <asp:Label ID="UNameText" runat="server" Text="" Font-Bold="True" ForeColor="DeepSkyBlue"> </asp:Label>
            <hr />
            <b>Date:</b> [ <%=DateTime.Now%> ]
        </div>
    </div>
    <div class="clear">
    </div>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">

    <div class="clear" runat="server">
    </div>
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div class="clear" runat="server"></div>

        <br />
        <div class="welcomeText">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New Leave Application</div>
        <div class="ntraining" runat="server">
            <div class="leaveTable" runat="server">
            <table>

            <tr>
            <td></td>
            <td></td>
            <td></td>

            </tr>
            <tr>
            <td>Employee Code</td>
            <td>:</td>
            <td><asp:Label id="lblLeaveEmpCode" runat="server"></asp:Label></td>
            </tr>

            <tr>
            <td>Employee Name</td>
            <td>:</td>
            <td><asp:Label id="lblLeaveEmpName" runat="server"></asp:Label></td>
            </tr>

            <tr>
            <td>Leave Type</td>
            <td>:</td>
            <td>
            <div class="fixLength" runat="server">
                <asp:DropDownList ID="cmbTrainingType" runat="server" class="fixLength">
                    <asp:ListItem>Basic Leave</asp:ListItem>
                    <asp:ListItem>Paid Leave</asp:ListItem>
                    <asp:ListItem>Cumulative Leave</asp:ListItem>
                    <asp:ListItem>Sick Leave</asp:ListItem>
                    <asp:ListItem>Emergency Leave</asp:ListItem>
                    <asp:ListItem>Planned Leave</asp:ListItem>
                </asp:DropDownList>
            </div>
            </td>
            </tr>


            <tr>

            <td>Start Date of Leave</td>
            <td>:</td>
            <td>
          <div class="fixLength" runat="server">
                <cc1:CalendarExtender TargetControlID="dtStartLeave" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy"></cc1:CalendarExtender>
                <%--<cc1:MaskedEditExtender ID="dateTo" runat="server" TargetControlID="dtTo" Mask="99/AAA/9999 99:99" MaskType="DateTime" UserDateFormat="DayMonthYear"></cc1:MaskedEditExtender>--%>
                <asp:TextBox ID="dtStartLeave" runat="server" Height="30" Width="100%" ToolTip="eg. 15-Jan-2017" ReadOnly="False" />
            </div>
            

            </td>
            </tr>

            <tr>
            <td>End Date of Leave</td>
            <td>:</td>
            <td>
            <div class="fixLength" runat="server">
                <cc1:CalendarExtender TargetControlID="dtEndLeave" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy"></cc1:CalendarExtender>
                <%--<cc1:MaskedEditExtender ID="dateTo" runat="server" TargetControlID="dtTo" Mask="99/AAA/9999 99:99" MaskType="DateTime" UserDateFormat="DayMonthYear"></cc1:MaskedEditExtender>--%>
                <asp:TextBox ID="dtEndLeave" runat="server" Height="30" Width="100%" ToolTip="eg. 15-Jan-2017" ReadOnly="False" />
            </div>
            </td>
            </tr>

            <tr>
            <td>Last Date of Working</td>
            <td>:</td>
            <td>
            <div class="fixLength" runat="server">
                <cc1:CalendarExtender TargetControlID="dtLastDateWork" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy ddddd"></cc1:CalendarExtender>
                <%--<cc1:MaskedEditExtender ID="dateTo" runat="server" TargetControlID="dtTo" Mask="99/AAA/9999 99:99" MaskType="DateTime" UserDateFormat="DayMonthYear"></cc1:MaskedEditExtender>--%>
                <asp:TextBox ID="dtLastDateWork" runat="server" Height="30" Width="100%" ToolTip="eg. 15-Jan-2017" ReadOnly="False" />
            </div>
            </td>
            </tr>
            <tr>
            <td>Reason for Leave</td>
            <td>:</td>
            <td><div class="fixLength" runat="server">
                <asp:TextBox ID="txtLeaveReason" runat="server" class="fixLength" TextMode="MultiLine" Height="60px" />
            </div></td>
            </tr>

            <tr>
            <td>Mobile Number while on Leave</td>
            <td>:</td>
            <td>
            <br />
            <div class="fixLength" runat="server" style="margin-top:10pt;">
                <asp:TextBox ID="txtLeaveMobile" runat="server" class="fixLength" />
            </div>
            </td>
            </tr>


            </table>
            </div>


            <hr />

        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</asp:Content>
