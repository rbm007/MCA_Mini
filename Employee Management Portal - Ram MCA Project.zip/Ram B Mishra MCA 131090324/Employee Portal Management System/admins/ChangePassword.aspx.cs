﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;

public partial class hrs_ChangePassword : System.Web.UI.Page
{
    con_properties con_CC = new con_properties();
    SqlDataAdapter sda;
    DataSet dst;
    string UpdatePassword;
    string getEmpCode;
    string UpdateEmpPassword;
    int getCount;
    string LoggedUserEmpCode;
    string updateEmpPwd;
    string LoggedUser;
    string oldPassword;

    protected void Page_Load(object sender, EventArgs e)
    {
        //btnResetPassChange_Click(null, null);
        getEmpCodeForPassword();
        txtOldPassword.Focus();
    }

    protected void btnUpdatePassword_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtEmpConfirmNewPassword.Text != "" || txtEmpNewPassword.Text != "" || txtOldPassword.Text != "")
            {
                changeEmpPassword();
            }
            else
            {
                lblErrorPwdChange.Text = "Please enter all required mandatory details to proceed.";
            }
        }
        catch (Exception ex)
        {
            lblErrorPwdChange.Text = "Secure connection to web failed";
        }
    }
    protected void btnResetPassChange_Click(object sender, EventArgs e)
    {
        txtOldPassword.Text = "";
        txtEmpNewPassword.Text = "";
        txtEmpConfirmNewPassword.Text = "";
        txtOldPassword.Focus();
        lblErrorPwdChange.Text = "";
    }

    public void getEmpCodeForPassword()
    {
        try
        {
            getEmpCode = "select EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName As EmpName,EmpCode,EmpEmail,EmpPassword,EmpRoleID from HRA_Employee with(nolock) where EmpEmail=@U";
            sda = new SqlDataAdapter(getEmpCode, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            sda.SelectCommand.Parameters.AddWithValue("@U", Session["EmpEmail"].ToString());
            con_CC.con_open();
            dst = new DataSet();
            sda.Fill(dst, "HRA_Employee");
            con_CC.close_con();
            getCount = dst.Tables["HRA_Employee"].Rows.Count;
            if (getCount > 0)
            {
                LoggedUserEmpCode = dst.Tables["HRA_Employee"].Rows[0]["EmpCode"].ToString();
                oldPassword = dst.Tables["HRA_Employee"].Rows[0]["EmpPassword"].ToString();
                lblLeaveEmpCode.Text = LoggedUserEmpCode.ToString();
            }
            else
            {
                lblErrorPwdChange.Text = "No Employee Code Loaded. Please try again";
            }
        }
        catch (Exception ex)
        {
            lblErrorPwdChange.Text = "No Employee codeloaded. Please refresh page";
        }
    }
    public void changeEmpPassword()
    {
        try
        {
            getEmpCode = "select EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName As EmpName,EmpCode,EmpEmail,EmpPassword,EmpRoleID from HRA_Employee with(nolock) where EmpEmail=@U";
            sda = new SqlDataAdapter(getEmpCode, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            sda.SelectCommand.Parameters.AddWithValue("@U", Session["EmpEmail"].ToString());
            con_CC.con_open();
            dst = new DataSet();
            sda.Fill(dst, "HRA_Employee");
            con_CC.close_con();
            getCount = dst.Tables["HRA_Employee"].Rows.Count;
            if (getCount > 0)
            {
                LoggedUserEmpCode = dst.Tables["HRA_Employee"].Rows[0]["EmpCode"].ToString();
                oldPassword = dst.Tables["HRA_Employee"].Rows[0]["EmpPassword"].ToString();
                lblLeaveEmpCode.Text = LoggedUserEmpCode.ToString();
                SubmitUpdate();
            }
        }
        catch (Exception ex)
        {
            lblErrorPwdChange.Text = ex.Message.ToString();
        }
    }

    public void SubmitUpdate()
    {
        try
        {
            if (LoggedUserEmpCode.ToString() == lblLeaveEmpCode.Text.ToString() && oldPassword.ToString() == txtOldPassword.Text.ToString())
            {
                updateEmpPwd = "Update HRA_Employee SET EmpPassword=@epwd Where EmpCode=@EC";
                sda = new SqlDataAdapter(updateEmpPwd, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sda.SelectCommand.Parameters.AddWithValue("@epwd", txtEmpConfirmNewPassword.Text.ToString());
                //sda.UpdateCommand.Parameters.AddWithValue("@eem", Session["EmpEmail"].ToString());
                sda.SelectCommand.Parameters.AddWithValue("@EC", lblLeaveEmpCode.Text.ToString());
                con_CC.con_open();
                dst = new DataSet();
                sda.Fill(dst, "HRA_Employee");
                con_CC.close_con();
                lblErrorPwdChange.Text = "<font color=green> <br>Congratulations! Your new password is changed. <a href='/../welcome/Login.aspx'> <b>Click Here</b></a> to Login";

                String newPwd = txtEmpNewPassword.Text.ToString();

                var fromAddress = new MailAddress("hrconnectportal@outlook.com", "HR Connect Portal");
                var toAddress = new MailAddress(Session["EmpEmail"].ToString());
                //const string fromPassword = "Mishra@007";
                const string subject = "HR Connect : Login ID and Password";
                string body = "<html><body width=100% font-family=verdana>"
                + "<div style=width:auto; color:black;>Dear " + Session["EmpName"].ToString() + ",<br><br>Greetings! from HR Connect Portal,"
                + "<br><br><desc>We have notices that your Login password is changed. Please find below your Login details.<br><br>"
                + "If you did not request for password, Kindly Call IT Team or <a href=mailto:hrconnectportal@gmail.com>Send Email</a> to hrconnectportal@gmail.com ASAP.<br><br>"
                + "<table style=padding:10px; font-family=verdana; font-size=10px; align=left width=70% cellpadding=2 rowpadding=3 cellspacing=2 border=2 bordercolor=black>"
                + "<tr><td font-color=white><b>Your New Password: </b></td><td>" + newPwd.ToString() + "</td></tr>"
                + "<tr><td font-color=white><b>Password Requested On: </b></td><td>" + DateTime.Now.ToString() + "</td></tr>"
                + "</table><br><hr><br><br><b>Regards</b><br>HR Connect Portal Team<br><br></div></body></html>";

                var smtp = new SmtpClient()
                {
                    Host = "smtp-mail.outlook.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = true,
                    Credentials = new NetworkCredential("hrconnectportal@outlook.com", "Ram@9324")
                };
                using (var message = new MailMessage(fromAddress, toAddress)
                {
                    IsBodyHtml = true,
                    Subject = subject,
                    Body = body,
                })
                {
                    smtp.Send(message);
                    lblErrorPwdChange.ForeColor = System.Drawing.Color.Green;
                    lblErrorPwdChange.Text = "Login credentials have been sent to your registred Email ID.";
                }
            }
            else
            {
                lblErrorPwdChange.Text = "Password Update Failed. Please try again";
            }
        } catch (Exception ex)
        { lblErrorPwdChange.Text = ex.ToString();}
    }

    protected void showPwd_CheckedChanged(object sender, EventArgs e)
    {
        if (showPwd.Checked == true)
        {
            txtOldPassword.TextMode = TextBoxMode.SingleLine;
        }
        else
        { txtOldPassword.TextMode = TextBoxMode.Password; }
    }
}