﻿<%@ Page Title="" Language="C#" MasterPageFile="~/hrs/hrsMasterPage.master" AutoEventWireup="true" CodeFile="salary_calculation.aspx.cs" Inherits="employee_salary_calc" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="salaryContain" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Employee Salary Calculation/Processing</div>
        <div class="formMjr multiAccordion">
            <div class="empProfileSummary" runat="server">
                <table id="tblPaySalary" style="display: block !important; width: 100% !important; box-sizing: border-box !important; margin: 0 !important;">
                    <tbody style="width: 100% !important;">
                        <tr>
                            <td colspan="3" style="box-shadow: 0 10px 10px -8px #333; margin-bottom: 1%; font-size: 100%; width: 150%; background-color: orangered; color: white; text-align: center; font-weight: 700;">Payroll Processing Area
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>

                        <tr style="text-align: center !important;">

                            <td class="tableTDFields" rowspan="2" style="padding: 2% !important; text-align: left; font-weight: 800; font-size: medium; color: orangered;">Select Date Range</td>

                            <td colspan="2" style="text-align: left; font-weight: 800; font-size: medium; color: orangered;">
                                <div class="fixLength" runat="server">
                                    <asp:TextBox placeholder="From Date" Style="height: 30pt !important; width: 90% !important" CssClass="setCalender txtBoxNewUser" ID="dtFromDatePay" runat="server" Height="40" ToolTip="eg. 15-Jan-2017" ReadOnly="true" />
                                </div>
                                <asp:RequiredFieldValidator ID="req1" runat="server" ControlToValidate="dtFromDatePay" ErrorMessage="Enter From Date"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" style="text-align: left; font-weight: 800; font-size: medium; color: orangered;">
                                <div class="fixLength" runat="server">
                                    <asp:TextBox placeholder="To Date" Style="height: 30pt !important; width: 90% !important" CssClass="setCalender txtBoxNewUser" ID="dtLastDatePay" runat="server" Height="40" ToolTip="eg. 15-Jan-2017" ReadOnly="true" />
                                </div>
                            </td>
                            <asp:RequiredFieldValidator ID="req2" runat="server" ControlToValidate="dtLastDatePay" ErrorMessage="Enter Last Date"></asp:RequiredFieldValidator>
                        </tr>
                        <tr>
                            <td class="tableTDFields" colspan="1" style="padding: 2% !important; text-align: left; font-weight: 800; font-size: medium; color: orangered;">Enter Employee Code/Email ID</td>
                            <td colspan="2">
                                <div class="fixLength" runat="server">
                                    <asp:TextBox ID="payTxtSearchCodeEmail" runat="server" CssClass="txtBoxNewUser" Placeholder="Emp. Code/Email ID" Style="height: 30pt !important; width: 80% !important; padding: 2% !important; font-weight: bolder;"></asp:TextBox>
                                    <asp:RequiredFieldValidator ID="requiredEmpIDCode" ControlToValidate="payTxtSearchCodeEmail" Display="None" SetFocusOnError="true" runat="server" ErrorMessage="Enter Email ID or Emp Code"></asp:RequiredFieldValidator>
                                    <asp:Button class="EmpProfileTabPD" ID="payBtnFindEmp" Text="Find" runat="server" Style="cursor: pointer; width: 50PX !important; padding: 0 !important; height: 35px !important; margin: 0 !important;" OnClick="payBtnFindEmp_Click" />
                                </div>
                            </td>
                        </tr>

                    </tbody>
                </table>
                <div class="clear"></div>
                <div>
                    <table style="width: 100% !important;">
                        <tbody id="tblDataForPayRoll" style="width: 100% !important;" runat="server" class="tblForPayrol formMjr multiAccordion">
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td style="border-bottom: 1pt solid orangered;" colspan="3"></td>
                            </tr>
                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Employee Code</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="PaytxtEmpCode" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Employment Type</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payEmpEmploymentType" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>



                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Employee Name</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTxtEmpName" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>

                                <td class="tableTDFields" style="padding-left: 10pt !important;">Employee Email ID</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTxtEmpEmail" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>

                                <td class="tableTDFields" style="padding-left: 10pt !important;">Pay Slip For Month & Year</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTxtMonthYear" runat="server" ReadOnly="true" Enabled="True" BorderStyle="None" CssClass="txtBoxLogin txtTdHead setCalender"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Total Working Days</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTotWorkDays" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Total Present Days Days</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTotalPresentDays" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Total Absent Days</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTotalAbsentDays" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="tableTDFields" style="padding-left: 10pt !important;">Total Leave Days</td>
                                <td><b>:</b></td>
                                <td>
                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTotalLeave" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td rowspan="8" class="tableTDFields" style="text-align: center !important;">
                                    <p class="EmpProfileTabPD">Employee Gross Salary</p>

                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTxtBasic" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtHRA" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PaytxtEduAmt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PaytxtLTA_amt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PayTxtESIC_amt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PayTxtConveyance_Amt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PayTxtPF_amt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PayTxtPT_amt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="PayTxtGrossAmt" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                    </div>
                                </td>

                                <td></td>
                                <td rowspan="8" class="tableTDFields" style="text-align: center !important;">
                                    <p class="EmpProfileTabPD">Employee Gross Salary</p>

                                    <div class="fixLength" style="height: auto !important;" runat="server">
                                        <asp:TextBox ID="payTxtBasicFinal" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtHraFinal" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="paytxtEduAmtFinal" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtLTA_amt_final" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtESIC_Final" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtConvey_Final" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtPFAmt_Final" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtPTamt_Final" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                        <asp:TextBox ID="payTxtGross_Final" runat="server" ReadOnly="true" Enabled="false" BorderStyle="None" CssClass="txtBoxLogin txtTdHead txtAmounts"></asp:TextBox>
                                    </div>
                                </td>
                            </tr>


                            <%--<tr>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <asp:Label ID="lblAddEmpErrorMsg" CssClass="ErrorMsg" runat="server"></asp:Label>
                                </td>
                            </tr>

                            <tr>
                                <td style="text-align: center; width: 100% !important;">

                                    <asp:Button ID="btnSaveEmpRegistration" Text="Confirm and Save" runat="server" class="LogBtn" />&nbsp;
                                <asp:Button ID="btnResetRegistrationData" Text="Reset Data" runat="server" class="LogBtn" />
                                </td>
                            </tr>--%>
                        </tbody>
                    </table>
                </div>
                <asp:Label ID="lblAddEmpErrorMsg" CssClass="ErrorMsg" runat="server"></asp:Label>
                <asp:ValidationSummary ID="errorValidation" runat="server" ShowMessageBox="True" HeaderText="Please Enter following below details" ToolTip="Error: Mandatory Information" ShowSummary="False" />
            </div>

        </div>
    </div>
    <div style="visibility: hidden; display: none;">
        // Employee Name, LeaveCode, EmpCode, Type, AppDate, StartDate, EndDate, TotalDays, Status, ApprovedBy, ApprovedDate, Remarks
        <asp:Label ID="EmailEmpName" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveCode" runat="server"></asp:Label>
        <asp:Label ID="EmailEmpCode" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveType" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveAppDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveStDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveEndDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveTotalDays" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveStatus" runat="server"></asp:Label>
        <asp:Label ID="EmailApprovalMgr" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveApproveDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveRemarks" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveEmailTo" runat="server"></asp:Label>
    </div>
</asp:Content>

<%--<tr>
                            <td colspan="2" class="tableTDFields">Middle Name & Last Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 39.5%; top: 0 !important;" class="setCalender" ID="txtEmpMiddleName" runat="server" ToolTip="Employee Middle name" ReadOnly="False" />
                                <asp:TextBox Style="height: 22pt; width: 39%; top: 0 !important;" class="setCalender" ID="txtEmpLastName" runat="server" ToolTip="Employee Last name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ErrorMessage="Employee Middle Name" ControlToValidate="txtEmpMiddleName" Display="None" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ErrorMessage="Employee Last Name" ControlToValidate="txtEmpLastName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Date of Birth</td>

                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="dtEmpDob" runat="server" Height="30" Width="81%" ToolTip="Employee date of birth" ReadOnly="true" />
                                    <asp:RequiredFieldValidator ID="ELastDt" runat="server" ErrorMessage="Employee Date of Birth." ControlToValidate="dtEmpDob" Display="None" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Gender</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpGen" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Male</asp:ListItem>
                                        <asp:ListItem>Female</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Email Address</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 80%; top: 0 !important;" class="setCalender" ID="txtEmpEmail" runat="server" Height="30" ToolTip="Employee Email ID" ReadOnly="false" />
                                <asp:RegularExpressionValidator ID="emValid" runat="server" ControlToValidate="txtEmpEmail" ValidationExpression="\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"
                                    SetFocusOnError="false" ErrorMessage="Employee Email Address" Display="None"> 
                                </asp:RegularExpressionValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Mobile Number  </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 80%; top: 0 !important;" class="setCalender" ID="txtEmpMobile" runat="server" Height="30" Width="80%" ToolTip="Employee Mobile" />
                                <br />
                                <asp:RequiredFieldValidator ID="mobiValid" runat="server" ErrorMessage="Employee Mobile Number" ControlToValidate="txtEmpMobile" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Phone Number  </td>

                            <td>
                                <asp:TextBox Style="height: 22pt; width: 80%; top: 0 !important;" class="setCalender" ID="txtEmpPhone" runat="server" Height="30" Width="80%" ToolTip="Employee Mobile" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator34" runat="server" ErrorMessage="Employee Phone Number" ControlToValidate="txtEmpPhone" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Date of Joining</td>
                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="txtDtOfJoining" runat="server" Height="30" Width="80%" ToolTip="Employee date of birth" ReadOnly="true" />
                                    <asp:RequiredFieldValidator ID="DOJValid" runat="server" ErrorMessage="Employee Date of Joining" ControlToValidate="txtDtOfJoining"
                                        Display="None" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Job Type</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpJobType" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Permanent</asp:ListItem>
                                        <asp:ListItem>Temporarly</asp:ListItem>
                                        <asp:ListItem>Probationary</asp:ListItem>
                                        <asp:ListItem>Contractual</asp:ListItem>
                                        <asp:ListItem>Consultants</asp:ListItem>
                                        <asp:ListItem>Visiting</asp:ListItem>
                                        <asp:ListItem>Faculty</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Access Right</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="DrpEmpRoleID" runat="server" Style="height: 22pt; width: 10%;">
                                        <asp:ListItem>1</asp:ListItem>
                                        <asp:ListItem>2</asp:ListItem>
                                        <asp:ListItem>3</asp:ListItem>
                                        <asp:ListItem>4</asp:ListItem>
                                    </asp:DropDownList>
                                    <asp:Label CssClass="ErrorMsg" ID="lblRoleInfo" Style="font-size-adjust: 0.40 !important; height: 22pt; width: 70%;" runat="server" Text="1.Employee, 2. HR 3. Managers 4. Admin"></asp:Label>

                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Desgination & Department</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpDesignation" runat="server" Style="height: 22pt; width: 39%;">
                                        <asp:ListItem>Executive</asp:ListItem>
                                        <asp:ListItem>Manager</asp:ListItem>
                                        <asp:ListItem>Supervisor</asp:ListItem>
                                        <asp:ListItem>Team Leader</asp:ListItem>
                                        <asp:ListItem>Accountant</asp:ListItem>
                                    </asp:DropDownList>

                                    <asp:DropDownList ID="drpDept" runat="server" Style="height: 22pt; width: 40%;">
                                        <asp:ListItem>HR Admin</asp:ListItem>
                                        <asp:ListItem>Information Technology</asp:ListItem>
                                        <asp:ListItem>Account</asp:ListItem>
                                        <asp:ListItem>Sales</asp:ListItem>
                                        <asp:ListItem>Purchase</asp:ListItem>
                                        <asp:ListItem>Help & Support</asp:ListItem>
                                        <asp:ListItem>Marketting</asp:ListItem>
                                        <asp:ListItem>Business Development</asp:ListItem>
                                        <asp:ListItem>House Keeping</asp:ListItem>
                                    </asp:DropDownList>
                                </div>


                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Work Location</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpWorkLocation" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>New Delhi</asp:ListItem>
                                        <asp:ListItem>Chennai</asp:ListItem>
                                        <asp:ListItem>Mumbai</asp:ListItem>
                                        <asp:ListItem>Bardoa</asp:ListItem>
                                        <asp:ListItem>Banglore</asp:ListItem>
                                        <asp:ListItem>Cochin</asp:ListItem>
                                        <asp:ListItem>Hyderabad</asp:ListItem>
                                        <asp:ListItem>Kolkata</asp:ListItem>
                                        <asp:ListItem>Lucknow</asp:ListItem>
                                        <asp:ListItem>Kanpur</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Work Division</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpWorkDivision" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Mumbai Div 1</asp:ListItem>
                                        <asp:ListItem>Mumbai Div 2</asp:ListItem>
                                        <asp:ListItem>Chennai Div 1</asp:ListItem>
                                        <asp:ListItem>Andheri</asp:ListItem>
                                        <asp:ListItem>Powai</asp:ListItem>
                                        <asp:ListItem>Churchgate</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Team Name</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpTeamName" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Junior Team</asp:ListItem>
                                        <asp:ListItem>Senior Team</asp:ListItem>
                                        <asp:ListItem>Faculty Team Div 1</asp:ListItem>
                                        <asp:ListItem>Training Team</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Reporting Manager Name</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpReportingMgr" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Select Name</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="empFamilyDetails" class="EmpProfileTabPD tahHead" onclick="showhide4()" style="cursor: pointer;" title="Click to show information">Personal Information
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblPropertiesFamily" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Father / Husband Name </td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpFathHusName" runat="server" Style="height: 22pt; width: 15%;">
                                        <asp:ListItem>Mr.</asp:ListItem>
                                        <asp:ListItem>Ms.</asp:ListItem>
                                        <asp:ListItem>Mrs.</asp:ListItem>
                                        <asp:ListItem>Smt.</asp:ListItem>
                                    </asp:DropDownList>
                                    <asp:TextBox Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtBoxFHName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Mother Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpMotherName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Place of Birth</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpPlaceOfBirth" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>



                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Current Address </td>
                            <td>
                                <textarea id="txtEmpCompleteAddress" cols="20" rows="3" runat="server" style="padding-left: 10px !important; resize: none; width: 81% !important;"></textarea>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator29" runat="server" ErrorMessage="Enter Current Address" ControlToValidate="txtEmpCompleteAddress" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Area Name/ Town Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpTownName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator30" runat="server" ErrorMessage="Enter Town Name" ControlToValidate="txtEmpTownName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">City Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpCityName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator31" runat="server" ErrorMessage="Enter City Name" ControlToValidate="txtEmpCityName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">State Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpStateName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator32" runat="server" ErrorMessage="Enter State Name" ControlToValidate="txtEmpCityName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Postal Code</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpAddPincode" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator41" runat="server" ErrorMessage="Enter Postal Code" ControlToValidate="txtEmpAddPincode" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Country Name </td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpCountry" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>India</asp:ListItem>
                                        <asp:ListItem>UAE</asp:ListItem>
                                        <asp:ListItem>Saudi Arabia</asp:ListItem>
                                        <asp:ListItem>USA</asp:ListItem>
                                        <asp:ListItem>UK</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Nationality</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpNationality" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Indian</asp:ListItem>
                                        <asp:ListItem>Other</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Marital Status</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpMaritalStatus" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Un-Married</asp:ListItem>
                                        <asp:ListItem>Married</asp:ListItem>
                                        <asp:ListItem>Not Disclosed</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Blood Group</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpBloodGroup" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>O-Positive</asp:ListItem>
                                        <asp:ListItem>O-Negative</asp:ListItem>
                                        <asp:ListItem>A-Positive</asp:ListItem>
                                        <asp:ListItem>A-Negative</asp:ListItem>
                                        <asp:ListItem>B-Positive</asp:ListItem>
                                        <asp:ListItem>B-Negative</asp:ListItem>
                                        <asp:ListItem>AB-Positive</asp:ListItem>
                                        <asp:ListItem>AB-Negative</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Hobbies / Interests </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpHobbies" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                
--%>
   