﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Globalization;



public partial class employee_attendance_history : System.Web.UI.Page
{
    con_properties attCon = new con_properties();
    SqlDataAdapter sdaAttend;
    DataSet dst;
    string strLoadAllQueries;
    int countrow;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.LoadAttendanceOfEmp();
        }

        
    }
    public void LoadAttendanceOfEmp()
    {
        if (!this.IsPostBack)
        {
            try
            {
                strLoadAllQueries = "SELECT ROW_NUMBER() OVER(ORDER BY RID ASC) AS SrNo, EmpName As 'Employee Name', EmpCode as 'Employee Code', Format(AttDate, 'dd-MMM-yyyy dddd') as 'Attendance Date', AttStatus As 'Status' from EmpAttendance with(nolock) Order By AttDate,RID ASC";
                sdaAttend = new SqlDataAdapter(strLoadAllQueries, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                attCon.con_open();
                dst = new DataSet();
                sdaAttend.Fill(dst, "EmpAttendance");
                attCon.close_con();
                countrow = dst.Tables["EmpAttendance"].Rows.Count;
                if (countrow > 0)
                {

                    
                    grdViewAttendanceRecords.Visible = true;
                    grdViewAttendanceRecords.DataMember = "EmpAttendance";
                    grdViewAttendanceRecords.DataSource = dst;
                    grdViewAttendanceRecords.DataBind();

                }
                else
                {
                    lblErrorMsgOnLeaveGrid.Text = " There is no attendance data found";
                }
            }
            catch (Exception ex)
            {
                lblErrorMsgOnLeaveGrid.Text = ex.Message.ToString();
            }
        }
    }




    protected void btnImportAttendance_Click(object sender, EventArgs e)
    {
        
        //try
        //{
        //    using Excel = Microsoft.Office.Interop.Excel;

        //    Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
        //    excel.Visible = true;
        //    Microsoft.Office.Interop.Excel.Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
        //    Microsoft.Office.Interop.Excel.Worksheet sheet1 = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];
        //    int StartCol = 1;
        //    int StartRow = 1;
        //    int j = 0, i = 0;

        //    //Write Headers
        //    for (j = 0; j < dgvSource.Columns.Count; j++)
        //    {
        //        Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[StartRow, StartCol + j];
        //        myRange.Value2 = dgvSource.Columns[j].HeaderText;
        //    }

        //    StartRow++;

        //    //Write datagridview content
        //    for (i = 0; i < dgvSource.Rows.Count; i++)
        //    {
        //        for (j = 0; j < dgvSource.Columns.Count; j++)
        //        {
        //            try
        //            {
        //                Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[StartRow + i, StartCol + j];
        //                myRange.Value2 = dgvSource[j, i].Value == null ? "" : dgvSource[j, i].Value;
        //            }
        //            catch
        //            {
        //                ;
        //            }
        //        }
        //    }
        //}
        //catch (Exception ex)
        //{
        //    MessageBox.Show(ex.ToString());
        //}

    }

    protected void grdViewLeaveRecords_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        grdViewAttendanceRecords.PageIndex = e.NewSelectedIndex;
        grdViewAttendanceRecords.DataBind();
    }



    protected void btnUpdateAttNew_Click(object sender, EventArgs e)
    {
        Response.Redirect(@"~/hrs/update-attendance.aspx", false);
    }

    protected void btnMarkAttNew_Click(object sender, EventArgs e)
    {
        Response.Redirect(@"~/hrs/record-attendance.aspx", false);
        
    }
}