﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;

public partial class comman_pages_applyleave : System.Web.UI.Page
{
    con_properties LC = new con_properties();
    //SqlConnection LoginCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HCUserLogin"].ToString());
    DataSet dtSet;
    SqlDataAdapter da;
    DataTable dt;
    SqlCommand cmd;
    int rowcount;
    string SessionLogged;
    string _UNameText;
    double countDays;
    double countHD;
    string strLoadEmail;
    string strLoadEmpQuery;
    string strQuery;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadEmpDataForNewLeaves();
            LoadEmailContacts();

            //    try
            //    {
            //        if (Session["ELoginName"] != null && Convert.ToString(Session["ELoginName"]) != "")
            //        {
            //            _UNameText = Convert.ToString(Session["ELoginName"]);
            //            Session["ELoginName"] = _UNameText;
            //            UNameText.Text = "Welcome! " + _UNameText.ToString();
            //        }

            //    }
            //    catch (Exception ex)
            //    {
            //        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Session Expired. Kindly re-login')</script>");
            //        Response.Redirect("Login.aspx");
            //    }
            //}
        }
    }

    public void LoadEmailContacts()
    {
        try
        {
            strLoadEmail = "select EmpTitle + ' ' + EmpFirstName  As EmpName, EmpEmail from HRA_Employee with(nolock)";

            da = new SqlDataAdapter(strLoadEmail, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            //da.SelectCommand.Parameters.AddWithValue("@Empe", Session["EmpEmail"].ToString());
            LC.con_open();
            dtSet = new DataSet();
            da.Fill(dtSet, "HRA_Employee");
            LC.close_con();
            rowcount = dtSet.Tables["HRA_Employee"].Rows.Count;

            if (rowcount > 0)
            {
                drpLeaveEmailCC.DataSource = dtSet.Tables["HRA_Employee"];
                drpLeaveEmailCC.DataBind();
                drpLeaveEmailCC.DataTextField = "EmpName";
                drpLeaveEmailCC.DataValueField = "EmpName";
                drpLeaveEmailCC.DataBind();
                lblLeaveCCEmailAddress.Text = dtSet.Tables["HRA_Employee"].Rows[0]["EmpEmail"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Web Connection Failed')</script>");
                Response.Redirect(@"~/hrs/Default.aspx", false);
            }
        }
        catch (Exception ex)
        {
            LeaveError.Text = "Web Connection failed. Data not loaded.";
        }
    }
    protected void LoadEmpDataForNewLeaves()
    {
        try
        {
            strQuery = "select EmpTitle + ' ' + EmpFirstName + ' : [ ' + EmpEmail + ' ]' As EmpNameEmail, EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName As EmpName, EmpTitle + ' ' + EmpFirstName + ' : [ ' + EmpEmail + ' ]' As EmpNameEmail, EmpCode, EmpEmail, PL_Leave, CL_Leave from HRA_Employee with(nolock) where EmpEmail=@Empe";
            da = new SqlDataAdapter(strQuery, ConfigurationManager.ConnectionStrings["HRAString"].ToString());

            da.SelectCommand.Parameters.AddWithValue("@EmpE", Session["EmpEmail"].ToString());
            LC.con_open();
            dtSet = new DataSet();
            da.Fill(dtSet, "HRA_Employee");
            LC.close_con();
            rowcount = dtSet.Tables["HRA_Employee"].Rows.Count;

            if (rowcount > 0)
            {
                //Session["EmpCode"] = SessionLogged.ToString();
                lblLeaveEmpCode.Text = dtSet.Tables["HRA_Employee"].Rows[0]["EmpCode"].ToString();
                lblLeaveEmpName.Text = dtSet.Tables["HRA_Employee"].Rows[0]["EmpName"].ToString();
                lblBalancePL.Text = dtSet.Tables["HRA_Employee"].Rows[0]["PL_Leave"].ToString();
                lblBalanceCL.Text = dtSet.Tables["HRA_Employee"].Rows[0]["CL_Leave"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Web Connection Failed')</script>");
                Response.Redirect(@"~/hrs/Default.aspx", false);
            }
        }
        catch (Exception ex)
        {
            LeaveError.Text = ex.Message.ToString();
        }
    }

    public void countEmpLeaveDays()
    {
        DateTime startDate = Convert.ToDateTime(dtStartLeave.Text);
        DateTime EndDate = Convert.ToDateTime(dtEndLeave.Text).AddDays(1);
        TimeSpan span = (EndDate - startDate);
        countDays = Convert.ToDouble(span.TotalDays);
        lblCountLeaveDys.Text = (countDays).ToString();
    }
    protected void btnCt_Click(object sender, EventArgs e)
    {
        try
        {

            DateTime startDt = Convert.ToDateTime(dtStartLeave.Text);
            DateTime endDt2 = Convert.ToDateTime(dtEndLeave.Text);

            if (startDt > endDt2)
            {
                lblLeaveErrorMsg.Text = "Error: Start Leave Date cannot be greater than";
            }

            if (rdoHalfDay.Checked == true)
            {
                countHD = Convert.ToDouble("0.5");
                TimeSpan span2 = (endDt2 - startDt);
                double withHalfDay = (Convert.ToDouble(span2.TotalDays) + 0.5);
                lblCountLeaveDys.Text = withHalfDay.ToString();
            }
            else
            {
                countEmpLeaveDays();

            }
        }
        catch (Exception ex)
        {
            lblLeaveErrorMsg.Text = "Please enter Dates to apply for leave";
        }
    }

    protected void drpLeaveEmailCC_SelectedIndexChanged(object sender, EventArgs e)

    {
        if (!Page.IsPostBack)
        {
            LoadEmailContacts();
        }


    }


    public void SaveNewEmpLeave()
    {
        try
        {
            string strNewLeaveRecord = "INSERT into EmpAppliedLeave (LeaveRefEmpRID, LeaveType, dtLeaveLastWorkDate, dtLeaveStartDate, dtLeaveEndDate, TotalAppliedDays, LeaveStatus, ReasonForLeave, LeaveAppCCEmail) Values (@a, @b, @c, @d, @e, @f, @g, @h, @i)";
            da = new SqlDataAdapter(strNewLeaveRecord, ConfigurationManager.ConnectionStrings["HRAString"].ToString());

            da.SelectCommand.Parameters.AddWithValue("@a", lblLeaveEmpCode.Text.ToString());
            da.SelectCommand.Parameters.AddWithValue("@b", cmbLeaveType.Text.ToString());
            da.SelectCommand.Parameters.AddWithValue("@c", Convert.ToDateTime(dtLastWorkDay.Text).ToString());
            da.SelectCommand.Parameters.AddWithValue("@d", Convert.ToDateTime(dtStartLeave.Text).ToString());
            da.SelectCommand.Parameters.AddWithValue("@e", Convert.ToDateTime(dtEndLeave.Text).ToString());
            da.SelectCommand.Parameters.AddWithValue("@f", Convert.ToDouble(lblCountLeaveDys.Text.ToString()));
            da.SelectCommand.Parameters.AddWithValue("@g", Convert.ToString("Pending"));
            da.SelectCommand.Parameters.AddWithValue("@h", txtLeaveReason.Text.ToString());
            da.SelectCommand.Parameters.AddWithValue("@i", lblLeaveCCEmailAddress.Text.ToString());

            dtSet = new DataSet();
            LC.con_open();
            da.Fill(dtSet, "EmpAppliedLeave");
            LC.close_con();
            ClientScript.RegisterStartupScript(Page.GetType(), "Leave Application Status", "<script language='javascript'>alert('Your leave application is submitted successfully. An email has been sent with the leave details.')</script>");

            Response.Redirect(@"~/hrs/Default.aspx", false);
        }
        catch (Exception ex)
        {
            lblLeaveErrorMsg.Text = ex.Message.ToString();
        }
    }

    protected void btnApplyNewLeave_Click(object sender, EventArgs e)
    {
        SaveNewEmpLeave();

    }



    protected void btnResetLeaveData_Click(object sender, EventArgs e)
    {
        cmbLeaveType.SelectedIndex = 0;
        dtStartLeave.Text = "";
        dtLastWorkDay.Text = "";
        dtEndLeave.Text = "";
        rdoFullDay.Checked = true;
        rdoHalfDay.Checked = false;
        lblCountLeaveDys.Text = " Days";
        txtLeaveReason.Text = "";
        txtLeaveMobile.Text = "";
        drpLeaveEmailCC.SelectedIndex = 0;
        lblLeaveCCEmailAddress.Text = drpLeaveEmailCC.SelectedValue.ToString();
    }
}
