﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.Globalization;

public partial class AdminMasterPage : System.Web.UI.MasterPage
{

    ContentPlaceHolder cpHolder;
    Label mpLabel;

    con_properties cl = new con_properties();
    DataSet ds;
    SqlDataAdapter adpNew;

    protected void Page_Load(object sender, EventArgs e)
    {

        //if (Session["EmpEmail"] == null)
        //{
        //    //Redirect to Welcome Page if Session is not null  

        //    Response.Redirect(@"~/common-errors/ErrorMsg.aspx");

        //}
        //else
        //{
            

        //}
    }
    public void showHomePage()
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "onclick", "javascript:window.open( 'Login.aspx','_blank','height=600px,width=600px,scrollbars=1');", true);
    }

    public void getUserName()
    {

        try
        {
            if (!IsPostBack)
            {

                cpHolder = (ContentPlaceHolder)Master.FindControl("MainHead");
                mpLabel = (Label)Master.FindControl("UNameText");

                if (mpLabel != null)
                {
                    try
                    {
                        string selectDt = "SELECT EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName As EmpFullName From JVIEmp with(nolock) Where ELoginName=@eLog";
                        SqlDataAdapter adp = new SqlDataAdapter(selectDt, (ConfigurationManager.ConnectionStrings["HRAString"].ToString()));
                        adp.SelectCommand.Parameters.AddWithValue("@eLog", Session["ELoginName"].ToString());
                        ds = new DataSet();
                        cl.con_open();
                        adp.Fill(ds, "JVIEmp");
                        cl.close_con();
                        if (ds.Tables["JVIEmp"].Rows.Count > 0)
                        {
                            mpLabel.Text = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EmpFullName"]);
                            }
                        else
                        { }
                    }catch (Exception ex)
                    {
                        Session.RemoveAll();
                        Response.Redirect(@"~/welcome/Login.aspx");
                    }


                    mpLabel.Text = "<h2 colour=#fc4508 text-align=center> Welcome [ " + mpLabel.Text + " ]</h2><hr background-color=red>";

                }
            }
        }
        catch (Exception ex)
        {
            //ClientScript.RegisterStartupScript(Page.GetType(), "Login Failed", "<script language='javascript'>alert('Error in loading data.')</script>");
        }
    }
}
