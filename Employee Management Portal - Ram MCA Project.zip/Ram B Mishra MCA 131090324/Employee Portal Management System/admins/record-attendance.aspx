﻿<%@ Page Title="" Language="C#" MasterPageFile="~/hrs/hrsMasterPage.master" AutoEventWireup="true" CodeFile="record-attendance.aspx.cs" Inherits="record_employee_attendance" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Employee Attendance Registration</div>
        <div class="formMjr" style="width: 98% !important; padding: 2pt !important;" runat="server">
            <table style="width: 100%; padding: 0 !important; margin: 0 !important; padding-top: 1pt !important; padding-bottom: 5pt !important; box-shadow: 0 10px 10px -8px #333 !important; height: 20px;">
                <tbody style="width: 100% !important">
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <asp:Label CssClass="ErrorMsg" ID="lblLastAttendanceUpdated" runat="server"></asp:Label>
                        </td>
                    </tr>
                    <tr style="text-align: left !important;">
                        <td>&nbsp;</td>
                        <td style="text-align: left; font-weight: 800; font-size: medium; color: orangered;">Select Date to mark attendance :                         
                            <asp:TextBox Style="margin-top: 8pt !important; height: 40pt !important; width: 40% !important" CssClass="setCalender txtBoxLogin" ID="dtAttendanceSelectedForEmp" runat="server" Height="40" ToolTip="eg. 15-Jan-2017" ReadOnly="true" />
                        </td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            <div class="clear"></div>
            <asp:GridView ID="grdViewLeaveRecords" Style="margin-bottom: 10pt; font-size: 12px; font-size-adjust: 0.88 !important; border-color: #DEBA84; border-width: 1px; border-style: None; font-size: 100% !important; font-size-adjust: 0.48 !important; line-height: 23pt;" CssClass="LeaveRecordsList" runat="server" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="3" CellSpacing="2" EnableModelValidation="True" HeaderStyle-Height="120%">
                <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                <HeaderStyle BackColor="orangered" Font-Bold="True" ForeColor="White" />
                <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                <RowStyle BackColor="white" ForeColor="orangered" />
                <SelectedRowStyle BackColor="cornsilk" Font-Bold="True" ForeColor="#fc4508" />

                <%--<Columns>
                    <asp:BoundField DataField="SrNo" HeaderText="Sr. No." ReadOnly="true" />
                    <asp:BoundField DataField="EmpCode" HeaderText="Emp. Code" ReadOnly="true" />
                    <asp:BoundField DataField="EmpDept" HeaderText="Department" ReadOnly="true" />
                    <asp:BoundField DataField="EmpName" HeaderText="Employee Name" ReadOnly="true" />
                </Columns>--%>
                <Columns>
                    <asp:TemplateField HeaderText="SrNo">
                        <ItemTemplate>
                            <asp:Label ID="lblAttSrNo" runat="server" Text='<%#Eval("SrNo")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <Columns>
                    <asp:TemplateField HeaderText="Emp. Code">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpCodeGrd" runat="server" Text='<%#Eval("EmpCode")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <Columns>
                    <asp:TemplateField HeaderText="Department">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpDeptGrd" runat="server" Text='<%#Eval("EmpDept")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Emp No.">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpNoGrd" runat="server" Text='<%#Eval("EmpNo")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Employee Name">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpNameGrd" runat="server" Text='<%#Eval("EmpName")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Mark Attendance">
                        <ItemTemplate>
                            <table runat="server" style="width: 100% !important;">
                                <tr>
                                    <td class="ErrorMsg footerButton" style="background-color:white; color:orangered; padding:1% !important">
                                        <asp:RadioButton Checked="true" ID="r1" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="P" ToolTip="P = Present" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r2" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="A" ToolTip="A = Absent" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r3" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="O" ToolTip="O = On Outdoor Duty" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r4" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="PL" ToolTip="L = Leave" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r5" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="UL" ToolTip="L = Leave" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                    </td>
                                </tr>
                            </table>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>

            <table style="width: 100% !important;">
                <tr>
                    <td colspan="3" style="text-align: center !important;">
                            <asp:Button Text="Save Attendance" ID="btnMarkAttendance" runat="server" class="LogBtn" OnClick="btnMarkAttendance_Click" />&nbsp;
                            <asp:Button CssClass="LogBtn" Text="Attendance History" runat="server" ID="btnHistoryAtt" OnClick="btnHistoryAtt_Click" />&nbsp;
                            <asp:Button CssClass="LogBtn" Text="Update Attendance" ID="btnUpdateAttNewRecord" runat="server" OnClick="btnUpdateAttNewRecord_Click" />&nbsp;
                            <asp:Button type="reset" ID="btnResetAttendance" Text="Clear Data" runat="server" class="LogBtn" OnClick="btnResetAttendance_Click" />
                    </td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="3" style="text-align: center !important;">
                        <asp:Label ID="lblErrorMsgOnLeaveGrid" class="ErrorMsg" runat="server">
                        </asp:Label>
                    </td>
                </tr>

                <asp:LinkButton Text="" ID="lblViewSelectedGridData" runat="server">
                </asp:LinkButton>
            </table>
        </div>
    </div>

</asp:Content>
