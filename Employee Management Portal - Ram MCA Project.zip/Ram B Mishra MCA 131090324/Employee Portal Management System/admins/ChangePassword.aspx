﻿<%@ Page Title="Change Password" Language="C#" MasterPageFile="~/admins/AdminMasterPage.master" AutoEventWireup="true" CodeFile="ChangePassword.aspx.cs" Inherits="hrs_ChangePassword" %>

<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Login Password Assistance</div>
        <div class="formMjr multiAccordion">
            <div class="empProfileSummary" runat="server">
                <table id="tblProperties" style="width: 100%; padding: 3% !important; box-sizing: border-box !important; margin: 0 !important;">
                    <tbody style="width: 100%">
                        <tr>
                            <td colspan="3" style="box-shadow: 0 10px 10px -8px #333; margin-bottom: 1%; font-size: 100%; width: 150%; background-color: orangered; color: white; text-align: center; font-weight: 700;">Change Login Password
                            </td>
                        </tr>

                        <tr><td></td></tr>
                        <tr>
                            <td class="tableTDFields">Your Employee Code</td>
                            <td class="tableTDFields"><b></b></td>
                            <td>
                                <asp:Label ID="lblLeaveEmpCode" style="padding-top:5% !important; border:0pt !important;" runat="server" CssClass="fixLength ErrorMsg"></asp:Label>
                            </td>
                        </tr>
                        <tr style="padding:5pt !important;">
                            <td class="tableTDFields">Enter Old Password * </td>
                            <td class="tableTDFields"><b></b></td>
                            <td>
                                <asp:TextBox ID="txtOldPassword" runat="server" style="padding-bottom:5% !important;padding-right:5% !important;padding-top:5% !important;" CssClass="setPTxtIcon txtBoxLogin" TextMode="Password" />
                                <asp:CheckBox ID="showPwd" runat="server" OnCheckedChanged="showPwd_CheckedChanged" />
                                <asp:RequiredFieldValidator ID="leavMob" runat="server" ErrorMessage="Please Enter Mobile Number reason  for Leave." ControlToValidate="txtEmpConfirmNewPassword" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr style="margin-bottom:5pt;">
                            <td class="tableTDFields">Enter New Password *</td>
                            <td class="tableTDFields"><b></b></td>
                            <td>
                                <asp:TextBox ID="txtEmpNewPassword" runat="server" style="padding-bottom:5% !important;padding-right:5% !important;padding-top:5% !important;" CssClass="setPTxtIcon txtBoxLogin" TextMode="Password" />
                                <asp:CheckBox ID="showPwd2" runat="server"/>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ErrorMessage="Please Enter Mobile Number reason  for Leave." ControlToValidate="txtEmpConfirmNewPassword" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr style="margin-bottom:5pt;">
                            <td class="tableTDFields">Confirm New Password *</td>
                            <td class="tableTDFields"><b></b></td>
                            <td>
                                <asp:TextBox ID="txtEmpConfirmNewPassword" runat="server" style="padding-bottom:5% !important;padding-right:5% !important;padding-top:5% !important;" CssClass="setPTxtIcon txtBoxLogin" TextMode="Password" />
                                <asp:CheckBox ID="showPwd3" runat="server" />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ErrorMessage="Please Enter Mobile Number reason  for Leave." ControlToValidate="txtEmpConfirmNewPassword" Display="Dynamic" SetFocusOnError="True"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="3">
                                <asp:Label ID="lblErrorPwdChange" CssClass="ErrorMsg" runat="server"></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center !important;">
                                <asp:Button ID="btnUpdatePassword" Text="Update Password" runat="server" OnClick="btnUpdatePassword_Click" class="LogBtn" />&nbsp;
                                <asp:Button ID="btnResetPassChange" Text="Reset Data" runat="server" class="LogBtn" OnClick="btnResetPassChange_Click" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <hr />
            <asp:Label ID="LeaveError" runat="server" CssClass="ErrorMsg"></asp:Label>
        </div>
    </div>

    <div style="visibility:hidden">

        <asp:Label ID=""
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
</asp:Content>
