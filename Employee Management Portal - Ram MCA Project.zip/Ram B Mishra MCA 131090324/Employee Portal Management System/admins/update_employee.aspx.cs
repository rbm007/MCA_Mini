﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Globalization;
using System.Net;
using System.Net.Mail;

public partial class comman_pages_leaveRecords : System.Web.UI.Page
{
    con_properties con_emp_update = new con_properties();
    SqlDataAdapter dataAdpEmpUpdate;
    DataSet dst_emp_update;
    String update_employee_record;
    String LoadManagerNames;
    SqlDataAdapter da_update;
    con_properties updateEmpCon = new con_properties();
    DataSet ds_update;
    int rowcount;
    string strLoadEmpDataInGrid;


        protected void Page_Load(object sender, EventArgs e)
    {
        LoadManagersForUpdateEmp();
        LoadEmployeeForUpdate();
        btnSaveEmpRegistration.Attributes.Add("AutoPostBack","false");
        btnSumNetSalary.Attributes.Add("AutoPostBack", "false");
        btnPreview.Attributes.Add("AutoPostBack", "false");
        btnSaveImage.Attributes.Add("AutoPostBack", "false");

    }


    protected void grdViewEmpRecords_SelectedIndexChanged(object sender, EventArgs e)
    {

        try
        {
            EmpCodeForUpdate.Text = "Data Updation for Employee Code" + (grdViewEmployeeLisToUpdate.SelectedRow.FindControl("EmpCode") as Label).Text;

          

            //BindLeaveAndEmpDetails();
            EmpUpdateEmployeeData.Show();
        }

        catch (SqlException ex)
        {
            if (ex.Number == 1205)
            {
                lblAddEmpErrorMsg.Text = ex.Message.ToString();
            }
            else
            {
                lblAddEmpErrorMsg.Text = "Data Error: Check your network setting";
            }
        }
    }

    protected void LoadManagersForUpdateEmp()
    {
        try
        {
            LoadManagerNames = "select EmpTitle + ' ' + EmpFirstName + ' ' + EmpLastName  As EmpName from HRA_Employee with(nolock)";

            da_update = new SqlDataAdapter(LoadManagerNames, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            //da.SelectCommand.Parameters.AddWithValue("@Empe", Session["EmpEmail"].ToString());
            updateEmpCon.con_open();
            ds_update = new DataSet();
            da_update.Fill(ds_update, "HRA_Employee");
            updateEmpCon.close_con();
            rowcount = ds_update.Tables["HRA_Employee"].Rows.Count;
            if (rowcount > 0)
            {
                drpEmpReportingMgr.DataSource = ds_update.Tables["HRA_Employee"];
                drpEmpReportingMgr.DataBind();
                drpEmpReportingMgr.DataTextField = "EmpName";
                drpEmpReportingMgr.DataValueField = "EmpName";
                drpEmpReportingMgr.DataBind();

            }
            else
            {
                Response.Write("<script>alert('Employee names not loaded.')</script>");

            }
        }
        catch (Exception ex)
        {
            lblAddEmpErrorMsg.Text = "Reports to: Contact Not Loaded";
        }
    }


    public void LoadEmployeeForUpdate()
    {
        if (!this.IsPostBack)
        {
            try
            {
                strLoadEmpDataInGrid = "SELECT ROW_NUMBER() OVER(ORDER BY RID ASC) AS SrNo, EmpTitle + ' ' + EmpFirstName + ' ' + EmpLastName  As EmpName,EmpPhone, EmpCode, EmpDept,EmpLocation FROM HRA_Employee ORDER BY SRNO ASC";

                dataAdpEmpUpdate = new SqlDataAdapter(strLoadEmpDataInGrid, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                updateEmpCon.con_open();
                dst_emp_update = new DataSet();
                dataAdpEmpUpdate.Fill(dst_emp_update, "HRA_Employee");
                updateEmpCon.close_con();
                rowcount = dst_emp_update.Tables["HRA_Employee"].Rows.Count;
                if (rowcount > 0)
                {
                    grdViewEmployeeLisToUpdate.AutoGenerateColumns = false;
                    grdViewEmployeeLisToUpdate.DataMember = "HRA_Employee";
                    grdViewEmployeeLisToUpdate.DataSource = dst_emp_update;
                    grdViewEmployeeLisToUpdate.DataBind();
                    grdViewEmployeeLisToUpdate.Visible = true;
                }

                else
                {
                    lblErrorMsgOnUpdateGrid.Text = " There is no leave application found";
                }
            }
            catch (Exception ex)
            {
                lblErrorMsgOnUpdateGrid.Text = ex.Message.ToString();
            }
        }
    }




    public void SaveEmployeeProfile()
    {
        try
        {

            FileUpload img = (FileUpload)EmpProfilePic;
            Byte[] imgByte = null;
            if (img.HasFile && img.PostedFile != null)
            {
                //To create a PostedFile
                HttpPostedFile File = EmpProfilePic.PostedFile;
                //Create byte Array with file len
                imgByte = new Byte[File.ContentLength];
                //force the control to load data in array
                File.InputStream.Read(imgByte, 0, File.ContentLength);
            }


            FileUpload img2 = (FileUpload)EmpAadharCopy;
            Byte[] imageByte2 = null;
            if (img.HasFile && img.PostedFile != null)
            {
                //To create a PostedFile
                HttpPostedFile File = EmpAadharCopy.PostedFile;
                //Create byte Array with file len
                imageByte2 = new Byte[File.ContentLength];
                //force the control to load data in array
                File.InputStream.Read(imageByte2, 0, File.ContentLength);
            }


            FileUpload img3 = (FileUpload)empIDCopy;
            Byte[] imageByte3 = null;
            if (img.HasFile && img.PostedFile != null)
            {
                //To create a PostedFile
                HttpPostedFile File = empIDCopy.PostedFile;
                //Create byte Array with file len
                imageByte3 = new Byte[File.ContentLength];
                //force the control to load data in array
                File.InputStream.Read(imageByte3, 0, File.ContentLength);
            }

            string EmpDOB = Request.Form[dtEmpDob.UniqueID];
            string aAttDtTime = Convert.ToDateTime(EmpDOB).ToString();
            EmpDOB = aAttDtTime;

            string EmpDOJ = Request.Form[txtDtOfJoining.UniqueID];
            string DtEmpDOJ = Convert.ToDateTime(EmpDOJ).ToString();
            EmpDOJ = DtEmpDOJ;


            string empDOL = Request.Form[txtEmpPreEmpLeave.UniqueID];
            string dtEmpDOL  = Convert.ToDateTime(empDOL).ToString();
            empDOL = dtEmpDOL;


            update_employee_record = "INSERT into HRA_Employee(EmpTitle, EmpFirstName, EmpMiddleName, EmpLastName, CreatedBy,LastModifiedBy,"
                + "EmpFHTitle, EmpFHName, EmpDOB, EmpPlaceBirth, EmpMarriageStatus, EmpNationality, EmpGender, EmpBloodGroup, EmpHighEducation,"
                + "EmpPreEmployer, EmpTotalExp, EmpPreDesignation, EmpDateOfJoin, EmpDept, EmpDesignation, EmpJobType, EmpWorkingStatus, EmpEmail,"
                + "EmpRoleID, EmpPhone, EmpDivision, EmpLocation, EmpTeamName, EmpReportingTo, EmpAddress1, EmpTown, EmpCity, EmpState, EmpCountry,"
                + "EmpPincode, EmpPAN, EmpUAN, empEsicNumber, EmpPRAN, EmpBankName, EmpBankAcNo, EmpBankMicrCode, EmpBankIFSC, EmpBankBranch,"
                + "EmpBankAccType, BasicPay, HRA, EducationAllowance, LTA, ESIC, Conveyance, PF_Amount, PT_Amount, EmpSalOtherDed, GrandGrossPay,"
                + "GrandDedAmount, NetPay, PL_Leave, CL_Leave, Total_Leave, Balance_Leave,EmpMobile, EmpPassword,  EmpHobbies, EmpSalPayGrade, SL_Leave, EmpPreEmpDOL,EmpIDProof, EmpAddProof,EmpProfileImg,"
                + "EmpFileName,EmpFileConType,ppLen,EmpFileName2,EmpFileConType2,IDLen,EmpFileName3, EmpFileConType3, AdhaLen)"
                + "VALUES(@a1, @a2, @a3, @a4, @a5, @a6, @a7, @a8, @a9, @a10, @a11, @a12, @a13, @a14, @a15, @a16, @a17, @a18, @a19, @a20, @a21,"
                + "@a22, @a23, @a24, @a25, @a26, @a27, @a28, @a29, @a30, @a31, @a32, @a33, @a34, @a35, @a36, @a37, @a38, @a39, @a40, @a41, @a42,"
                + "@a43, @a44, @a45, @a46, @a47, @a48, @a49, @a50, @a51, @a52, @a53, @a54, @a55, @a56, @a57, @a58, @a59, @a60, @a61, @a62,@a63, @a64, @a65, @a66, @a67,"
                + "@a68, @a69, @a70, @a71,@a72, @a73, @a74, @a75,@a76, @a77, @a78, @a79,@a80)";

            
           

            dataAdpEmpUpdate = new SqlDataAdapter(update_employee_record, ConfigurationManager.ConnectionStrings["HRAString"].ToString());

            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a1", drpEmpTitle.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a2", txtFirstName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a3", txtEmpMiddleName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a4", txtEmpLastName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a5", Session["EmpName"].ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a6", Session["EmpName"].ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a7", drpFathHusName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a8", txtBoxFHName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a9", Convert.ToDateTime(EmpDOB.ToString()));
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a10", txtEmpPlaceOfBirth.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a11", drpMaritalStatus.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a12", drpNationality.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a13", drpEmpGen.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a14", drpEmpBloodGroup.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a15", drpEmpEducationHigh.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a16", txtPreEmployer.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a17", txtPreEmpExp.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a18", txtPreEmpDesignation.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a19", Convert.ToDateTime(EmpDOJ.ToString()));
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a20", drpDept.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a21", drpDesignation.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a22", drpJobType.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a23", "Working");
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a24", txtEmpEmail.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a25", DrpEmpRoleID.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a26", txtEmpPhone.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a27", drpEmpWorkDivision.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a28", drpEmpWorkLocation.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a29", drpEmpTeamName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a30", drpEmpReportingMgr.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a31", txtEmpCompleteAddress.InnerText.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a32", txtEmpTownName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a33", txtEmpCityName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a34", txtEmpStateName.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a35", drpEmpCountry.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a36", txtEmpAddPincode.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a37", txtEmpPAN.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a38", txtPfUan.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a39", txtEmpESICNo.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a40", txtPranPension.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a41", txtEmpBank.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a42", txtEmpBankAcNo.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a43", txtEmpBankMICR.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a44", txtEmpBankIFSC.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a45", txtEmpbankBranch.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a46", drpEmpAcType.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a47", txtBasicSal.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a48", txtHRA_Amount.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a49", txtEduAmount.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a50", txtLTAampunt.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a51", txtESICAmount.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a52", txtEmpConveyance.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a53", txtPFamount.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a54", txtPTAmount.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a55", txtEmpSalOtherDed.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a56", txtTotalEarning.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a57", txtDedAmount.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a58", txtNetSalary.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a59", txtPLDays.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a60", txtCLDays.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a61", txtTotalLeave.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a62", txtTotalLeave.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a63", txtEmpMobile.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a64", txtFirstName.Text.ToString());//PassKey
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a65", txtEmpHobbies.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a66", drpEmpPayingGrade.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a67", txtSLDays.Text.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a68", Convert.ToDateTime(empDOL.ToString()));
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a69", imageByte3);//PP Image
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a70", imageByte2); // Aadhar
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a71", imgByte);// ID
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a72", EmpProfilePic.FileName.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a73", EmpProfilePic.PostedFile.ContentType);
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a74", EmpProfilePic.PostedFile.ContentLength);
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a75", EmpAadharCopy.FileName.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a76", EmpAadharCopy.PostedFile.ContentType);
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a77", EmpAadharCopy.PostedFile.ContentLength);
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a78", empIDCopy.PostedFile.ContentType);
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a79", empIDCopy.PostedFile.FileName.ToString());
            dataAdpEmpUpdate.SelectCommand.Parameters.AddWithValue("@a80", empIDCopy.PostedFile.ContentLength);

        
            dst_emp_update = new DataSet();
            con_emp_update.con_open();
            dataAdpEmpUpdate.Fill(dst_emp_update, "HRA_Employee");
            con_emp_update.close_con();

            lblAddEmpErrorMsg.Text = "Employee data has been saved. Login credentials have been sent on provided Email ID of Employee";
            lblAddEmpErrorMsg.ForeColor = System.Drawing.Color.Green;


        } catch(Exception ex)
        { lblAddEmpErrorMsg.Text = ex.ToString(); }
    }

    protected void LoadManagers()
    {
        try
        {
            LoadManagerNames = "select EmpTitle + ' ' + EmpFirstName + ' ' + EmpLastName  As EmpName from HRA_Employee with(nolock)";

            da_update = new SqlDataAdapter(LoadManagerNames, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
            //da.SelectCommand.Parameters.AddWithValue("@Empe", Session["EmpEmail"].ToString());
            con_emp_update.con_open();
            ds_update = new DataSet();
            da_update.Fill(ds_update, "HRA_Employee");
            con_emp_update.close_con();
            rowcount = ds_update.Tables["HRA_Employee"].Rows.Count;
            if (rowcount > 0)
            {
                drpEmpReportingMgr.DataSource = ds_update.Tables["HRA_Employee"];
                drpEmpReportingMgr.DataBind();
                drpEmpReportingMgr.DataTextField = "EmpName";
                drpEmpReportingMgr.DataValueField = "EmpName";
                drpEmpReportingMgr.DataBind();
                
            }
            else
            {
                Response.Write("<script>alert('Employee names not loaded.')</script>");
                
            }
        }
        catch (Exception ex)
        {
            lblAddEmpErrorMsg.Text = "Reports to: Contact Not Loaded";
        }
    }

    protected void lblCountLeaveForEmp_Click(object sender, EventArgs e)
    {
        double CL = Convert.ToDouble(txtCLDays.Text);
        double PL = Convert.ToDouble(txtPLDays.Text);
        double SL = Convert.ToDouble(txtSLDays.Text);
        double TL = Convert.ToDouble(CL + PL + SL);
        txtTotalLeave.Text = Convert.ToDouble(TL).ToString();
    }
    protected void btnSumNetSalary_Click(object sender, EventArgs e)
    {
        double bs_amt = Convert.ToDouble(txtBasicSal.Text);

        double hra_amt = Convert.ToDouble((txtHRA_Amount.Text));
        double final_hra = Convert.ToDouble(((bs_amt * hra_amt)) / 100);


        double pt_amt = Convert.ToDouble(txtPTAmount.Text);
        double final_pt = Convert.ToDouble(((bs_amt * pt_amt)) / 100);

        double ea_amt = Convert.ToDouble(txtEduAmount.Text);
        double final_ea_amt = Convert.ToDouble(((bs_amt * ea_amt)) / 100);

        double lt_amt = Convert.ToDouble(txtLTAampunt.Text);
        double final_lt_amt = Convert.ToDouble(((bs_amt * lt_amt)) / 100);

        double esic_amt = Convert.ToDouble(txtESICAmount.Text);
        double final_esic_amt = Convert.ToDouble(((bs_amt * esic_amt)) / 100);

        double pf_amt = Convert.ToDouble(txtPFamount.Text);
        double final_pf_amt = Convert.ToDouble(((bs_amt * pf_amt)) / 100);

        double ca_amt = Convert.ToDouble(txtEmpConveyance.Text);
        double final_ca_amt = Convert.ToDouble(((bs_amt * ca_amt)) / 100);

        double od_amt = Convert.ToDouble(txtEmpSalOtherDed.Text);

        double tot_ded = Convert.ToDouble(final_pf_amt + final_pt + od_amt);
        double tot_ear = Convert.ToDouble(bs_amt + final_hra + final_ea_amt + final_lt_amt + final_ca_amt + final_esic_amt);
        double net_salary = Convert.ToDouble(tot_ear-tot_ded);

        txtDedAmount.Text = Convert.ToDouble(tot_ded).ToString();
        txtTotalEarning.Text = Convert.ToDouble(tot_ear).ToString();
        txtNetSalary.Text = Convert.ToDouble(net_salary).ToString();

    }




}



//using System;
//using System.Collections.Generic;
//using System.Web;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.IO;
//using System.Data.SqlClient;
//using System.Configuration;

//public partial class _Default : System.Web.UI.Page
//{
//    protected void btn_Upload_Click(object sender, EventArgs e)
//    {
//        if (FileToUpload.PostedFile == null || String.IsNullOrEmpty(FileToUpload.PostedFile.FileName) || FileToUpload.PostedFile.InputStream == null)
//        {
//            lit_Status.Text = “< br /> Error – unable to upload file. Please try again.< br />”;
//            }
//else
//{
//                using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings[“ConnectionString”].ConnectionString))
//                {
//                    try
//                    {
//                        const string SQL = “INSERT INTO[BinaryTable] ([FileName], [DateTimeUploaded], [MIME], [BinaryData]) VALUES(@FileName, @DateTimeUploaded, @MIME, @BinaryData)”;
//SqlCommand cmd = new SqlCommand(SQL, Conn);
//    cmd.Parameters.AddWithValue(“@FileName”, FileName.Text.Trim());
//cmd.Parameters.AddWithValue(“@MIME”, FileToUpload.PostedFile.ContentType);

//byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
//    FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
//cmd.Parameters.AddWithValue(“@BinaryData”, imageBytes);
//cmd.Parameters.AddWithValue(“@DateTimeUploaded”, DateTime.Now);

//Conn.Open();
//cmd.ExecuteNonQuery();
//lit_Status.Text = “<br />File successfully uploaded – thank you.<br />”;
//    Conn.Close();
//}
//catch
//{
//Conn.Close();
//}
//}
//}
//}
//}


// Iamge Showing
//public class ShowImage : IHttpHandler
//{
//    public void ProcessRequest(HttpContext context)
//    {
//        Int32 empno;
//        if (context.Request.QueryString["id"] != null)
//            empno = Convert.ToInt32(context.Request.QueryString["id"]);
//        else
//            throw new ArgumentException("No parameter specified");

//        context.Response.ContentType = "image/jpeg";
//        Stream strm = ShowEmpImage(empno);
//        byte[] buffer = new byte[4096];
//        int byteSeq = strm.Read(buffer, 0, 4096);

//        while (byteSeq > 0)
//        {
//            context.Response.OutputStream.Write(buffer, 0, byteSeq);
//            byteSeq = strm.Read(buffer, 0, 4096);
//        }
//        //context.Response.BinaryWrite(buffer);
//    }

//    public Stream ShowEmpImage(int empno)
//    {
//        string conn = ConfigurationManager.ConnectionStrings["EmployeeConnString"].ConnectionString;
//        SqlConnection connection = new SqlConnection(conn);
//        string sql = "SELECT empimg FROM EmpDetails WHERE empid = @ID";
//        SqlCommand cmd = new SqlCommand(sql, connection);
//        cmd.CommandType = CommandType.Text;
//        cmd.Parameters.AddWithValue("@ID", empno);
//        connection.Open();
//        object img = cmd.ExecuteScalar();
//        try
//        {
//            return new MemoryStream((byte[])img);
//        }
//        catch
//        {
//            return null;
//        }
//        finally
//        {
//            connection.Close();
//        }
//    }

