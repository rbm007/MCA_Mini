﻿<%@ Page Title="" Language="C#" MasterPageFile="~/admins/AdminMasterPage.master" AutoEventWireup="true" CodeFile="update-profile.aspx.cs" Inherits="comman_pages_myprofile" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ContentPlaceHolderID="pageDataContainer" runat="server" Visible="true" ID="empProfile">
    <div class="ntraining" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Employee Profile System Manager</div>
        <div class="clear"></div>
        <div class="empProfileSideBar" runat="server" id="empPSideBar">
            <div class="formMjr multiAccordion">
                <div class="empProfileSummary" runat="server">
                    <%--<fieldset style="padding:2%;">--%>
                    <%--<legend style="text-align:center;"></legend>--%>
                    <table id="tblProperties" style="width: 100%; padding: 0 !important; margin: 0 !important;">
                        <tbody style="width: 100%">
                            <tr>
                                <td colspan="10" style="width: 100%; background-color: orangered; color: white; text-align: center; font-weight: 700;">
                                    
                                    <%=Convert.ToString("Dashbaord: " + Session["EmpName"])%>
                                </td>
                            </tr>

                            <tr>
                                <td>Employee Code</td>
                                <td>
                                    <asp:Label ID="dsEmpCode" class="lbltData" runat="server">IRC14252</asp:Label></td>
                                <td>Employee Full Name</td>
                                <td>
                                    <asp:Label ID="Label1" class="lbltData" runat="server">Ram B Mishra</asp:Label></td>
                            </tr>

                            <tr>
                                <td>Your Date of Joining</td>
                                <td>
                                    <asp:Label ID="Label2" class="lbltData" runat="server"></asp:Label></td>
                                <td>Your Department Name</td>
                                <td>
                                    <asp:Label ID="Label3" class="lbltData" runat="server"></asp:Label></td>
                            </tr>
                            <tr>
                                <td>Your Reputed Desgination</td>
                                <td>
                                    <asp:Label ID="Label4" class="lbltData" runat="server"></asp:Label></td>
                                <td>Your Reporting Manager</td>
                                <td>
                                    <asp:Label ID="Label5" class="lbltData" runat="server"></asp:Label></td>
                            </tr>
                            <tr>
                                <td>Total Applied Leaves</td>
                                <td>
                                    <asp:Label ID="Label6" class="lbltData" runat="server"></asp:Label></td>
                                <td>Total Balance Leaves</td>
                                <td>
                                    <asp:Label ID="Label7" class="lbltData" runat="server"></asp:Label></td>
                            </tr>
                            <tr>
                                <td rowspan="20">
                                    <asp:Image ID="imgEmpProfile" ImageUrl="/../images/rampic.jpg" Height="150px" Width="100px" runat="server" Style="border-radius: 50%; width: auto; border: dotted 1pt orangered;" />
                                    <br />
                                    <hr />
                                    <div>
                                        <br />
                                        <asp:FileUpload CssClass="EmpProfileTabPD" ID="FileUpload1" runat="server" />
                                        <br />
                                        <br />
                                        <asp:Button class="LogBtn" ID="btnsaveProfile" runat="server" OnClick="btnsaveProfile_Click" Text="Save" Style="width: 85px" />
                                        <br />
                                        <br />
                                        <asp:Label ID="lblmessage" runat="server" />
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <%--</fieldset>--%>
                </div>

                <div class="clear">
                </div>
                <h4 id="clkFirstProfileTab" class="EmpProfileTabPD" onclick="showhide1()" style="cursor: pointer;">Personal Details
                                <span itemid="ram" class="right active"></span></h4>
                <div id="empProfileT1" runat="server">
                    <table id="tbl1" cellpadding="0" cellspacing="0" border="0" style="width: 100%; transition: width 2s;">
                        <tr>
                            <td style="width: 35%">
                                <label>First Name&nbsp;<span>*</span></label></td>
                            <td style="width: 65%">
                                <asp:DropDownList runat="server" ID="drpSalutation" Style="float: left; width: 15%; height: auto !important; position: inherit; padding: 2%;">
                                    <asp:ListItem Text="Mr." Value="0" />
                                    <asp:ListItem Text="Mrs." Value="1" />
                                    <asp:ListItem Text="Ms." Value="2" />
                                    <asp:ListItem Text="Smt." Value="3" />
                                    <asp:ListItem Text="Dr." Value="4" />
                                </asp:DropDownList>
                                <asp:TextBox CssClass="profileTxtBox" Style="width: 80%; margin-left: 3%;" ID="txtFirstname" runat="server" MaxLength="100" onkeypress="return EnableKeys(16,event);"
                                    onpaste="return false;" onkeyup="ChangeCase(txtFirstname)"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td>
                                <label>Middle Name&nbsp;</label></td>
                            <td>
                                <asp:TextBox CssClass="profileTxtBox" ID="txtMiddleName" runat="server" MaxLength="25" onkeypress="return EnableKeys(16,event);"
                                    onpaste="return false;" onkeyup="ChangeCase(txtMiddleName)"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td>
                                <label>Last Name&nbsp;<span>*</span></label></td>
                            <td>
                                <asp:TextBox CssClass="profileTxtBox" ID="txtlastname" runat="server" MaxLength="25" onkeypress="return EnableKeys(16,event);"
                                    onpaste="return false;" onkeyup="ChangeCase(txtlastname)"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email&nbsp;<span>*</span></label></td>
                            <td>
                                <asp:TextBox CssClass="profileTxtBox" ID="txtEmailAdd" runat="server" MaxLength="78" onpaste="return false;"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td>
                                <label>Date of Birth&nbsp;<span>*</span></label></td>
                            <td>

                                <cc1:CalendarExtender TargetControlID="dtStartLeave" runat="server" FirstDayOfWeek="Monday" Format="dd-MMM-yyyy"></cc1:CalendarExtender>
                                <%--<cc1:MaskedEditExtender ID="dateTo" runat="server" TargetControlID="dtTo" Mask="99/AAA/9999 99:99" MaskType="DateTime" UserDateFormat="DayMonthYear"></cc1:MaskedEditExtender>--%>
                                <asp:TextBox ID="dtStartLeave" runat="server" Height="30" Width="100%" ToolTip="eg. 15-Jan-2017" ReadOnly="False" onkeypress="return false;" onkeydown="return false"
                                    onpaste="return false;" />
                        </tr>
                        <tr>
                            <td>
                                <label>Mobile No.&nbsp;<span>*</span></label></td>
                            <td>
                                <asp:TextBox ID="txtMobile" runat="server" MaxLength="50" CssClass="profileTxtBox" onkeypress="return EnableKeys(18,event);" onpaste="return false;"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td>
                                <label>Place of Birth&nbsp;</label></td>
                            <td>
                                <asp:TextBox ID="txtplaceOfBirth" runat="server" CssClass="profileTxtBox" MaxLength="80"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td>
                                <label>Gender&nbsp;</label></td>
                            <td>
                                <asp:DropDownList runat="server" ID="DrpDownGen" CssClass="profileTxtBox">
                                    <asp:ListItem Text="Male" Value="0" />
                                    <asp:ListItem Text="Female" Value="1" />
                                    <asp:ListItem Text="Other" Value="2" />
                                </asp:DropDownList>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Nationality</label></td>
                            <td>
                                <asp:DropDownList ID="drpNationality" DataTextField="Title" DataValueField="RID" runat="server"></asp:DropDownList>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Marital Status</label></td>
                            <td>
                                <asp:DropDownList ID="drpmaritialstatus" DataTextField="Title" DataValueField="RID" runat="server"></asp:DropDownList>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Passport No.&nbsp;<span>*</span></label></td>
                            <td>
                                <asp:TextBox ID="txtPassport" runat="server" MaxLength="10" onpaste="return false;" onkeypress="return EnableKeys(1,event);"></asp:TextBox></td>
                        </tr>
                    </table>
                </div>
                <div class="multiAccordion">
                    <h4 class="EmpProfileTabPD" onclick="showhide2()" style="cursor: pointer;">Contact Details
                                <span itemid="ram2" class="right active"></span>
                    </h4>
                    <div class="displayNn">
                        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                            <ContentTemplate>
                                <table id="tbl2" cellpadding="0" cellspacing="0" border="0" style="width: 100%">
                                    <tr>
                                        <td style="width: 35%" valign="top">
                                            <label>Address</label></td>
                                        <td style="width: 65%">
                                            <asp:TextBox ID="txtAddress" runat="server" MaxLength="200" onchange="testLength(this)" onkeyup="testLength(this)" onpaste="testLength(this)" TextMode="MultiLine"></asp:TextBox></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>Pincode</label></td>
                                        <td>
                                            <asp:TextBox ID="txtpinCode" runat="server" MaxLength="6" onkeypress="return EnableKeys(2,event);" Style="width: 85px;" onpaste="return false;" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>Country</label></td>
                                        <td>
                                            <asp:DropDownList ID="drpCountry" runat="server" DataTextField="Title" DataValueField="RID" AutoPostBack="true"></asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>State</label></td>
                                        <td>
                                            <asp:DropDownList ID="drpState" runat="server" DataTextField="Title" DataValueField="RID" AutoPostBack="true"></asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>City</label></td>
                                        <td>
                                            <asp:DropDownList ID="drpCity" runat="server" DataTextField="Title" DataValueField="RID"></asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Phone No. (Residence)</td>
                                        <td>
                                            <asp:TextBox ID="txtPhoneRes" runat="server" MaxLength="15" onkeypress="return EnableKeys(2,event);" onpaste="return false;" /></td>
                                    </tr>
                                    <tr>
                                        <td>Phone No. (Office)</td>
                                        <td>
                                            <asp:TextBox ID="txtPhoneOff" runat="server" MaxLength="15" onkeypress="return EnableKeys(2,event);" onpaste="return false;" /></td>
                                    </tr>
                                    <tr>
                                        <td>Mobile No.</td>
                                        <td>
                                            <asp:TextBox runat="server" ID="txtCountryCode" Text="+91" MaxLength="5" onkeypress="return EnableKeys(2,event);"
                                                onpaste="return false;" Width="50px"></asp:TextBox>&nbsp
                                                        <asp:TextBox ID="txtMobileOther" runat="server" Style="width: 192px;" MaxLength="10" onkeypress="return EnableKeys(2,event);"
                                                            onpaste="return false;" />
                                        </td>
                                    </tr>
                                    <tr class="brdbtm1px">
                                        <td colspan="2"></td>
                                    </tr>
                                </table>
                            </ContentTemplate>
                        </asp:UpdatePanel>
                    </div>
                </div>
                <div class="accordiontm">
                    <h4>Attachments
                                <span class="right"></span>
                    </h4>
                    <div class="displayNn">
                        <table cellpadding="0" cellspacing="0" border="0" style="width: 100%">
                            <tr>
                                <td style="width: 35%" valign="top">
                                    <label><strong>Upload your resume</strong></label></td>
                                <td style="width: 65%">
                                    <asp:FileUpload ID="txtfileresume" runat="server" />
                                    <div style="display: inline">
                                        <br />
                                        <asp:Button ID="btnattachresume" runat="server" CssClass="buttonGrey w120px " Text="View Resume" Style="margin-top: 4px;" />
                                        <asp:Label runat="server" ID="lblResumeName" Style="color: green; font-size: 8pt; margin-top: 5px;" Text="" />
                                        <br />
                                        <small>Attach .doc,.docx, .rtf and .pdf  files only. Max file size 2MB.</small>
                                    </div>

                                </td>
                            </tr>
                            <tr>
                                <td valign="top">
                                    <label><strong>Upload your passport size photo</strong></label></td>
                                <td>
                                    <asp:FileUpload ID="txtfilephoto" runat="server" />

                                    <div style="display: inline">
                                        <br />
                                        <asp:Button ID="btnattachephoto" runat="server" CssClass="buttonGrey w120px " Text="View Photo" Style="margin-top: 4px;" />
                                        <asp:Label runat="server" ID="lblPhotoName" Style="color: green; font-size: 8pt; margin-top: 5px;" Text="" />
                                        <br />
                                        <small>Attach .png, .jpg, .jpeg and .gif files only. Max file size 2MB.</small>
                                    </div>

                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div>
                    <table style="width: 100%">
                        <tr>
                            <td class="center">
                                <asp:Button ID="btnUpdateProfile" Text="Submit" runat="server" CssClass="button marR5px w65px marT10px" />
                                <asp:Button ID="btnclearDataProfile" Text="Clear" runat="server" CssClass="button w65px marT10px" />
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="clear"></div>
                <asp:Panel runat="server" ID="diverr" Visible="false">
                    <table cellpadding="0" cellspacing="0" border="0" style="width: 100%; height: 40px;">
                        <tr valign="top">
                            <td align="center" valign="middle" style="text-align: center !important;">
                                <asp:Label runat="server" ID="lblApplyInfo" Text="You are successfully applied to the requirement" />
                            </td>
                            <td style="width: 16px;"></td>
                        </tr>
                    </table>
                </asp:Panel>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</asp:Content>
<%-- Add content controls here --%>
