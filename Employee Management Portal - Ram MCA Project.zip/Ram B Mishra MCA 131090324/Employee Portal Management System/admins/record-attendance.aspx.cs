﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Globalization;
public partial class record_employee_attendance : System.Web.UI.Page
{
    con_properties attCon = new con_properties();
    SqlDataAdapter sdaAttend;
    SqlCommand cmd;

    DataSet dst;
    string strLoadAllQueries;
    int countrow;
    string UserNameFullName;
    string UpdateLeaveStatus;
    string getAttTime;

    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        LastAttendanceUpdated();
        LoadEmployeeForAttendance();
        dtAttendanceSelectedForEmp.Text = DateTime.Now.ToString("dd-MMM-yyyy dddd");
        
        //DateTime dt2 = new DateTime();
        //dt2 = DateTime.ParseExact(txtAttendanceSystemDate.Text.ToString(), "dd-MMM-yyyy dddd", CultureInfo.InvariantCulture);
        //DateTime dateTime = new DateTime();
        //dateTime = DateTime.ParseExact(dt2.ToString(), "dd-MMM-yyyy dddd", CultureInfo.InvariantCulture);
    }
    protected void LastAttendanceUpdated()
    {
        if (!this.IsPostBack)
        {
            try
            {
                getAttTime = "SELECT TOP 1 RID, FORMAT(AttMarkedDate,'hh:mm:ss tt') As AtTime, FORMAT(AttMarkedDate,'dd-MMM-yyyy dddd') As AttDate FROM EmpAttendance";
                sdaAttend = new SqlDataAdapter(getAttTime, ConfigurationManager.ConnectionStrings["HRAString"].ToString());

                dst = new DataSet();

                attCon.con_open();
                sdaAttend.Fill(dst, "EmpAttendance");
                attCon.close_con();
                countrow = dst.Tables["EmpAttendance"].Rows.Count;
                if (countrow > 0)
                {
                    string updatedTime = dst.Tables["EmpAttendance"].Rows[0]["AtTime"].ToString();
                    string updatedDate = dst.Tables["EmpAttendance"].Rows[0]["AttDate"].ToString();
                    lblLastAttendanceUpdated.Text = "Last Attendance Updated On <b>" + updatedDate.ToString() + "</b> at <b>" + updatedTime.ToString()+ "</b>. Updating duplicate attendance is not allowed.<hr>";
                                       
                }
                else
                {
                    lblErrorMsgOnLeaveGrid.Text = "There is No Attendance Pending for Today.";
                }
            }
            catch (Exception ex)
            {
                lblErrorMsgOnLeaveGrid.Text = ex.ToString();
            }

        }

    }

    public void LoadEmployeeForAttendance()
    {
        if (!this.IsPostBack)
        {
            try
            {
                //strLoadAllQueries = "SELECT  ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo,H.EMPRID As EmpNo, H.EmpCode,H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,"
                //+ " H.EmpDept from HRA_Employee H LEFT Join EmpAttendance L On H.EMPRID = L.EmpAttID WHERE EmpWorkingStatus In('Working')And Format(L.attDate, 'dd-MMM-yyyy') != Format(CURRENT_TIMESTAMP, 'dd-MMM-yyy') AND "
                //+ " Format(L.attDate, 'dd-MMM-yyyy') !< Format(CURRENT_TIMESTAMP, 'dd-MMM-yyy')";

                strLoadAllQueries = "SELECT  ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo,H.EMPRID As EmpNo, H.EmpCode,H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,"
                + " H.EmpDept from HRA_Employee H WHERE EmpWorkingStatus In('Working')";

                sdaAttend = new SqlDataAdapter(strLoadAllQueries, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                attCon.con_open();
                dt = new DataTable();
                sdaAttend.Fill(dt);
                attCon.close_con();
                
               if (dt.Rows.Count>0)
                {
                    grdViewLeaveRecords.AutoGenerateColumns = false;
                    grdViewLeaveRecords.DataMember = "HRA_Employee";
                    grdViewLeaveRecords.DataSource = dt ;
                    grdViewLeaveRecords.DataBind();
                    grdViewLeaveRecords.Visible = true;

                    //string formatDt = "dd-MMM-yyyy dddd";
                    //DateTime.ParseExact(dtAttendanceSelectedForEmp.Text.ToString(), (formatDt).ToString(), CultureInfo.InvariantCulture).ToString();
                }
                else
                {
                    lblErrorMsgOnLeaveGrid.Text = "There is No Attendance Pending for Today.";
                }
            }
            catch (Exception ex)
            {
                lblErrorMsgOnLeaveGrid.Text = ex.Message.ToString();
            }

        }
    }
    protected void btnUpdateLeaveStatus_Click(object sender, EventArgs e)
    {

    }

    protected void btnMarkAttendance_Click(object sender, EventArgs e)
    {

        string dt = Request.Form[dtAttendanceSelectedForEmp.UniqueID];
        //DateTime myDate = DateTime.ParseExact(dt.ToString(), "dd-MMM-yyyy dddd", System.Globalization.CultureInfo.InvariantCulture);

        try
        {

            foreach (GridViewRow row in grdViewLeaveRecords.Rows)
            {
                //insertAttendance = "INSERT into EmpAttendance(EmpAttID, EmpCode, EmpName, EmpDept, AttDate, AttStatus, AttMode, AttMarkBy) VALUES "

                int aID = Convert.ToInt32(((Label)row.FindControl("lblEmpNoGrd")).Text);
                String aEmpCode = (((Label)row.FindControl("lblEmpCodeGrd")).Text);
                String aEmpName = (((Label)row.FindControl("lblEmpNameGrd")).Text);
                String aEmpDept = (((Label)row.FindControl("lblEmpDeptGrd")).Text);
                String aAttDtTime = Convert.ToDateTime(dt).ToString();
                String AttStatus = "";
                RadioButton rdbt1 = (row.Cells[4].FindControl("R1") as RadioButton); //P
                RadioButton rdbt2 = (row.Cells[4].FindControl("R2") as RadioButton); //A
                RadioButton rdbt3 = (row.Cells[4].FindControl("R3") as RadioButton); //O
                RadioButton rdbt4 = (row.Cells[4].FindControl("R4") as RadioButton); //PL
                RadioButton rdbt5 = (row.Cells[4].FindControl("R5") as RadioButton); //UL

                if (rdbt1.Checked || rdbt3.Checked || rdbt4.Checked)
                {AttStatus = "P";}
                else if (rdbt2.Checked || rdbt5.Checked)
                {AttStatus = "A".ToString();}
                String markAttMode = "Online";
                String markAttMarkedBy = Session["EmpName"].ToString();



                sdaAttend = new SqlDataAdapter("insert_multiple_row", ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sdaAttend.SelectCommand.CommandType = CommandType.StoredProcedure;
               
                sdaAttend.SelectCommand.Parameters.AddWithValue("@EID", aID.ToString());
                sdaAttend.SelectCommand.Parameters.AddWithValue("@ECod", aEmpCode.ToString());
                sdaAttend.SelectCommand.Parameters.AddWithValue("@Ename", aEmpName.ToString());
                sdaAttend.SelectCommand.Parameters.AddWithValue("@EmpDt", aEmpDept.ToString());
                sdaAttend.SelectCommand.Parameters.AddWithValue("@AttDt", Convert.ToDateTime(aAttDtTime.ToString()));
                sdaAttend.SelectCommand.Parameters.AddWithValue("@attst", AttStatus.ToString());
                sdaAttend.SelectCommand.Parameters.AddWithValue("@attMd", markAttMode.ToString());
                sdaAttend.SelectCommand.Parameters.AddWithValue("@attMarkBy", markAttMarkedBy.ToString());

                dst = new DataSet();
                attCon.con_open();
                sdaAttend.Fill(dst, "EmpAttendance");
                attCon.close_con();


                lblErrorMsgOnLeaveGrid.ForeColor = System.Drawing.Color.Green;
                lblErrorMsgOnLeaveGrid.Text = "<br><br>Attendance has been updated for " + dt.ToString() + " .";
                
            }
        }
        catch (Exception ex)
        {
            lblErrorMsgOnLeaveGrid.Text = ex.Message.ToString();
        }
        ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Attendance has been updated successfully');", true);
        
    }

    protected void btnResetAttendance_Click(object sender, EventArgs e)
    {
        LoadEmployeeForAttendance();
    }

    protected void DtSelectedDateForEmpAtt_Load(object sender, EventArgs e)
    {
        //DateTime myDt  = DateTime.ParseExact(DtSelectedDateForEmpAtt.SelectedDate.ToString(), "dd-MMM-yyyy dddd", System.Globalization.CultureInfo.InvariantCulture);
        //dtAttendanceSelectedForEmp.Text = myDt.ToString();
    }

    protected void btnHistoryAtt_Click(object sender, EventArgs e)
    {
        Response.Redirect(@"~/hrs/attendance-history.aspx", false);
    }

    protected void btnUpdateAttNewRecord_Click(object sender, EventArgs e)
    {
        Response.Redirect(@"~/hrs/update-attendance.aspx", false);
    }
}