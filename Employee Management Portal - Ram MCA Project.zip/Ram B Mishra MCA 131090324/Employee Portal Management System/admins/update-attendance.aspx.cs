﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Globalization;

public partial class update_employee_attendance : System.Web.UI.Page
{
    con_properties att_update = new con_properties();
    SqlDataAdapter sdaAttUpdate;
    DataSet dst;
    DataTable dt;
    string strLoadAllQueries;
    int countrow;
    string insertAttendance;
    string strLoadEmpEmailCode;
    string dtnew;
    protected void Page_Load(object sender, EventArgs e)
    {

        dtAttUpdateSelectedForEmp.Text = DateTime.Now.ToString("dd-MMM-yyyy dddd");
        dtnew = Request.Form[dtAttUpdateSelectedForEmp.UniqueID];

    }
    protected void btnUpdateAttendance_Click(object sender, EventArgs e)
    {

        string attUpdatedDate = System.DateTime.Now.ToString();

        string dt = Request.Form[dtAttUpdateSelectedForEmp.UniqueID];
        //DateTime myDate = DateTime.ParseExact(dt.ToString(), "dd-MMM-yyyy dddd", System.Globalization.CultureInfo.InvariantCulture);
        try
        {

            foreach (GridViewRow row in grdDataForUpdateAttendance.Rows)
            {
                int EmpIdUpdate = Convert.ToInt32(((Label)row.FindControl("lblEmpNoGrd")).Text);
                String UEmpCode = (((Label)row.FindControl("lblEmpCodeGrd")).Text);
                String UEmpName = (((Label)row.FindControl("lblEmpNameGrd")).Text);
                String UEmpDept = (((Label)row.FindControl("lblEmpDeptGrd")).Text);
                String UAttDtTime = Convert.ToDateTime(dt).ToString();
                String UAttStatus = "";
                RadioButton rdbt1 = (row.Cells[4].FindControl("R1") as RadioButton); //P
                RadioButton rdbt2 = (row.Cells[4].FindControl("R2") as RadioButton); //A
                RadioButton rdbt3 = (row.Cells[4].FindControl("R3") as RadioButton); //O
                RadioButton rdbt4 = (row.Cells[4].FindControl("R4") as RadioButton); //PL
                RadioButton rdbt5 = (row.Cells[4].FindControl("R5") as RadioButton); //UL

                if (rdbt1.Checked || rdbt3.Checked || rdbt4.Checked)
                { UAttStatus = "P"; }
                else if (rdbt2.Checked || rdbt5.Checked)
                { UAttStatus = "A".ToString(); }
                String UpdateAttMode = "Online";
                String UpdateAttBy = Session["EmpName"].ToString();

                sdaAttUpdate = new SqlDataAdapter("update_emp_attendance", ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sdaAttUpdate.SelectCommand.CommandType = CommandType.StoredProcedure;

                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@EMPRID", EmpIdUpdate.ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@ECode", UEmpCode.ToString());
                //sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@Ename", UEmpName.ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@AttDateNew", Convert.ToDateTime(UAttDtTime.ToString()));
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@AttStatusNew", UAttStatus.ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@AttModeNew", UpdateAttMode.ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@AttUpdatedBy", UpdateAttBy.ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@AttMarkedNew", Convert.ToDateTime(attUpdatedDate.ToString())); 

                dst = new DataSet();
                att_update.con_open();
                sdaAttUpdate.Fill(dst, "EmpAttendance");
                att_update.close_con();

            }
            lblErrorMsgOnLeaveGrid.ForeColor = System.Drawing.Color.Green;
            lblErrorMsgOnLeaveGrid.Text = "Attendance is Updated successfully";
            //Response.Write("<script>alert('Attendance saved successfully");
        }
        catch (Exception ex)
        {
            lblErrorMsgOnLeaveGrid.Text = ex.Message.ToString();
        }
    }

    protected void DtSelectedDateForEmpAtt_Load(object sender, EventArgs e)
    {
        //DateTime myDt  = DateTime.ParseExact(DtSelectedDateForEmpAtt.SelectedDate.ToString(), "dd-MMM-yyyy dddd", System.Globalization.CultureInfo.InvariantCulture);
        //dtAttendanceSelectedForEmp.Text = myDt.ToString();
    }

    protected void btnAttUpdate_Click(object sender, EventArgs e)
    {

        string selectDt = Request.Form[dtAttUpdateSelectedForEmp.UniqueID];
        String selectAttDtTime = Convert.ToDateTime(dtnew).ToString();
        try
            {
strLoadEmpEmailCode = "SELECT TOP 1 ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo, H.EmpRID As EmpNo, H.EmpCode,"
                + "H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,"
                + "H.EmpDept As EmpDept, Format(L.AttDate, 'dd-MMM-yyyy dddd') As 'AttendanceDate',"
                + "CASE WHEN L.AttStatus = 'P' THEN 'Present' when attStatus = 'A' then 'Absent' WHEN AttStatus = 'O' then 'Present'"
                +" WHEN AttStatus = 'PL' THEN 'Present'WHEN AttStatus = 'UL' THEN 'Absent' END As AttendanceStatus"
                + " from HRA_Employee H RIGHT JOIN EmpAttendance L On H.RID = L.EmpAttID WHERE EmpWorkingStatus In('Working')"
                +" And H.EmpCode = @ec AND L.AttDate=@LDate";

                sdaAttUpdate = new SqlDataAdapter(strLoadEmpEmailCode, ConfigurationManager.ConnectionStrings["HRAString"].ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@ec", txtEmpIdOrEmail.Text.ToString());
                sdaAttUpdate.SelectCommand.Parameters.AddWithValue("@LDate", Convert.ToDateTime(selectAttDtTime.ToString()));
                att_update.con_open();
                dst = new DataSet();
                sdaAttUpdate.Fill(dst, "HRA_Employee");
                att_update.close_con();
                countrow = dst.Tables["HRA_Employee"].Rows.Count;


                if (countrow > 0)
                {
                    grdDataForUpdateAttendance.AutoGenerateColumns = false;
                    grdDataForUpdateAttendance.DataMember = "HRA_Employee";
                    grdDataForUpdateAttendance.DataSource = dst;
                    grdDataForUpdateAttendance.DataBind();
                    //string formatDt = "dd-MMM-yyyy dddd";
                    //DateTime.ParseExact(dtAttendanceSelectedForEmp.Text.ToString(), (formatDt).ToString(), CultureInfo.InvariantCulture).ToString();
                }
                else
                {
                 lblErrorMsgOnLeaveGrid.Text = "No Employee Data Found for Update.";
                }
            }catch (Exception ex)
            {
                lblErrorMsgOnLeaveGrid.Text = ex.Message.ToString();
            }

        }

    protected void btnMarkAttNewHistory_Click(object sender, EventArgs e)
    {
        Response.Redirect("/../hrs/attendance-history.aspx", false);
        
    }

    protected void btnUpdateAttNewAtt_Click(object sender, EventArgs e)
    {
        Response.Redirect(@"~/hrs/record-attendance.aspx", false);
    }

   
}