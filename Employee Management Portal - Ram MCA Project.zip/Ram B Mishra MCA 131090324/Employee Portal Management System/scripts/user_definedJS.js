﻿
function noSundays(date) {
               return [date.getDay() != 0, ''];
           }


$(function () {
    $('.multiAccordion h4').click(function () {
        $(this).toggleClass('active');
        $(this).children().toggleClass('active');
        return false;
    })
})

$(function () {
    $("[id$=dtAttUpdateSelectedForEmp]").datepicker({
        showOn: "button",
        dateFormat: "dd-MM-yy, DD",
        buttonImageOnly: true,
        buttonImage: '/../images/calender.png',
        maxDate: '0',
        minDate: -31,
        beforeShowDay: noSundays
    });
});
                
$(document).ready(function () {
    $("[id*=dtAttUpdateSelectedForEmp]").focus(function () {
        $(this).datepicker("show")
    })
});



$(function () {
    $('#leftSlide').click(function () {
        $("#mySidenav").toggleClass('MySlider');
        $("#mySidenav").children().toggleClass('MySlider');
        return false;
    })
})
                
$(document).ready(function () {
    $("[id*=txtEmpPreEmpLeave]").focus(function () {
        $(this).datepicker("show")
    })
});

        
$(function () {
    $("[id*=txtEmpPreEmpLeave]").datepicker({
        dateFormat: "dd-MM-yy, DD ",
        showOn: "button",
        buttonImageOnly: true,
        buttonImage: '/../images/calender.png',
        changeYear: true,
        changeMonth: true,
        showButtonPanel: true,
        beforeShowDay: noSundays,
        maxDate: '0'
    });
});



$(function () {
    $("[id*=txtDtOfJoining]").datepicker({
        dateFormat: "dd-MM-yy, DD",
        showOn: "button",
        buttonImageOnly: true,
        buttonImage: '/../images/calender.png',
        changeYear: true,
        changeMonth: true,
        showButtonPanel: true,
        beforeShowDay: noSundays,
        yearRange: '-1:-1', // Min Age 18 and Max 45 for Age
        maxDate: '30',
        minDate: -30
    });
});
$(document).ready(function () {
    $("[id*=txtDtOfJoining]").focus(function () {
        $(this).datepicker("show")
    })
});

$(function () {
    $("[id*=dtEmpDob]").datepicker({
        dateFormat: "dd-MM-yy, DD",
        showOn: "button",
        buttonImageOnly: true,
        buttonImage: '/../images/calender.png',
        changeYear: true,
        changeMonth: true,
        showButtonPanel: true,
        yearRange: '-45:-18', // Min Age A8 and Max 45 for Age
        maxDate: '0',
    });
});
$(document).ready(function () {
    $("[id*=dtEmpDob]").focus(function () {
        $(this).datepicker("show")
    })
});


$(document).ready(function () {
    $("[id*=dtEndLeave]").focus(function () {
        $(this).datepicker("show")

    })
});

$(function () {
    $("[id*=dtStartLeave]").datepicker({
        dateFormat: "dd-MM-yy, DD",
        showOn: "button",
        buttonImageOnly: true,
        beforeShowDay: noSundays,
        buttonImage: '/../images/calender.png',
        maxDate: 60,
        minDate: -7
    });
});

$(function () {
    $("[id*=dtEndLeave]").datepicker({
        showOn: "button",
        dateFormat: "dd-MM-yy, DD",
        buttonImageOnly: true,
        beforeShowDay: noSundays,
        buttonImage: '/../images/calender.png',
        maxDate: '60',
        minDate: -7
    });
});

$(function () {
    $("[id*=dtLastWorkDay]").datepicker({
        showOn: "button",
        dateFormat: "dd-MM-yy, DD",
        buttonImageOnly: true,
        beforeShowDay: noSundays,
        buttonImage: '/../images/calender.png',
        maxDate: 60,
        minDate: -7
    });
});

$(function () {
    $("[id$=dtAttendanceSelectedForEmp]").datepicker({
        showOn: "button",
        dateFormat: "dd-MM-yy, DD",
        buttonImageOnly: true,
        beforeShowDay: noSundays,
        buttonImage: '/../images/calender.png',
        maxDate: '0',
        minDate: '0'
    });
});

$(document).ready(function () {
    $("[id*=dtStartLeave]").focus(function () {
        $(this).datepicker("show")
    })
});

$(document).ready(function () {
    $("[id*=dtEndLeave]").focus(function () {
        $(this).datepicker("show")

    })
});

$(document).ready(function () {
    $("[id$=dtAttendanceSelectedForEmp]").focus(function () {
        $(this).datepicker("show")

    })
});


$(document).ready(function () {
    $("[id*=dtLastWorkDay]").focus(function () {
        $(this).datepicker("show")
    })
});
</script>
    <script>

        function showhide9() {
            var x11 = document.getElementById("tblPropertiesHistory");
            var root5 = document.getElementsByTagName('span')["*"];

            if (x11.style.display === "none") {
                x11.style.display = "block";
            }
            else {
                x11.style.display = "none";
            }
        }



function showhide8() {
    var xx1 = document.getElementById("tblEmpDocDetails");
    var root4 = document.getElementsByTagName('span')["*"];

    if (xx1.style.display === "none") {
        xx1.style.display = "block";
    }
    else {
        xx1.style.display = "none";
    }
}


function showhide7() {
    var xx = document.getElementById("tblEmpLeaveDetails");
    var root3 = document.getElementsByTagName('span')["*"];

    if (xx.style.display === "none") {
        xx.style.display = "block";
    }
    else {
        xx.style.display = "none";
    }
}

function showhide6() {
    var x2 = document.getElementById("tblEmpidDetails");
    var root2 = document.getElementsByTagName('span')["*"];

    if (x2.style.display === "none") {
        x2.style.display = "block";
    }
    else {
        x2.style.display = "none";
    }
}

function showhide5() {
    var x2 = document.getElementById("tblEmpCTC");
    var root2 = document.getElementsByTagName('span')["*"];

    if (x2.style.display === "none") {
        x2.style.display = "block";

        root2.classList.add('spn');
    }
    else {
        x2.style.display = "none";
        root2.classList.add('spn1');
    }
}


function showhide4() {
    var x2 = document.getElementById("tblPropertiesFamily");
    var root2 = document.getElementsByTagName('span')["*"];

    if (x2.style.display === "none") {
        x2.style.display = "block";

        root2.classList.add('spn');
    }
    else {
        x2.style.display = "none";
        root2.classList.add('spn1');
    }
}

function showhide3() {
    var x1 = document.getElementById("tblProperties");
    var root1 = document.getElementsByTagName('span')["*"];

    if (x1.style.display === "none") {
        x1.style.display = "block";
        root1.classList.add('spn');
    }
    else {
        x1.style.display = "none";
        root1.classList.add('spn1');
    }
}


function showhide1() {
    var x = document.getElementById("tbl1");
    var root = document.getElementsByTagName('span')["*"];

    if (x.style.display === "none") {
        x.style.display = "block";
        root.classList.add('spn');
    }
    else {
        x.style.display = "none";
        root.classList.add('spn1');
    }
}
function showhide2() {
    var y = document.getElementById("tbl2");
    if (y.style.display === "none") {
        y.style.display = "block";
    }
    else {
        y.style.display = "none";
    }
}

// Set timeout variables.
var timoutWarning = 60000; // Display warning in 1Mins.
var timoutNow = 40000; // Timeout in 2 mins.
var logoutUrl = '/../common-errors/ErrorMsg.aspx';

var warningTimer;
var timeoutTimer;

// Start timers.
function StartTimers() {
    warningTimer = setTimeout("IdleWarning()", timoutWarning);
    timeoutTimer = setTimeout("IdleTimeout()", timoutNow);
}

// Reset timers.
function ResetTimers() {
    clearTimeout(warningTimer);
    clearTimeout(timeoutTimer);
    StartTimers();
    $("#timeout").dialog('close');
}

// Show idle timeout warning dialog.
function IdleWarning() {
    $("#timeout").dialog({
        modal: true,
        modal:'show'
    });
}

// Logout the user.
function IdleTimeout() {
    window.location = logoutUrl;
}