﻿Select top 2 * from hra_employee;
Select top 2 * from EmpAttendance;
Select top 2 Leave * from EmpAppliedLeave;

select top 1 E.EmpCode, Sum(L.TotalAppliedDays) As TotalLeave,
COUNT(case when A.AttStatus IN('P', 'O', 'PL') then 1 end) as PresentDays,
COUNT(case when A.AttStatus IN('A', 'UL') then 1 end) as AbsentDays, COUNT(distinct A.AttDate) as Tot_count 
from HRA_Employee E
LEFT OUTER JOIN EmpAttendance A On E.EmpCode = A.EmpCode
LEFT OUTER JOIN EmpAppliedLeave L On E.EmpCode = L.LeaveRefEmpRID
WHERE A.AttDate between '01-Oct-2018' AND '29-Oct-2018' And LeaveRefEmpRID='EMP0000002';
 group by E.EmpCode;

--From EmpAppliedLeave WHERE EmpCode=@EmpC AND (dtLeaveStart BETWEEN @dtLeave1 AND @dtLeave2);

CREATE PROCEDURE GET_ATTENDANCEREPORT   
@STARTDATE DATETIME,  
@ENDDATE DATETIME  
AS BEGIN  
select * from EmpAttendance;
WITH EmpAttendance AS  
(  
       SELECT AttDate=DATEADD(AttDate,0, @STARTDATE)  
       WHERE DATEADD(AttDate, 1, @STARTDATE) <= @ENDDATE  
       UNION ALL  
       SELECT DATEADD(AttDate, 1, DT)  
       FROM EmpAttendance  
       WHERE DATEADD(AttDate, 1, DT) <= @ENDDATE  
)  
    SELECT * INTO #TMP_DATES  
    FROM EmpAttendance   
    DECLARE @COLUMN VARCHAR(MAX)  
    SELECT @COLUMN=ISNULL(@COLUMN+',','')+ '['+ CAST(CONVERT(DATE , T.AttDate) AS VARCHAR) + ']' FROM #TMP_DATES T  
    DECLARE @Columns2 VARCHAR(MAX)  
    SET @Columns2 = SUBSTRING((SELECT DISTINCT ',ISNULL(['+ CAST(CONVERT(DATE , DT) as varchar )+'],''N/A'') AS ['+CAST(CONVERT(DATE , DT) as varchar )+']' FROM #TMP_DATES GROUP BY dt FOR XML PATH('')),2,8000)  
    DECLARE @QUERY VARCHAR(MAX)  
    SET @QUERY = 'SELECT NAME, ' + @Columns2 +' FROM   
    (  
    SELECT A.NAME , B.DT AS DATE, A.PRESENT_STATUS FROM TMP A RIGHT OUTER JOIN #TMP_DATES B ON A.DATE=B.DT   
    ) X  
    PIVOT   
    (  
    MIN([PRESENT_STATUS])  
    FOR [DATE] IN (' + @COLUMN + ')  
    ) P   
    WHERE ISNULL(NAME,'''')<>''''  
    '  
    EXEC (@QUERY)  
    DROP TABLE #TMP_DATES  
    END  

Select  top 1 E.EmpTitle + ' ' + E.EmpFirstName + ' ' + E.EmpMiddleName + ' ' + E.EmpLastName  As EmpName,E.EmpCode,
E.EmpEmail, E.EmpJobType,E.BasicPay,E.HRA, E.EducationAllowance, E.LTA, E.ESIC, E.Conveyance, E.PF_Amount, E.PT_Amount,E.GrandGrossPay,
COUNT(case when A.AttStatus IN('P', 'O', 'PL') then 1 end) as PresentDays,
COUNT(case when A.AttStatus IN('A', 'UL') then 1 end) as AbsentDays, 
COUNT(distinct A.AttDate) as Tot_count,
Sum(L.TotalAppliedDays) As TotalLeave
from HRA_Employee E 
LEFT OUTER JOIN EmpAttendance A ON (E.EmpCode = A.EmpCode)
LEFT OUTER JOIN EmpAppliedLeave L ON (E.EmpCode = L.LeaveRefEmpRID)
WHERE L.LeaveRefEmpRID='EMP0000002' AND (L.dtLeaveStartDate BETWEEN '01-Oct-2018' AND '29-Oct-2018')
And (A.AttDate between '01-Oct-2018' AND '29-Oct-2018') AND 
(E.EmpCode='EMP0000002') GROUP BY E.EmpCode;


Select  top 1 E.EmpCode
SELECT COUNT(case when A.AttStatus IN('P', 'O', 'PL') then 1 end) as PresentDays,
COUNT(case when A.AttStatus IN('A', 'UL') then 1 end) as AbsentDays, 
COUNT(distinct A.AttDate) as Tot_count,
Sum(L.TotalAppliedDays) As TotalLeave
from HRA_Employee E 
RIGHT JOIN EmpAttendance A ON (E.EmpCode = A.EmpCode)
RIGHT JOIN EmpAppliedLeave L ON (E.EmpCode = L.LeaveRefEmpRID)
WHERE L.LeaveRefEmpRID='EMP0000002' AND (L.dtLeaveStartDate BETWEEN '01-Oct-2018' AND '29-Oct-2018')
And (A.AttDate between '01-Oct-2018' AND '29-Oct-2018') AND 
(E.EmpCode='EMP0000002') GROUP BY E.EmpCode;


Select top 2 * from hra_employee;
Select top 2 * from EmpAttendance;
Select top 2 * from EmpAppliedLeave;



SELECT TOP 1 ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo,H.EmpRID As EmpNo, H.EmpCode, 
H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,
H.EmpDept, Format(L.AttDate,'dd-MMM-yyyy dddd') As 'Attendance Date', 
CASE 
when attStatus = 'A' OR AttStatus = 'UL' then (Select Count(*) AttStatus from EmpAttendance Where AttStatus IN('A','UL') Group by AttStatus)
WHEN AttStatus = 'O' Or AttStatus = 'P' Or AttStatus = 'PL'  then (Select Count(*) AttStatus from EmpAttendance Where AttStatus IN('P','PL','O') Group by AttStatus)
END As CurrentAttStatus
from HRA_Employee H RIGHT JOIN EmpAttendance L On H.RID = L.EmpAttID 
WHERE EmpWorkingStatus In('Working') And H.RID=2 AND L.AttDate='22-Oct-2018';



update HRA_Employee Set EmpPassword='mishra' WHERE EmpEmail ='masterofprogramming.mca@gmail.com';



Select LeaveRefEmpRID * from EmpAppliedLeave;

SELECT TOP 1 ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo,H.EmpRID As EmpNo, H.EmpCode, 
H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,
H.EmpDept, Format(L.AttDate,'dd-MMM-yyyy dddd') As 'Attendance Date', 
CASE WHEN L.AttStatus = 'P' THEN 'Present'
when attStatus = 'A' then 'Absent'
WHEN AttStatus = 'O' then 'Present'
WHEN AttStatus = 'PL' THEN 'Present'
WHEN AttStatus = 'UL' THEN 'Absent' 
END As CurrentAttStatus
 from HRA_Employee H RIGHT JOIN EmpAttendance L On H.RID = L.EmpAttID 
WHERE EmpWorkingStatus In('Working') And H.RID=2 AND L.AttDate='22-Oct-2018';


select * from EmpAttendance;
SELECT * FROM HRA_Employee;
select * from 
select dtLeaveStartDate,dtLeaveEndDate from EmpAppliedLeave;
Select  
BasicPay,HRA, EducationAllowance, LTA, ESIC, Conveyance, PF_Amount, PT_Amount,GrandGrossPay
sELECT * from HRA_Employee;



"SELECT Sum(TotalAppliedDays) From EmpAppliedLeave WHERE LeaveRefEmpRID='EMP0000002' AND (dtLeaveStartDate BETWEEN '2018-11-01' AND '2018-11-30')"

select * from emppAYSlips;

SELECT top 1 

drop table emppAYSlips;


Select 
EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName  As EmpName,EmpCode,EmpEmail, EmpJobType From HRA_Employee

WHERE Exists(select
EmpName,Count(AttStatus),
CASE WHEN attStatus = 'P' THEN 'Present'
when attStatus = 'A' then 'Absent'
WHEN AttStatus = 'O' then 'Present'
WHEN AttStatus = 'PL' THEN 'Present'
WHEN AttStatus = 'UL' THEN 'Absent'
Else 'No' END AS EmpCode
from EmpAttendance
Group By EmpName,AttStatus)



SELECT EMPCode FROM HRA_Employee;

select EmpName
      ,count(case when AttStatus IN('P','O','PL') then 1 end) as PresentDays
      ,count(case when AttStatus IN('A','UL') then 1 end) as AbsentDays
      ,count(distinct AttDate) as Tot_count
  from EmpAttendance where AttDate between '2018-10-01' and '2018-10-31' 
   group 
    by EmpName 



Create Table EmpPaySlips
(
RID int identity(1,1) Not Null,
PayslipID int FOREIGN KEY references HRA_Employee (EMPRID),
PaySlipInvoice varchar(2) not null default 'PS',
PaySlipNumber As (PaySlipInvoice+right('000000'+Convert([Varchar](50),[RID]),(10))) PERSISTED primary key,
PaySlipCreatedOn datetime default current_timestamp,
PaySlipCreatedBy varchar(100),
PaySlipMothFor Date,
PayEmpCode varchar(50),
PayEmpName varchar(100),
PayEmpEmail nvarchar(100),
PayTotWorkingDays numeric(4,2),
PayOTDays numeric(4,2),
PayTotAbsentDays numeric(4,2),
PayTotPresentDays numeric(4,2),
PayTotLeaveDays numeric(4,2),
PayTotBalLeave numeric(4,2),
PayEmpDept varchar(50),
PayEmpLocation varchar(50),
PayEmpDesignation varchar(50),
PayEmpDOJ date,
PayEmpPAN VARCHAR(10),
PayEmpPFNo varchar(16),
PayESICNo varchar(18),
PayPRANNo varchar(20),
payBasicAmt numeric(10,2),
payHraAmt numeric (10,2),
PayEduAmt numeric(10,2),
payLTAAmt numeric(10,2), 
payESICAmt numeric(10,2),
payConveyanceAmt numeric(10,2),
payPFAmt numeric(10,2),
payPTAmt numeric(10,2),
payIncentiveAmt numeric(10,2),
payGrandGrossPayAmt numeric(10,2),
payGrandDedAmountAmt numeric(10,2),
payNetPayAmt numeric(10,2),
PayAmtInWords varchar(200),
PayApprovedBy varchar(100))

-- Table Design

CREATE TABLE [dbo].[EmpPaySlips] (
    [RID]                  INT             IDENTITY (1, 1) NOT NULL,
    [PayslipID]            INT             NULL,
    [PaySlipInvoice]       VARCHAR (2)     DEFAULT ('PS') NOT NULL,
    [PaySlipNumber]        AS              ([PaySlipInvoice]+right('000000'+CONVERT([varchar](50),[RID]),(10))) PERSISTED NOT NULL,
    [PaySlipCreatedOn]     DATETIME        DEFAULT (getdate()) NULL,
    [PaySlipCreatedBy]     DATETIME        DEFAULT (getdate()) NULL,
    [PaySlipMothFor]       DATE            NULL,
    [PayEmpCode]           VARCHAR (50)    NULL,
    [PayEmpName]           VARCHAR (100)   NULL,
    [PayEmpEmail]          NVARCHAR (100)  NULL,
    [PayTotWorkingDays]    NUMERIC (4, 2)  NULL,
    [PayOTDays]            NUMERIC (4, 2)  NULL,
    [PayTotAbsentDays]     NUMERIC (4, 2)  NULL,
    [PayTotPresentDays]    NUMERIC (4, 2)  NULL,
    [PayTotLeaveDays]      NUMERIC (4, 2)  NULL,
    [PayTotBalLeave]       NUMERIC (4, 2)  NULL,
    [PayEmpDept]           VARCHAR (50)    NULL,
    [PayEmpLocation]       VARCHAR (50)    NULL,
    [PayEmpDesignation]    VARCHAR (50)    NULL,
    [PayEmpDOJ]            DATE            NULL,
    [PayEmpPAN]            VARCHAR (10)    NULL,
    [PayEmpPFNo]           VARCHAR (16)    NULL,
    [PayESICNo]            VARCHAR (18)    NULL,
    [PayPRANNo]            VARCHAR (20)    NULL,
    [payBasicAmt]          NUMERIC (10, 2) NULL,
    [payHraAmt]            NUMERIC (10, 2) NULL,
    [PayEduAmt]            NUMERIC (10, 2) NULL,
    [payLTAAmt]            NUMERIC (10, 2) NULL,
    [payESICAmt]           NUMERIC (10, 2) NULL,
    [payConveyanceAmt]     NUMERIC (10, 2) NULL,
    [payPFAmt]             NUMERIC (10, 2) NULL,
    [payPTAmt]             NUMERIC (10, 2) NULL,
    [payIncentiveAmt]      NUMERIC (10, 2) NULL,
    [payGrandGrossPayAmt]  NUMERIC (10, 2) NULL,
    [payGrandDedAmountAmt] NUMERIC (10, 2) NULL,
    [payNetPayAmt]         NUMERIC (10, 2) NULL,
    [PayAmtInWords]        VARCHAR (200)   NULL,
    [PayApprovedBy]        VARCHAR (100)   NULL,
    PRIMARY KEY CLUSTERED ([PaySlipNumber] ASC),
    FOREIGN KEY ([PayslipID]) REFERENCES [dbo].[HRA_Employee] ([EMPRID])
);





SELECT top 1 Format(AttMarkedDate,'hh:mm:ss tt') As AtTime,Format(AttMarkedDate,'dd-MMM-yyyy dddd') As AttDate FROM EmpAttendance;

Select count(AttDate), count(EmpName) from EmpAttendance Group By AttDate,EmpName;

SELECT EL.RID As 'Leave Code', EL.LeaveRefEmpRID As 'Employee Code', HR.EmpTitle + ' ' + HR.EmpFirstName + ' ' + HR.EmpMiddleName + ' ' + HR.EmpLastName As 'Employee Name', HR.EmpDept As 'Department',HR.EmpDesignation As 'Designation', EL.dtLeaveApplied As 'Application Date', EL.dtLeaveStartDate As 'Leave From',HR.EmpLocation As Location, EL.LeaveStatus As LeaveStatus,EL.dtLeaveEndDate As 'Leave Till', EL.TotalAppliedDays As 'TotalDays',el.ReasonForLeave As 'LeaveReason' from EmpAppliedLeave EL LEFT OUTER JOIN  HRA_Employee HR ON EL.LeaveRefEmpRID = hr.EmpCode WHERE EL.RID=2

CREATE TABLE [dbo].[EmpAttendance] (
    [RID]           INT           IDENTITY (1, 1) NOT NULL,
    [EmpAttID]      INT           NOT NULL,
    [EmpCode]       VARCHAR (200) NOT NULL,
    [EmpName]       VARCHAR (50)  NOT NULL,
    [EmpDept]       VARCHAR (50)  NOT NULL,
    [AttDate]       DATETIME      NOT NULL,
    [InTime]        DATETIME      NULL,
    [OutTime]       DATETIME      NULL,
    [AttStatus]     VARCHAR (10)  NOT NULL,
    [AttMode]       VARCHAR (20)  NULL,
    [AttMarkBy]     VARCHAR (50)  NOT NULL,
    [AttMarkedDate] DATETIME      DEFAULT (getdate()) NOT NULL,
    FOREIGN KEY ([EmpAttID]) REFERENCES [dbo].[HRA_Employee] ([EMPRID]),
	Primary Key ([EmpCode],[AttDate])
);

SELECT * FROM  EmpAttendance;
SELECT SYSDATE FROM DUAL;


SELECT  ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo,H.EMPRID As EmpNo, H.EmpCode,H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,
H.EmpDept from HRA_Employee H, EmpAttendance L Where L.AttDate not in Date('dd-MMM-yyyy'),'dd-MMM-yyyy'));
LEFT Join EmpAttendance L On L.EmpAttID NOT IN(H.EMPRID)  WHERE EmpWorkingStatus In('Working')And Format(L.attDate, 'dd-MMM-yyyy') != Format(CURRENT_TIMESTAMP, 'dd-MMM-yyy') And
Format(L.attDate, 'dd-MMM-yyyy') !< Format(CURRENT_TIMESTAMP, 'dd-MMM-yyy');

Delete from EmpAttendance Where RID=7;

SELECT TOP 1 ROW_NUMBER() OVER(ORDER BY RID ASC) AS SrNo,EmpRID As EmpNo, EmpCode,EmpTitle + ' ' + EmpFirstName + ' ' + EmpMiddleName + ' ' + EmpLastName As EmpName, EmpDept from HRA_Employee with(nolock) WHERE EmpWorkingStatus In('Working');
 And (EmpCode=@1 Or EmpEmail=@2);

-- To Check if Attendance is Pending
SELECT  ROW_NUMBER() OVER(ORDER BY H.RID ASC) AS SrNo, H.EmpCode,H.EmpTitle + ' ' + H.EmpFirstName + ' ' + H.EmpMiddleName + ' ' + H.EmpLastName As EmpName,
H.EmpDept from HRA_Employee H RIGHT Join EmpAttendance L On EMPRID!=L.EmpAttID WHERE EmpWorkingStatus In('Working') And 
(Format(CURRENT_TIMESTAMP,'dd-MMM-yyy') !< Format(L.attDate,'dd-MMM-yyyy')) Or Format(L.attDate,'dd-MMM-yyyy')=NULL AND L.AttStatus='' or L.AttStatus != '';


Select * from EmpAttendance;
 where EmpCode = 'EMP0000001';
Select top 3 * from HRA_Employee;
truncate table EmpAttendance;


Alter Table HRA_Employee Alter Column [EmpSalPayGrade] varchar(20);

INSERT into HRA_Employee(EmpTitle, EmpFirstName, EmpMiddleName, EmpLastName, CreatedBy,LastModifiedBy, EmpFHTitle, EmpFHName, EmpDOB, EmpPlaceBirth, EmpMarriageStatus, EmpNationality, EmpGender, EmpBloodGroup, EmpHighEducation, EmpPreEmployer, EmpTotalExp, EmpPreDesignation, EmpDateOfJoin, EmpDept, EmpDesignation, EmpJobType, EmpWorkingStatus, EmpEmail, EmpRoleID, EmpPhone, EmpDivision, EmpLocation, EmpTeamName, EmpReportingTo, EmpAddress1, EmpTown, EmpCity, EmpState, EmpCountry, EmpPincode, EmpPAN, EmpUAN, empEsicNumber, EmpPRAN, EmpBankName, EmpBankAcNo, EmpBankMicrCode, EmpBankIFSC, EmpBankBranch, EmpBankAccType, BasicPay, HRA, EducationAllowance, LTA, ESIC, Conveyance, PF_Amount, PT_Amount, EmpSalOtherDed, GrandGrossPay, GrandDedAmount, NetPay, PL_Leave, CL_Leave, Total_Leave, Balance_Leave, EmpIDProof, EmpAddProof, EmpProfileImg, EmpMobile, EmpPassword,  EmpHobbies, EmpSalPayGrade, SL_Leave, EmpPreEmpDOL)
VALUES(@a1, @a2, @a3, @a4, @a5, @a6, @a7, @a8, @a9, @a10, @a11, @a12, @a13, @a14, @a15, @a16, @a17, @a18, @a19, @a20, @a21, @a22, @a23, @a24, @a25, @a26, @a27, @a28, @a29, @a30, @a31, @a32, @a33, @a34, @a35, @a36, @a37, @a38, @a39, @a40, @a41, @a42, @a43, @a44, @a45, @a46, @a47, @a48, @a49, @a50, @a51, @a52, @a53, @a54, @a55, @a56, @a57, @a58, @a59, @a60, @a61, @a62, @a63, @a64, @a65, @a66, @a67, @a68, @a69, @a70, @a71);


Drop Table HRA_Employee;
select * from HRA_Employee with(nolock);


Update HRA_Employee Set EmpEmail = 'ramji.mishra@outlook.com' Where EmpEmail='drkhushi.mishra98@gmail.com';
select *  from EmpAttendance with(nolock);

alter table HRA_Employee Add AdhaLen int;

alter table HRA_Employee Add EmpFileConType3 nvarchar(200);
 date;

 numeric(8,2);

select * from HRA_Employee;
alter table EmpAppliedLeave Drop Column EmpFHTitle,EmpHobbies,EmpPreEmpDOL,EmpSalPayGrade;

Create Table HRA_Emp_Attendance
(
RID bigint identity(1,1),
)

CREATE TABLE HRA_Employee(
RID int identity(1,1) Not Null,
EmpTitle varchar(10),
EmpFirstName varchar(50)NOT NULL,
EmpMiddleName varchar(50)NOT NULL,
EmpLastName varchar(50)NOT NULL,
ECPrefix varchar(10) default('EMP') NOT NULL,
EmpCode As (ECPrefix+right('000000'+Convert([Varchar](50),[RID]),(10))) primary key,
CreatedDate datetime default(CURRENT_TIMESTAMP),
CreatedBy varchar(50) not null,
LastModifiedDate datetime default(CURRENT_TIMESTAMP),
LastModifiedBy varchar(50) not null,
EmpFHName varchar(100),
EmpDOB date,
EmpPlaceBirth varchar(50),
EmpMarriageStatus varchar(20),
EmpNationality varchar(50),
EmpGender varchar(10),
EmpBloodGroup varchar(20),
EmpHighEducation varchar(100),
EmpPreEmployer varchar(100),
EmpTotalExp varchar(50),
EmpPreDesignation varchar(50),
EmpDateOfJoin date not null,
EmpDateofResign date,
EmpPreAppDate date,
EmpNextAppDate date,
EmpDept varchar(100),
EmpDesignation varchar(50),
EmpJobType varchar(50),
EmpWorkingStatus varchar(20) Not Null,
EmpKYC char(5),
EmpEmail nvarchar(50) primary key Not Null,
EmpPassword As (lower(empFirstName+EmpLastName)) PERSISTED,
EmpRoleID int not null,
EmpPhone varchar(15) Unique,
EmpDivision varchar(50),
EmpLocation varchar(50),
EmpTeamName varchar(50),
EmpReportingTo varchar(50),
EmpAddress1 varchar(100),
EmpAddress2 varchar(100),
EmpTown varchar(50),
EmpCity varchar(50),
EmpState varchar(50),
EmpCountry varchar(50),
EmpPincode numeric(6),
EmpProfilePic varbinary(max),
EmpPAN varchar(10) unique,
EmpUAN varchar(20),
empEsicNumber varchar(20),
EmpPRAN varchar(20),
EmpBankName varchar(max),
EmpBankAcNo numeric(20) unique,
EmpBankMicrCode varchar(50),
EmpBankIFSC varchar(50),
EmpBankBranch varchar(50),
EmpBankAccType varchar(50),
BasicPay numeric(8,2)not null,
HRA numeric (8,2)not null, -- calculate from percentage
EducationAllowance numeric(8,2), -- calculate from percentage
LTA numeric(8,2), -- calculate from percentage
ESIC numeric(8,2), -- calculate from percentage
Conveyance numeric(8,2),
PF numeric(8,2),
PT numeric(8,2),
GrandGrossPay numeric(8,2),
GrandDedAmount numeric(8,2),
NetPay numeric(8,2),
EmpIDProof varbinary(max),
EmpAddressProof varbinary(max));


Select  * from HRA_Employee;

Update HRA_Employee Set EmpMobile='9324595544', EmpEmail='drkhushi.mishra98@gmail.com' Where EmpEmail='drkhushi.mishra@gmail.com';


Create Table EmpAppliedLeave
(
RID INT IDENTITY(1,1),
LeaveRefEmpRID varchar(50) NOT NULL,
LeaveType varchar(50),
LeaveID As (RID) PERSISTED NOT NULL,
dtLeaveApplied datetime default(CURRENT_TIMESTAMP),
dtLeaveLastWorkDate date not null,
dtLeaveStartDate date not null,
dtLeaveEndDate date not null,
LeaveApprovedBy varchar(50),
LeaveApprovedDate datetime,
TotalAppliedDays numeric(4,2) Not Null,
TotalApprovedDays numeric(4,2),
LeaveStatus varchar(50),
ReasonForLeave varchar(max) not null,
LeaveAppCCEmail nvarchar(70),
LeaveRejectReason varchar(max));



Update EmpAppliedLeave set LeaveNotesForEmp= 'Dear Khushi, Your leave is approved.' Where RID=2;


select  * from  HRA_Employee;

SELECT  EL.RID As 'Sr. No.', EL.LeaveRefEmpRID As 'Employee Code', HR.EmpTitle + ' ' + HR.EmpFirstName + ' ' + HR.EmpMiddleName + ' ' + HR.EmpLastName As 'Employee Name', HR.EmpDept As 'Department', HR.EmpDesignation As 'Designation',
EL.dtLeaveApplied As 'Application Date', EL.dtLeaveStartDate As 'Leave From', EL.dtLeaveEndDate As 'Leave Till', EL.TotalAppliedDays As 'Total Days',el.ReasonForLeave As 'Leave Reason'
 from  EmpAppliedLeave EL LEFT OUTER JOIN  HRA_Employee HR ON  EL.LeaveRefEmpRID = hr.EmpCode Order By EL.dtLeaveApplied ASC;

Select EmpCode, EmpMobile, EmpEmail From HRA_Employee with(nolock) Where EmpEmail='drkhushi.mishra98@gmail.com';


Use JVIIT;

SELECT ROW_NUMBER() OVER(ORDER BY RID ASC) AS SrNo, EmpName As 'Employee Name', EmpCode as Code, Format(AttDate, 'dd-MMM-yyyy dddd') as 'Attendance Date', AttStatus As 'Status' from EmpAttendance;


alter table EmpAppliedLeave Add LeaveNotesForEmp varchar(max);
 unique not null;

Create table EmpAttendance
(
RID int identity(1,1) not null,
EmpAttID int REFERENCES HRA_Employee(EMPRID) NOT NULL,
EmpCode varchar(200) not null,
EmpName varchar(50) not null,
EmpDept varchar(50)not null,
AttDate datetime Not null,
InTime datetime,
OutTime datetime,
AttStatus varchar(10) not null,
AttMode varchar(20),
AttMarkBy varchar(50) not null,
AttMarkedDate  datetime default (CURRENT_TIMESTAMP) not null
)

insert into EmpAttendance (EmpAttID, EmpCode, 

truncate table empAttendance;

select * from EmpAttendance;

exec insert_multiple_row;

CREATE PROCEDURE insert_multiple_row
@EID int,
@ECod varchar(50),
@Ename varchar(100),
@EmpDt varchar(50),
@AttDt date,
@AttSt varchar(10),
@attMd varchar(20),
@attMarkBy varchar(50)
As 
begin 
insert into EmpAttendance(EmpAttID, EmpCode, EmpName, EmpDept, AttDate, AttStatus, AttMode, AttMarkBy)
VALUES(@EID, @ECod, @Ename, @EmpDt, @AttDt, @attst, @attMd, @attMarkBy)



Alter Procedure update_emp_attendance
@ECode varchar(50),
@AttDateNew date,
@AttStatusNew varchar(20),
@AttUpdatedBy varchar(100),
@EMPRID int,
@AttModeNew varchar(50)
AS 
BEGIN
Update EmpAttendance SET AttDate=@AttDateNew, AttStatus=@AttStatusNew,AttMode=@AttModeNew, AttMarkedDate=@AttMarkedNew,AttMarkBy=@AttUpdatedBy 
Where EmpCode=@ECode AND AttDate=@AttDateNew and EmpAttID=@EMPRID;
END;



End;

CREATE TABLE [dbo].[HRA_Employee] (
    [RID]                INT             IDENTITY (1, 1) NOT NULL,
    [EMPRID]             AS              ([RID]+(1)) PERSISTED NOT NULL,
    [EmpTitle]           VARCHAR (10)    NULL,
    [EmpFirstName]       VARCHAR (50)    NOT NULL,
    [EmpMiddleName]      VARCHAR (50)    NOT NULL,
    [EmpLastName]        VARCHAR (50)    NOT NULL,
    [ECPrefix]           VARCHAR (3)     DEFAULT ('EMP') NOT NULL,
    [EmpCode]            AS              ([ECPrefix]+right('000000'+CONVERT([varchar](30),[RID]),(50))) PERSISTED,
    [CreatedDate]        DATETIME        DEFAULT (getdate()) NULL,
    [CreatedBy]          VARCHAR (50)    NOT NULL,
    [LastModifiedDate]   DATETIME        DEFAULT (getdate()) NULL,
    [LastModifiedBy]     VARCHAR (50)    NOT NULL,
    [EmpFHName]          VARCHAR (100)   NULL,
    [EmpDOB]             DATE            NULL,
    [EmpPlaceBirth]      VARCHAR (50)    NULL,
    [EmpMarriageStatus]  VARCHAR (20)    NULL,
    [EmpNationality]     VARCHAR (50)    NULL,
    [EmpGender]          VARCHAR (10)    NULL,
    [EmpBloodGroup]      VARCHAR (20)    NULL,
    [EmpHighEducation]   VARCHAR (100)   NULL,
    [EmpPreEmployer]     VARCHAR (100)   NULL,
    [EmpTotalExp]        VARCHAR (50)    NULL,
    [EmpPreDesignation]  VARCHAR (50)    NULL,
    [EmpDateOfJoin]      DATE            NOT NULL,
    [EmpDateofResign]    DATE            NULL,
    [EmpPreAppDate]      DATE            NULL,
    [EmpNextAppDate]     DATE            NULL,
    [EmpDept]            VARCHAR (100)   NULL,
    [EmpDesignation]     VARCHAR (50)    NULL,
    [EmpJobType]         VARCHAR (50)    NULL,
    [EmpWorkingStatus]   VARCHAR (20)    NOT NULL,
    [EmpKYC]             VARCHAR (20)    NULL,
    [EmpEmail]           NVARCHAR (50)   NOT NULL,
    [EmpRoleID]          INT             NOT NULL,
    [EmpPhone]           VARCHAR (15)    NULL,
    [EmpDivision]        VARCHAR (50)    NULL,
    [EmpLocation]        VARCHAR (50)    NULL,
    [EmpTeamName]        VARCHAR (50)    NULL,
    [EmpReportingTo]     VARCHAR (50)    NULL,
    [EmpAddress1]        VARCHAR (100)   NULL,
    [EmpAddress2]        VARCHAR (100)   NULL,
    [EmpTown]            VARCHAR (50)    NULL,
    [EmpCity]            VARCHAR (50)    NULL,
    [EmpState]           VARCHAR (50)    NULL,
    [EmpCountry]         VARCHAR (50)    NULL,
    [EmpPincode]         NUMERIC (6)     NULL,
    [EmpPAN]             VARCHAR (10)    NULL,
    [EmpUAN]             VARCHAR (20)    NULL,
    [empEsicNumber]      VARCHAR (20)    NULL,
    [EmpPRAN]            VARCHAR (20)    NULL,
    [EmpBankName]        VARCHAR (MAX)   NULL,
    [EmpBankAcNo]        NUMERIC (20)    NULL,
    [EmpBankMicrCode]    VARCHAR (50)    NULL,
    [EmpBankIFSC]        VARCHAR (50)    NULL,
    [EmpBankBranch]      VARCHAR (50)    NULL,
    [EmpBankAccType]     VARCHAR (50)    NULL,
    [BasicPay]           NUMERIC (8, 2)  NOT NULL,
    [HRA]                NUMERIC (8, 2)  NOT NULL,
    [EducationAllowance] NUMERIC (8, 2)  NULL,
    [LTA]                NUMERIC (8, 2)  NULL,
    [ESIC]               NUMERIC (8, 2)  NULL,
    [Conveyance]         NUMERIC (8, 2)  NULL,
    [PF_Amount]          NUMERIC (8, 2)  NULL,
    [PT_Amount]          NUMERIC (8, 2)  NULL,
    [GrandGrossPay]      NUMERIC (8, 2)  NULL,
    [GrandDedAmount]     NUMERIC (8, 2)  NULL,
    [NetPay]             NUMERIC (8, 2)  NULL,
    [PL_Leave]           NUMERIC (4, 1)  NULL,
    [CL_Leave]           NUMERIC (4, 1)  NULL,
    [Total_Leave]        NUMERIC (4, 1)  NULL,
    [Balance_Leave]      NUMERIC (4, 1)  NULL,
    [EmpIDProof]         VARBINARY (MAX) NULL,
    [EmpAddProof]        VARBINARY (MAX) NULL,
    [EmpProfileImg]      VARBINARY (MAX) NULL,
    [EmpMobile]          NUMERIC (15)    NULL,
    [EmpPassword]        VARCHAR (50)    NULL,
    PRIMARY KEY CLUSTERED ([EMPRID] ASC),
    UNIQUE NONCLUSTERED ([EmpBankAcNo] ASC),
    UNIQUE NONCLUSTERED ([EmpPRAN] ASC),
    UNIQUE NONCLUSTERED ([empEsicNumber] ASC),
    UNIQUE NONCLUSTERED ([EmpUAN] ASC),
    UNIQUE NONCLUSTERED ([EmpPAN] ASC),
    UNIQUE NONCLUSTERED ([EmpPhone] ASC),
    CONSTRAINT [UK] UNIQUE NONCLUSTERED ([EmpMobile] ASC)
);




--INSERT into EmpAttendance(EmpAttID, EmpCode, EmpName, EmpDept, AttDate, AttStatus, AttMode, AttMarkBy)


INSERT into HRA_Employee(EmpTitle,EmpFirstName, EmpMiddleName, EmpLastName, CreatedBy, EmpFHName, EmpDOB, EmpPlaceBirth, EmpMarriageStatus,EmpNationality, EmpGender, EmpBloodGroup, EmpHighEducation, EmpPreEmployer, EmpTotalExp, EmpPreDesignation, 
EMPDATEOFJOIN,EMPDEPT, EMPDESIGNATION, EMPJOBTYPE, EMPWORKINGSTATUS, empKYC, EMPEMAIL, EMPPHONE, EMPDIVISION, EMPLOCATION, EMPTEAMNAME,EmpReportingTo,EmpAddress1,EmpAddress2,EmpTown,EmpCity, EmpState,EmpCountry,EmpPincode
, EmpPAN, EmpUAN,EmpEsicNumber,EmpPran,EmpBankName, EmpBankAcNo, EmpBankMicrCode,EmpBankIFSC, EmpBankBranch, EmpBankAccType, BasicPay, HRA, EducationAllowance,LTA, ESIC, Conveyance, PF,PT, GrandGrossPay, GrandDedAmount, NetPay,EmpRoleID)
Values('Mr.','Ram','B','Mishra','Khushi.Mishra','G P Mishra','21-Jan-1991','Mumbai','Married','Indian','Male','B Positive','Post Graduation - MCA','Tata Consultancy Services - Mumbai','10 Years','Software Engineer','15-Apr-2015','IT-InHouse',
'Software Developer','Permanent','Working','Completed','ramji.mishra@outlook.com','1','02267241627','JVI-Sakinaka','Mumbai','IT Team','Mr. Manohar Khedekar','ABC Road','XYZ Society','Andheri East','Mumbai','Maharashtra','India', '400059','CKAPM6211M',
'100020235242','12222144858','321240023525','ICICI Bank','2320100012525236','ICICI52636','Andheri East, Mumbai','Salary Account','ICICI012030','20000.00','100.00', '250.00', '350.00','400.00','630.00','450.00','200.00','22500.00','1050.00','21000.00');

Use JVIIT;

SELECT ROW_NUMBER() OVER(ORDER BY TRefNo ASC) AS SrNo,TRefNo as "Ticket Number", 
Format(TTrainingCreatedDate, 'dd-MMM-yyyy hh:mm tt') As 'Scheduled Date',
TTrainingTitle as 'Training Subject',
Format(TdateFromTime, 'dd-MMM-yyyy hh:mm tt') As 'Start Date', 
Format(TDateTillTime, 'dd-MMM-yyyy hh:mm tt') As 'End Date',
TType as 'Training Type', TTrainerName AS 'Trainer Name',
TTrainingLocation + ' ' + TTrainingVenue As 'Training Address',
TTrainingStatus as Status,
TTrainingNotes as Remarks
from UserTraining;


create table User_Role (URoleID int primary key not null, URoleName varchar(50)Not Null);
insert into User_Role Values(3,'Employee');

alter table JVIEmp Add URoleID int references User_Role(URoleID);

SELECT * from JVIEmp with(nolock);
update JVIEmp Set URoleID=3 Where EID=1;
select * from UserTraining with(nolock);

Select TrefNo as TrainingNumber, TDateFromTime as TrainingDate, TTYpe as TrainingType, TTrainingCreatedDate as ScheduledOn,
ttrainingLocation As TrainingLocation  from UserTraining with(nolock)


Update Usertraining Set TTrainingNotes = 'Recruiter Training Online required' Where TID=2;

Alter Table UserTraining Add  TTrainingModifiedDate datetime default(CURRENT_TIMESTAMP);

Select EFirstName, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName AS FullName FROM jviemp;
create table JVIUserRequestForPassword(ID int identity(1,1), 
RequestDateTime datetime default(CURRENT_TIMESTAMP),
UserName varchar(50) Foreign Key References JVIEmp(ELoginName),
Email nvarchar(100),
Mobile nvarchar(20));

select * from JVIUserRequestForPassword;

Create Table UserGreviences(id int IDENTITY(1,1)NOT NULL,
GrPrefix varchar(10) default('UG') NOT NULL,
GrRefNo  As (GrPrefix+right('000000'+Convert([Varchar](10),[ID]),(10))) PERSISTED,
GrLoggedInDate datetime default(CURRENT_TIMESTAMP),
GrModifiedDate datetime default(CURRENT_TIMESTAMP),
ELoginName varchar(50) Foreign Key References JVIEmp(ELoginName),GrIssueTitle varchar(100),
GrRequestedUser varchar(50) not null,
GrAltContact varchar(max),
GrRequestedUserEmail nvarchar(150)not null,
GrCategory varchar(100)not null, 
GrType varchar(100)not null,
GrPriority NVarchar(50)not null,
GrIssueFrom Date not null,
GrDesc nVarchar(max), 
GrCompleted Date,GrStatus varchar(20),
);
alter table JVIEmp drop column Epassword;
alter table JVIEmp Add Epassword binary(100);
alter table JVIEmp alter column Epassword binary(64);
select * from JVIEmp;

Select EloginName, EPassKey, EEmail, Emobile from JVIEmp WITH(NOLOCK)

declare @pkey NVarchar(100)
update JVIEmp SET Epassword=HASHBYTES('ram@123',Epasskey) where EMobile=7977261158;

update JVIEmp SET Epasskey='ram@123' where EMobile=7977261158;

update JVIEmp Set Epassword= HashBytes('ram@123', Epasskey) where EMobile=7977261158;
select * from UserGreviences;
SELECT CONVERT(nvarchar, DecryptByPassphrase(Password, EncKey)) As PasswordValue from HC_Users with(nolock) Where Username='ram.mishra'; 
    AS 'Decrypted card number' FROM Sales.CreditCard   
    WHERE CreditCardID = '3681';  

Select ROW_NUMBER() OVER(ORDER BY ID ASC) AS 'Sr. No.','Issue In ' + GrCategory + ' ( ' + GrType + ' )' As 'Subject',
Format(GrLoggedInDate, 'dd-MMM-yyyy hh:mm:ss tt') as RequestedDate, EloginName AS UserName,GrPriority as Priority, GrRequestedUser as UserFullName,
GrAltContact as 'Alternate Contact',GrRequestedUserEmail As 'Email ID', GrIssueFrom as IssueFrom, GrDesc AS Description,
GrStatus as Status from UserGreviences;

Select ROW_NUMBER() OVER(ORDER BY ID ASC) AS 'Sr. No.','Feedbak for ' + FBType As 'Subject',FBUserFullName as UserName,Format(FBDateTime, 'dd-MMM-yyyy hh:mm:ss tt') as FeedBackDate,
FBComments as 'Feedback Description',FBRating as Rating From UserFeebacks with(nolock) Order By FBDateTime DESC;


declare @encrypt varbinary(200) 
select @encrypt = EncryptByPassPhrase('key', 'abc' )
Select Username, * from HC_Users with(nolock) Where Username='ram.mishra';

SELECT CAST(Password AS varchar(20)) AS Pass from HC_Users with(nolock) Where Username='ram.mishra';

Select ROW_NUMBER() OVER(ORDER BY id ASC) AS SrNo, GrRefNo As CaseID,Format(GrLoggedInDate, 'dd-MMM-yyyy hh:mm:ss tt') As 'Requeste Date',GrIssueTitle as SubjectTitle,
GrCategory + ' - ' + GrType as Category, GrPriority as Priority,GrIssueFrom as 'Issue From',GrCompleted as 'Resolved Date', GrDesc As IssueDescription,
GrStatus as Status from UserGreviences with(nolock) Where EloginName=@grLogin order by GrLoggedInDate desc;

Create Table UserLoginLog(id int identity(1,1) not null, LoginDateTime datetime default(CURRENT_TIMESTAMP),ELoginName varchar(50) Foreign Key References JVIEmp(ELoginName),PC_Name varchar(50) Not Null, BrowserName varchar(50));

Create Table UserFeebacks(
ID int identity(1,1) not null,
FBPrefix varchar(10) default('FB') NOT NULL,
FBRefNo  As (FBPrefix+right('0000'+Convert([Varchar](10),[ID]),(10))) PERSISTED,
FBUserEmail nvarchar(100)not null,
FBUserName varchar(50) Foreign Key References JVIEmp(ELoginName),
FBUserFullName varchar(50) not null,
FBUserLocation nvarchar(100)not null,
FBType varchar(20)NOT NULL, 
FBDateTime dateTime default(CURRENT_TIMESTAMP),
FBComments NVARCHAR(max)not null,
FBRating nvarchar(20) not null
);

DROP table UserFeebacks;

select * from UserFeebacks;
select * from issue
select * from UserLoginLog;
use master;
select * from Issues
Update Issues Set IssueTitle='Internet Browser Issue' WHERE id=26;
USE [master]
GO
CREATE DATABASE [SQLAuthority] ON
( FILENAME = N'C:\inetpub\wwwroot\IT Portal\IT Portal\App_Data\DB\JVIIT.mdf' ),
( FILENAME = N'C:\inetpub\wwwroot\IT Portal\IT Portal\App_Data\DB\JVIIT_log.ldf' )
 FOR ATTACH
GO;
DBCC CHECKPRIMARYFILE('C:\inetpub\wwwroot\IT Portal\IT Portal\App_Data\DB\JVIIT.mdf',2)
--Back up Data
DECLARE @name VARCHAR(50) -- database name  
DECLARE @path VARCHAR(256) -- path for backup files  
DECLARE @fileName VARCHAR(256) -- filename for backup  
DECLARE @fileDate VARCHAR(20) -- used for file name
 
-- specify database backup directory
SET @path = 'D:\'  
 
-- specify filename format
SELECT @fileDate = CONVERT(VARCHAR(20),GETDATE(),112) 
 
DECLARE ram_cursor CURSOR READ_ONLY FOR  
SELECT name 
FROM master.dbo.sysdatabases 
WHERE name IN ('JVIIT')  -- exclude these databases
 
OPEN db_cursor   
FETCH NEXT FROM ram_cursor INTO @name   
 
WHILE @@FETCH_STATUS = 0   
BEGIN   
   SET @fileName = @path + @name + '_' + @fileDate + '.BAK'  
   BACKUP DATABASE @name TO DISK = @fileName  
 
   FETCH NEXT FROM db_cur INTO @name   
END

CLOSE ram_cursor
DEALLOCATE ram_cursor

--Backup end



select * from JVIEmp;
create table Issues (id int not null IDENTITY(1,1),AddedOn datetime default(Current_TimeStamp),IssueTitle varchar(100)not null, IssueType varchar(50));
insert into SoftwareIssue(IssueTitle) Values('Portal Issue')
select * from Issues order By IssueTitle ASC;

Select IssueTitle from Issues with(nolock) Where IssueType='Software';
Insert into JVIIT.dbo.Issues(IssueTitle, IssueType) Select IssueTitle, IssueType from master.dbo.Issues;

exec sp_rename 'HireCraftIssue', 'Issues'
Alter Table HireCraftIssue Add IssueType varchar(50);
Update HardwareIssue set IssueType='Hardware';

alter Table JVIEmp Add JVIEmpAboutUser nvarchar(max);
Insert into JVIEmp
(EPreFix,EFirstName,EMiddleName,ELastName,EGen,EDOB, EMaritalStatus,EMobile, EEmail, EJoinDate,EEducation,ELocation,
EDept,EDiv,EDesg,ELoginName,EloginCreatedDate,Epasskey, EWorkingStatus, URoleID) 
VALUES('Mr.','Pradeep','A','Maurya','Male','10-Oct-1992','Single',08286162243,'mauryapradeep@gmail.com','25-Aug-2010','Post Graduate-MCA','Mumbai','Admin',
'Sakinaka','Admin-Executive','pradeep.m','01-Oct-2018','pradeep@123','Working',4);

update JVIEMP set EloginCreatedDate='01-Oct-2018' Where EID='3';

select * from JVIEmp;
select * from User_Role with (nolock);
insert into User_Role(URoleID, URoleName) Values(4,'Manager');



USE JVIIT;

ALTER DATABASE JVIIT SET READ_WRITE WITH NO_WAIT;
ALTER DATABASE JVIIT SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE JVIIT SET MULTI_USER
ALTER DATABASE JVIIT SET MULTI_USER WITH NO_WAIT
ALTER DATABASE JVIIT SET MULTI_USER WITH ROLLBACK IMMEDIATE



select * from JVIEmp;
select * from UserTraining;

Create Table UserCreationRequest
(
UCRID int identity(1,1)not null,
UCRPrefix varchar(10) default('UCR') NOT NULL,
UCRRefNo As ([UCRPrefix]+right('000000'+Convert([Varchar](10),[UCRID]),(10))) PERSISTED,
ELoginName varchar(50) Foreign Key References JVIEmp(ELoginName),
UCRRequestedDate dateTime default(CURRENT_TIMESTAMP),
UCRRequestedUser varchar(50) not null,
UCRRequestedUserEmail nvarchar(150)not null,
UCRNewUserTitle varchar(10)not null,
UCRNewUserFirstName varchar(50)not null,
UCRNewUserMiddleName varchar(50),
UCRNewUserLastName varchar(50)not null,
UCRNewUserEmailID nvarchar(150)UNIQUE NOT NULL,
UCRNewUserPhone numeric(20)Unique Not Null,
UCRNewUserHCID nvarchar(20)primary key not null,
UCRNewUserDesg varchar(50)not null,
UCRNewUserLocation varchar(50)not null,
UCRNewUserDivision varchar(50)not null,
UCRNewUserDeptName varchar(70)not null,
UCRNewUserTeam varchar(50)not null,
UCRNewUserJoinedDate date not null,
UCRNewUserCreationStatus varchar(20),
UCRNewUserCreationNewOld varchar(50),
UCRNewUserRemarks varchar(max)
)

drop table UserCreationRequest;

Alter table UserCreationRequest Alter Column UCRRequestedDate DateTime;
alter table UserCreationRequest drop column UCRRequestedDate;


Select Top 1 UCRRefNo,UCRNewUserCreationNewOld,UCRRequestedDate,UCRNewUserTitle+ ' ' + UCRNewUserFirstName + ' ' + UCRNewUserMiddleName + ' ' + UCRNewUserLastName
As NewUserFullName,UCRNewUserHCID,UCRNewUserDesg,UCRNewUserLocation+ ', ' + UCRNewUserDivision+ ' [ ' + UCRNewUserDeptName + ' - ' + UCRNewUserTeam + ' ] ' As WorkLocation,
UCRNewUserEmailID,UCRNewUserPhone,UCRNewUserRemarks
from UserCreationRequest with(nolock)

alter Table UserCreationRequest ADD UCRNewUserDeptName varchar(70);

Drop Table UserCreationRequest;
SELECT ELoginName,EEmail, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName + '( ' + Edesg + ' )' As EmpFullName from JVIEmp;

INSERT INTO UserCreationRequest(ELoginName,UCRRequestedUser,UCRRequestedUserEmail,UCRNewUserTitle,UCRNewUserFirstName,UCRNewUserMiddleName,UCRNewUserLastName,UCRNewUserEmailID,UCRNewUserPhone,
UCRNewUserHCID,UCRNewUserDesg,UCRNewUserLocation,UCRNewUserDivision,UCRNewUserTeam,UCRNewUserDeptName,UCRNewUserJoinedDate,UCRNewUserCreationStatus,
UCRNewUserRemarks,UCRNewUserCreationNewOld)
VALUES('ram.mishra','Mr. Ram B Mishra( IT Executive )','support2@jvi-global.com','Mr.','Pravin','R','Jadhav','mumpetro1@jvi-global.com',022491402529,'pravin.jadhav',
'Sr. Recruiter','Mumbai','JVC-Nariman Point','Projects And Construction','Recruitment Team','30-Oct-2017','In-Process','New ID','Please create new HireCraft ID');

Select * from UserCreationRequest;

truncate table UserCreationRequest;
CREATE TABLE UserTraining
(
	TID INT identity(1,1)not null,
	TPreFix varchar(10) default('JVI') not null,
	TRefNo As ([TPreFix]+right('000000'+CONVERT([varchar](7),[TID]),(7))) PERSISTED,
	ELoginName VARCHAR(50)Foreign Key References JVIEmp(ELoginName),
	TDateFromTime dateTime not null,
	TDateTillTime dateTime not null,
	TType varchar(50)not null,
	TTrainingCreatedDate date default(GetUTCDate()),
	TTrainerName varchar(max),
	TTrainingLocation varchar(50),
	TTrainingFeedBackScore int,
	TTrainingStatus varchar(50)Not Null,
	TUserLevel varchar(50),
);

Create Table JVIEmp
(
EID int identity(1,1)not null,
EPreFix varchar(5) not null,
EFirstName  varchar(max) not null,
EMiddleName varchar(max),
ELastName varchar(max) Not Null,
EGen varchar(10)not null,
EDOB date not null,
EMaritalStatus varchar(20),
EMobile numeric(20)Unique Not Null,
EEmail varchar(50)Unique Not Null,
EJoinDate date not null,
EEducation varchar(max),
ELocation varchar(max),
EDept varchar(max),
EDiv varchar(max),
EDesg varchar(max),
ELoginName varchar(50) Primary Key Not Null,
EPassword varchar(50) Not Null,
ELoginCreatedDate date,
EResignDate date,
EWorkingStatus Varchar(50)
);

select * from JVIEmp;
update JVIEmp SET JVIEmpAboutUser='I am graduate in Computer Science' Where EID=1;

ALTER TABLE JVIEmp ALTER COLUMN EmpCreatedDate DateTime;
default(CURRENT_TIMESTAMP);
Alter Table JVIEmp ALter Column EmpCreatedDate dateTime default(GetUTCDate());
,EmpModifiedDate date default(GetUTCDate());
select * from UserTraining;
Use JVIIT;
SELECT ELoginName, EPreFix + ' ' + EFirstName + ' '  + EMiddleName + ' ' + ELastName + '( ' + Edesg + ' )' As EmpFullName FROM JVIEMP;