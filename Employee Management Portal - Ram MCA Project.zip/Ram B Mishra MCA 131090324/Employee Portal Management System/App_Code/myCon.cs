﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for myCon
/// </summary>
public class con_properties
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HRAString"].ToString());

    public void con_open()
    {

        try
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        catch (SqlException ex)
        {
            if (ex.Number == 1205)
            { {

                    ex.Message.ToString();
                } }
        }
    }

    //public void ConStr()
    //{
    //    using (SqlConnection conn = new SqlConnection())
    //    {
    //        conn.ConnectionString = (ConfigurationManager.ConnectionStrings["HRAString"].ToString());
    //        // using the code here...
    //    }
    //}

    public void getCon()
    {

        string connection = ConfigurationManager.ConnectionStrings["HRAString"].ConnectionString;

    }

    public void close_con()
    {
        try
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        catch (Exception ex) { ex.Message.ToString(); }
    }
}