﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Reflection;
    public partial class comman_pages_myprofile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

    protected void btnsaveProfile_Click(object sender, EventArgs e)
    {
        StringBuilder sb = new StringBuilder();

        if (empProfilePic.HasFile)
        {
            try
            {
                sb.AppendFormat(" Uploading file: {0}", empProfilePic.FileName);

                //saving the file
                empProfilePic.SaveAs("<c:\\SaveDirectory>" + empProfilePic.FileName);

                //Showing the file information
                sb.AppendFormat("<br/> Save As: {0}", empProfilePic.PostedFile.FileName);
                sb.AppendFormat("<br/> File type: {0}", empProfilePic.PostedFile.ContentType);
                sb.AppendFormat("<br/> File length: {0}", empProfilePic.PostedFile.ContentLength);
                sb.AppendFormat("<br/> File name: {0}", empProfilePic.PostedFile.FileName);
                imgEmpProfile.ImageUrl = empProfilePic.PostedFile.FileName;

            }
            catch (Exception ex)
            {
                sb.Append("<br/> Error <br/>");
                sb.AppendFormat("Image not saved. <br/> {0}", ex.Message);
            }
        }
        else
        {
            lblmessage.Text = sb.ToString();
        }
    }
}