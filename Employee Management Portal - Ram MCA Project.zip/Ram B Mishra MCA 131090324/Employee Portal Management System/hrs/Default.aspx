﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="Home" MasterPageFile="~/hrs/hrsMasterPage.master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">

    <div class="clear" runat="server">
    </div>
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div class="Welcm" runat="server">
            <asp:Image class="bannerImg" ID="Image1" runat="server" ImageUrl="~/images/eSSTopImg.jpg" />

        </div>

        <div class="clear">
        </div>
        <div class="intro" runat="server">

            <div class="dashboard" runat="server">

                <table style="width:90%; margin:0 auto !important;">
                    <tbody style="width: 100%; text-align:center; margin:0 auto !important;">
                        <tr>
                            <td>
                                <a href="/../comman-pages/myprofile.aspx">
                                    <div style="border: 1pt solid green; background-image: url(/../images/myProfile.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>My Profile</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/payIcon.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">

                                        <p>Pay Slips</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/leaveIcon.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>Leave Management</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/TimeIcon.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>Time & Attendance</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/msgIcon.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>Messages</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/Ficon.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>Forms & Formats</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/Dicon.png); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>Download</p>
                                    </div>
                                </a>
                                <a href="#">
                                    <div style="border: 1pt solid green; background-image: url(/../images/missIcon.jpg); background-repeat: no-repeat; background-position: center;" class="myTab" runat="server">
                                        <p>Miscellaneous</p>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>


        </div>
    </div>


</asp:Content>


