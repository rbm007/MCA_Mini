﻿<%@ Page Title="" Language="C#" MasterPageFile="~/hrs/hrsMasterPage.master" AutoEventWireup="true" CodeFile="add-new-employee.aspx.cs" Inherits="add_new_employee_data" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">New Employee Registration</div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="clkFirstProfileTab" class="EmpProfileTabPD tahHead" onclick="showhide3()" style="cursor: pointer;" title="Click to show information">Basic Information
            <span itemid="ram" class="right active"></span></h4>
                <table id="tblProperties" style="display: none !important; width: 100%; box-sizing: border-box !important; margin: 0 !important;">
                    <tbody style="width: 100%">
                        <tr>
                            <td colspan="3" style="text-align: center !important;">
                                <div style="border-bottom: 2pt solid orangered; display: flex; padding: 5pt !important;">
                                    <div style="width: 45% !important">
                                        <asp:Image ID="imgEmpProfile" ImageUrl="/../images/PP.png" Height="150px" Width="100px" runat="server" Style="border-radius: 50%; width: auto; border: dotted 1pt orangered;" />
                                        <br />
                                        <br />
                                        <asp:Label CssClass="ErrorMsg" Font-Bold="true" runat="server">Employee Photograph</asp:Label>
                                    </div>
                                    <div style="width: 45% !important; align-self: center;">
                                        <asp:Label runat="server" Font-Bold="true" Font-Size="Medium" ForeColor="OrangeRed" Text="Upload/Update Employee Latest Picture"></asp:Label>
                                        <asp:FileUpload class="EmpProfileTabPD" Style="padding: 3%;" ID="EmpProfilePic" runat="server" />
                                        <br />
                                        <br />
                                        <asp:Button class="LogBtn" ID="btnSaveImage" runat="server" Text="Save" Style="width: 85px; height: 30px !important" />
                                        <asp:Button class="LogBtn" ID="btnPreview" runat="server" Text="Preview" Style="width: 85px; height: 30px !important" />
                                        <asp:Label ID="Label1" runat="server" />
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Title & First Name</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpTitle" runat="server" Style="height: 22pt; width: 15%;">
                                        <asp:ListItem>Mr.</asp:ListItem>
                                        <asp:ListItem>Ms.</asp:ListItem>
                                        <asp:ListItem>Mrs.</asp:ListItem>
                                        <asp:ListItem>Smt.</asp:ListItem>
                                    </asp:DropDownList>
                                    <asp:TextBox Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtFirstName" runat="server" ToolTip="Employee first name" ReadOnly="False" />
                                    <br />
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ErrorMessage="Employee First Name" ControlToValidate="txtFirstName" Display="None"></asp:RequiredFieldValidator>
                                    <br />
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Middle Name & Last Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 39.5%; top: 0 !important;" class="setCalender" ID="txtEmpMiddleName" runat="server" ToolTip="Employee Middle name" ReadOnly="False" />
                                <asp:TextBox Style="height: 22pt; width: 39%; top: 0 !important;" class="setCalender" ID="txtEmpLastName" runat="server" ToolTip="Employee Last name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ErrorMessage="Employee Middle Name" ControlToValidate="txtEmpMiddleName" Display="None" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ErrorMessage="Employee Last Name" ControlToValidate="txtEmpLastName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Date of Birth</td>

                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="dtEmpDob" runat="server" Height="30" Width="81%" ToolTip="Employee date of birth" ReadOnly="true" />
                                    <asp:RequiredFieldValidator ID="ELastDt" runat="server" ErrorMessage="Employee Date of Birth." ControlToValidate="dtEmpDob" Display="None" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Gender</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpGen" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Male</asp:ListItem>
                                        <asp:ListItem>Female</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Email Address</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 80%; top: 0 !important;" class="setCalender" ID="txtEmpEmail" runat="server" Height="30" ToolTip="Employee Email ID" ReadOnly="false" />
                                <asp:RegularExpressionValidator ID="emValid" runat="server" ControlToValidate="txtEmpEmail" ValidationExpression="\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"
                                    SetFocusOnError="false" ErrorMessage="Employee Email Address" Display="None"> 
                                </asp:RegularExpressionValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Mobile Number  </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 80%; top: 0 !important;" class="setCalender" ID="txtEmpMobile" runat="server" Height="30" Width="80%" ToolTip="Employee Mobile" />
                                <br />
                                <asp:RequiredFieldValidator ID="mobiValid" runat="server" ErrorMessage="Employee Mobile Number" ControlToValidate="txtEmpMobile" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Phone Number  </td>

                            <td>
                                <asp:TextBox Style="height: 22pt; width: 80%; top: 0 !important;" class="setCalender" ID="txtEmpPhone" runat="server" Height="30" Width="80%" ToolTip="Employee Mobile" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator34" runat="server" ErrorMessage="Employee Phone Number" ControlToValidate="txtEmpPhone" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Date of Joining</td>
                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="txtDtOfJoining" runat="server" Height="30" Width="80%" ToolTip="Employee date of birth" ReadOnly="true" />
                                    <asp:RequiredFieldValidator ID="DOJValid" runat="server" ErrorMessage="Employee Date of Joining" ControlToValidate="txtDtOfJoining"
                                        Display="None" SetFocusOnError="True"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Job Type</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpJobType" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Permanent</asp:ListItem>
                                        <asp:ListItem>Temporarly</asp:ListItem>
                                        <asp:ListItem>Probationary</asp:ListItem>
                                        <asp:ListItem>Contractual</asp:ListItem>
                                        <asp:ListItem>Consultants</asp:ListItem>
                                        <asp:ListItem>Visiting</asp:ListItem>
                                        <asp:ListItem>Faculty</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Access Right</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="DrpEmpRoleID" runat="server" Style="height: 22pt; width: 10%;">
                                        <asp:ListItem>1</asp:ListItem>
                                        <asp:ListItem>2</asp:ListItem>
                                        <asp:ListItem>3</asp:ListItem>
                                        <asp:ListItem>4</asp:ListItem>
                                    </asp:DropDownList>
                                    <asp:Label CssClass="ErrorMsg" ID="lblRoleInfo" Style="font-size-adjust: 0.40 !important; height: 22pt; width: 70%;" runat="server" Text="1.Employee, 2. HR 3. Managers 4. Admin"></asp:Label>

                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Desgination & Department</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpDesignation" runat="server" Style="height: 22pt; width: 39%;">
                                        <asp:ListItem>Executive</asp:ListItem>
                                        <asp:ListItem>Manager</asp:ListItem>
                                        <asp:ListItem>Supervisor</asp:ListItem>
                                        <asp:ListItem>Team Leader</asp:ListItem>
                                        <asp:ListItem>Accountant</asp:ListItem>
                                    </asp:DropDownList>

                                    <asp:DropDownList ID="drpDept" runat="server" Style="height: 22pt; width: 40%;">
                                        <asp:ListItem>HR Admin</asp:ListItem>
                                        <asp:ListItem>Information Technology</asp:ListItem>
                                        <asp:ListItem>Account</asp:ListItem>
                                        <asp:ListItem>Sales</asp:ListItem>
                                        <asp:ListItem>Purchase</asp:ListItem>
                                        <asp:ListItem>Help & Support</asp:ListItem>
                                        <asp:ListItem>Marketting</asp:ListItem>
                                        <asp:ListItem>Business Development</asp:ListItem>
                                        <asp:ListItem>House Keeping</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Work Location</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpWorkLocation" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>New Delhi</asp:ListItem>
                                        <asp:ListItem>Chennai</asp:ListItem>
                                        <asp:ListItem>Mumbai</asp:ListItem>
                                        <asp:ListItem>Bardoa</asp:ListItem>
                                        <asp:ListItem>Banglore</asp:ListItem>
                                        <asp:ListItem>Cochin</asp:ListItem>
                                        <asp:ListItem>Hyderabad</asp:ListItem>
                                        <asp:ListItem>Kolkata</asp:ListItem>
                                        <asp:ListItem>Lucknow</asp:ListItem>
                                        <asp:ListItem>Kanpur</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Work Division</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpWorkDivision" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Mumbai Div 1</asp:ListItem>
                                        <asp:ListItem>Mumbai Div 2</asp:ListItem>
                                        <asp:ListItem>Chennai Div 1</asp:ListItem>
                                        <asp:ListItem>Andheri</asp:ListItem>
                                        <asp:ListItem>Powai</asp:ListItem>
                                        <asp:ListItem>Churchgate</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Team Name</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpTeamName" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Junior Team</asp:ListItem>
                                        <asp:ListItem>Senior Team</asp:ListItem>
                                        <asp:ListItem>Faculty Team Div 1</asp:ListItem>
                                        <asp:ListItem>Training Team</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Reporting Manager Name</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpReportingMgr" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Select Name</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="empFamilyDetails" class="EmpProfileTabPD tahHead" onclick="showhide4()" style="cursor: pointer;" title="Click to show information">Personal Information
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblPropertiesFamily" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Father / Husband Name </td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpFathHusName" runat="server" Style="height: 22pt; width: 15%;">
                                        <asp:ListItem>Mr.</asp:ListItem>
                                        <asp:ListItem>Ms.</asp:ListItem>
                                        <asp:ListItem>Mrs.</asp:ListItem>
                                        <asp:ListItem>Smt.</asp:ListItem>
                                    </asp:DropDownList>
                                    <asp:TextBox Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtBoxFHName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Mother Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpMotherName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Place of Birth</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpPlaceOfBirth" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Employee Current Address </td>
                            <td>
                                <textarea id="txtEmpCompleteAddress" cols="20" rows="3" runat="server" style="padding-left: 10px !important; resize: none; width: 81% !important;"></textarea>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator29" runat="server" ErrorMessage="Enter Current Address" ControlToValidate="txtEmpCompleteAddress" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Area Name/ Town Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpTownName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator30" runat="server" ErrorMessage="Enter Town Name" ControlToValidate="txtEmpTownName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">City Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpCityName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator31" runat="server" ErrorMessage="Enter City Name" ControlToValidate="txtEmpCityName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">State Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpStateName" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator32" runat="server" ErrorMessage="Enter State Name" ControlToValidate="txtEmpCityName" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Postal Code</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpAddPincode" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator41" runat="server" ErrorMessage="Enter Postal Code" ControlToValidate="txtEmpAddPincode" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Country Name </td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpCountry" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>India</asp:ListItem>
                                        <asp:ListItem>UAE</asp:ListItem>
                                        <asp:ListItem>Saudi Arabia</asp:ListItem>
                                        <asp:ListItem>USA</asp:ListItem>
                                        <asp:ListItem>UK</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Nationality</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpNationality" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Indian</asp:ListItem>
                                        <asp:ListItem>Other</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Marital Status</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpMaritalStatus" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Un-Married</asp:ListItem>
                                        <asp:ListItem>Married</asp:ListItem>
                                        <asp:ListItem>Not Disclosed</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Blood Group</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpBloodGroup" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>O-Positive</asp:ListItem>
                                        <asp:ListItem>O-Negative</asp:ListItem>
                                        <asp:ListItem>A-Positive</asp:ListItem>
                                        <asp:ListItem>A-Negative</asp:ListItem>
                                        <asp:ListItem>B-Positive</asp:ListItem>
                                        <asp:ListItem>B-Negative</asp:ListItem>
                                        <asp:ListItem>AB-Positive</asp:ListItem>
                                        <asp:ListItem>AB-Negative</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Hobbies / Interests </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpHobbies" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <%-- Education and Profession --%>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="EmpHistoryArea" class="EmpProfileTabPD tahHead" onclick="showhide9()" style="cursor: pointer;" title="Click to show information">Education and Employment Information
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblPropertiesHistory" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Highest Qualification</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpEducationHigh" runat="server" Style="height: 22pt; width: 81%;">
                                        <asp:ListItem>Below SSC</asp:ListItem>
                                        <asp:ListItem>SSC</asp:ListItem>
                                        <asp:ListItem>HSC</asp:ListItem>
                                        <asp:ListItem>BA</asp:ListItem>
                                        <asp:ListItem>BCA</asp:ListItem>
                                        <asp:ListItem>BSc</asp:ListItem>
                                        <asp:ListItem>BMS</asp:ListItem>
                                        <asp:ListItem>BE</asp:ListItem>
                                        <asp:ListItem>BTech</asp:ListItem>
                                        <asp:ListItem>MA</asp:ListItem>
                                        <asp:ListItem>MCA</asp:ListItem>
                                        <asp:ListItem>MSc</asp:ListItem>
                                        <asp:ListItem>ME</asp:ListItem>
                                        <asp:ListItem>MCom</asp:ListItem>
                                        <asp:ListItem>MTech</asp:ListItem>
                                        <asp:ListItem>Other Graduate</asp:ListItem>
                                        <asp:ListItem>Post Graduate</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Previous Employer Name </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtPreEmployer" runat="server" Width="80%" ToolTip="Previous Employer Name" ReadOnly="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Position Held</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtPreEmpDesignation" runat="server" Width="80%" ToolTip="Previous Position" ReadOnly="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Experience (In Years)</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtPreEmpExp" runat="server" Width="80%" ToolTip="Previous Experience in Yrs" ReadOnly="False" />

                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Date of Leaving</td>
                            <td>
                                <div runat="server" style="width: 100% !important; padding: 4px 0px 4px 0px;">
                                    <asp:TextBox class="setCalender" ID="txtEmpPreEmpLeave" runat="server" Height="30" Width="80%" ToolTip="Employee date of birth" ReadOnly="true" />
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="empCTCdata" class="EmpProfileTabPD tahHead" onclick="showhide5()" style="cursor: pointer;" title="Click to show information">CTC Information
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblEmpCTC" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <%--<asp:UpdatePanel ID="salUpdate" runat="server">
                        <Triggers>
                            <asp:AsyncPostBackTrigger ControlID="txtMQty" EventName="TextChanged" />
                        </Triggers>
                        <ContentTemplate>--%>
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Select Paying Grade</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpPayingGrade" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Grade I</asp:ListItem>
                                        <asp:ListItem>Grade II</asp:ListItem>
                                        <asp:ListItem>Grade III</asp:ListItem>
                                        <asp:ListItem>Grade IV</asp:ListItem>
                                        <asp:ListItem>Grade V</asp:ListItem>
                                        <asp:ListItem>Grade VI</asp:ListItem>
                                        <asp:ListItem>Grade VII</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Enter Basic Salary Amount</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtBasicSal" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                    <br />
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" ErrorMessage="Basic Salary" ControlToValidate="txtBasicSal" Display="None"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">House Rent Allowance (HRA) </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtHRA_Amount" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" ErrorMessage="HRA Amount" ControlToValidate="txtHRA_Amount" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Professional Tax Amount</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtPTAmount" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator8" runat="server" ErrorMessage="Professional Tax Amount" ControlToValidate="txtPTAmount" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Education Allowance</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtEduAmount" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator9" runat="server" ErrorMessage="Education Allowance" ControlToValidate="txtEduAmount" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">LT Allowance</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtLTAampunt" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator10" runat="server" ErrorMessage="LT Allowance" ControlToValidate="txtLTAampunt" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Provident Fund </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtPFamount" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator11" runat="server" ErrorMessage="Provident Fund" ControlToValidate="txtPFamount" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Medical (ESIC)</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtESICAmount" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator12" runat="server" ErrorMessage="Medical Allowance" ControlToValidate="txtESICAmount" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Conveyance Allowances</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 40%; top: 0 !important;" class="setCalender" ID="txtEmpConveyance" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" /><asp:Label runat="server" Text="%"></asp:Label>
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator24" runat="server" ErrorMessage="Conveyance Allowances Amount" ControlToValidate="txtEmpConveyance" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Other Deduction Amount</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpSalOtherDed" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Click button <b>'Calculate Net Salary'</b></td>
                            <td>
                                <asp:LinkButton class="EmpProfileTabPD" OnClick="btnSumNetSalary_Click" ID="btnSumNetSalary" runat="server">Calculate Net Salary </asp:LinkButton>
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Total Deduction Amount</td>
                            <td>
                                <asp:TextBox Text="0" Style="color: orangered; height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtDedAmount" runat="server" Width="80%" ToolTip="Employee first name" Enabled="false" ReadOnly="true" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator13" runat="server" ErrorMessage="Deduction Amount" ControlToValidate="txtDedAmount" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Total Earnings</td>
                            <td>
                                <asp:TextBox Text="0" Style="color: orangered; height: 22pt; width: 81%; top: 0 !important;" Enabled="false" class="setCalender" ID="txtTotalEarning" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="true" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator14" runat="server" ErrorMessage="Total Salary Earning" ControlToValidate="txtTotalEarning" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Net Pay</td>
                            <td>
                                <asp:TextBox Text="0" Style="color: orangered; height: 22pt; width: 81%; top: 0 !important;" Enabled="false" class="setCalender" ID="txtNetSalary" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="true" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator15" runat="server" ErrorMessage="Total Net Salary Mother Name" ControlToValidate="txtNetSalary" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                    </tbody>
                    <%--</ContentTemplate>
                    </asp:UpdatePanel>--%>
                </table>
            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="EmpidDetails" class="EmpProfileTabPD multiIcon tahHead" onclick="showhide6()" style="cursor: pointer;" title="Click to show information">Bank & ID Information
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblEmpidDetails" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Bank Account Number</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpBankAcNo" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Bank Name</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpBank" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Bank Branch Name</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpbankBranch" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Bank IFCS & MICR Code </td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 39.5%; top: 0 !important;" class="setCalender" ID="txtEmpBankIFSC" runat="server" ToolTip="Employee Middle name" ReadOnly="False" />
                                <asp:TextBox Style="height: 22pt; width: 39%; top: 0 !important;" class="setCalender" ID="txtEmpBankMICR" runat="server" ToolTip="Employee Last name" ReadOnly="False" />
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Accounty Type</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:DropDownList ID="drpEmpAcType" runat="server" Style="height: 22pt; width: 80%;">
                                        <asp:ListItem>Saving Account</asp:ListItem>
                                        <asp:ListItem>Salary Account</asp:ListItem>
                                        <asp:ListItem>Current Account</asp:ListItem>
                                        <asp:ListItem>Credit Card</asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">PAN Number</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpPAN" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />

                                <asp:RequiredFieldValidator ID="RequiredFieldValidator20" runat="server" ErrorMessage="Enter PAN Number" ControlToValidate="txtEmpPAN" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Aadhar Number</td>
                            <td>
                                <asp:TextBox MaxLength="16" Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpAadhaar" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />

                                <asp:RequiredFieldValidator ID="RequiredFieldValidator21" runat="server" ErrorMessage="Enter Aadhar Number" ControlToValidate="txtEmpAadhaar" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>


                        <tr>
                            <td colspan="2" class="tableTDFields">PF / UAN Number</td>
                            <td>
                                <asp:TextBox MaxLength="16" Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtPfUan" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator22" runat="server" ErrorMessage="PF / UAN Number" ControlToValidate="txtPfUan" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Medical ESIC Number</td>
                            <td>
                                <asp:TextBox MaxLength="16" Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtEmpESICNo" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator33" runat="server" ErrorMessage="Enter ESIC Number" ControlToValidate="txtPfUan" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">PRAN / Pension Number</td>
                            <td>
                                <asp:TextBox MaxLength="16" Style="height: 22pt; width: 81%; top: 0 !important;" class="setCalender" ID="txtPranPension" runat="server" Width="80%" ToolTip="Employee first name" ReadOnly="False" />
                                <br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator23" runat="server" ErrorMessage="Enter PRAN /Pension Number" ControlToValidate="txtPranPension" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="empLeaveDetails" class="EmpProfileTabPD multiIcon tahHead" onclick="showhide7()" style="cursor: pointer;" title="Click to show leave information">Leave Information
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblEmpLeaveDetails" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Total Paid Leave (In Days)</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:TextBox Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtPLDays" runat="server" Width="70%" ToolTip="Employee first name" ReadOnly="False" />
                                    <asp:Label runat="server" CssClass="ErrorMsg">Days</asp:Label><br />
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator25" runat="server" ErrorMessage="No. of Paid Leave " ControlToValidate="txtPLDays" Display="None"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Total Casual Leave (In Days)</td>
                            <td>
                                <div class="fixLength" runat="server">
                                    <asp:TextBox Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtCLDays" runat="server" Width="70%" ToolTip="Employee first name" ReadOnly="False" />
                                    <asp:Label runat="server" CssClass="ErrorMsg">Days</asp:Label>
                                    <br />
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator27" runat="server" ErrorMessage="No. of Casual Leaves" ControlToValidate="txtCLDays" Display="None"></asp:RequiredFieldValidator>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="tableTDFields">Total Sick Leave (In Days)</td>
                            <td>
                                <asp:TextBox Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtSLDays" runat="server" Width="70%" ToolTip="Employee first name" ReadOnly="False" />
                                <asp:Label runat="server" CssClass="ErrorMsg">Days</asp:Label><br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator28" runat="server" ErrorMessage="No. of Sick Leaves" ControlToValidate="txtSLDays" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields"></td>
                            <td>
                                <asp:Button Text="Show Total" class="EmpProfileTabPD" OnClick="lblCountLeaveForEmp_Click" ID="lblCountLeaveForEmp" runat="server"></asp:Button>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" class="tableTDFields">Grand Total of Leave (In Days)</td>
                            <td>
                                <asp:TextBox Text="0" Style="height: 22pt; width: 65%; top: 0 !important;" class="setCalender" ID="txtTotalLeave" Enabled="false" runat="server" Width="70%" ToolTip="Employee first name" ReadOnly="true" />
                                <asp:Label runat="server" CssClass="ErrorMsg">Days</asp:Label><br />
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator39" runat="server" ErrorMessage="Total Leaves Name" ControlToValidate="txtTotalLeave" Display="None"></asp:RequiredFieldValidator>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <h4 id="empDocDetails" class="EmpProfileTabPD multiIcon tahHead" onclick="showhide8()" style="cursor: pointer;" title="Click to show leave information">Attachments / Documents
            <span itemid="ram1" class="right active"></span></h4>
                <table id="tblEmpDocDetails" style="display: none; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="text-align: center;">
                                <div style="border-bottom: 2pt solid orangered; display: flex; height: 250px; padding: 2pt !important;">
                                    <div style="width: 45% !important">
                                        <asp:Image ToolTip="Aadhar Card Copy" ID="Image1" ImageUrl="/../images/PP.png" Height="150px" Width="100px" runat="server" Style="border-radius: 0%; width: auto; border: dotted 1pt orangered;" />
                                        <br />
                                        <br />
                                        <asp:Label CssClass="EmpProfileTabPD" runat="server" ID="lblAadhar" Text="Aadhar Card Copy"></asp:Label>
                                        <br />
                                    </div>
                                    <div class="clear"></div>
                                    <div style="width: 45% !important; align-self: center;">
                                        <asp:Label runat="server" Font-Bold="true" Font-Size="Medium" ForeColor="OrangeRed" Text="Upload/Update Employee Aadhar Card Copy"></asp:Label>
                                        <asp:FileUpload class="EmpProfileTabPD" Style="padding: 3%;" ID="EmpAadharCopy" runat="server" />
                                        <br />
                                        <br />
                                        <asp:Button class="LogBtn" ID="btnUploadAddressProof" runat="server" Text="Save Image" Style="width: 85px; height: 30px !important" />
                                        <asp:Label ID="Label3" runat="server" />
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="text-align: center;">

                                <div style="border-bottom: 2pt solid orangered; display: flex; height: 250px; padding: 2pt !important;">
                                    <div style="width: 45% !important">
                                        <asp:Image ToolTip="Aadhar Card Copy" ID="Image2" ImageUrl="/../images/PP.png" Height="150px" Width="100px" runat="server" Style="border-radius: 0%; width: auto; border: dotted 1pt orangered;" />
                                        <br />
                                        <br />
                                        <asp:Label CssClass="EmpProfileTabPD" runat="server" ID="Label2" Text="ID Proof Copy"></asp:Label>
                                        <br />
                                    </div>
                                    <div class="clear"></div>

                                    <div style="width: 45% !important; align-self: center;">
                                        <asp:Label runat="server" Font-Bold="true" Font-Size="Medium" ForeColor="OrangeRed" Text="Upload/Update Employee ID Card Copy"></asp:Label>
                                        <asp:FileUpload class="EmpProfileTabPD" Style="padding: 3%;" ID="empIDCopy" runat="server" />
                                        <br />
                                        <br />
                                        <asp:Button class="LogBtn" ID="btnUploadEmpIDProof" runat="server" Text="Save Image" Style="width: 85px; height: 30px !important" />
                                        <asp:Label ID="Label4" runat="server" />
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="formMjr multiAccordion" style="padding-top: 0 !important;">
            <div class="empProfileSummary multiAccordion" runat="server">
                <table id="tblSubmitArea" style="display: block; width: 100%; box-sizing: border-box !important; margin-top: 15pt !important; margin: 0 !important;">
                    <tbody style="width: 100%;">
                        <tr>
                            <td colspan="3">
                                <asp:Label ID="lblAddEmpErrorMsg" CssClass="ErrorMsg" runat="server"></asp:Label>
                                <asp:ValidationSummary ID="errorValidation" runat="server" ShowMessageBox="True" HeaderText="Please Enter following below details" ToolTip="Error: Mandatory Information" ShowSummary="False" />
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center; width: 100% !important;">
                                <asp:Button ID="btnSaveEmpRegistration" Text="Confirm and Save" runat="server" class="LogBtn" OnClick="btnSaveEmpRegistration_Click" />&nbsp;
                                <asp:Button ID="btnResetRegistrationData" Text="Reset Data" runat="server" class="LogBtn" />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <hr />
            </div>
        </div>
    </div>
    <div style="visibility: hidden; display: none;">
        // Employee Name, LeaveCode, EmpCode, Type, AppDate, StartDate, EndDate, TotalDays, Status, ApprovedBy, ApprovedDate, Remarks
        <asp:Label ID="EmailEmpName" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveCode" runat="server"></asp:Label>
        <asp:Label ID="EmailEmpCode" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveType" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveAppDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveStDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveEndDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveTotalDays" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveStatus" runat="server"></asp:Label>
        <asp:Label ID="EmailApprovalMgr" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveApproveDate" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveRemarks" runat="server"></asp:Label>
        <asp:Label ID="EmailLeaveEmailTo" runat="server"></asp:Label>
    </div>
</asp:Content>
