﻿<%@ Page Title="" Language="C#" MasterPageFile="~/hrs/hrsMasterPage.master" AutoEventWireup="true" CodeFile="update-attendance.aspx.cs" Inherits="update_employee_attendance" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Employee Attendance Registration</div>
        <div class="formMjr" style="width: 98% !important; padding: 2pt !important;" runat="server">

            <table style="width: 100%; padding: 0 !important; margin: 0 !important; padding-top: 1pt !important; padding-bottom: 5pt !important; box-shadow: 0 10px 10px -8px #333 !important; height: 20px;">
                <tbody style="width: 100% !important">
                    <tr>
                        <td></td>
                    </tr>

                    <tr>
                        <td class="tableTDFields" colspan="1" style="padding: 2% !important; text-align: left; font-weight: 800; font-size: medium; color: orangered;">Enter Employee Code/Email ID</td>
                        <td colspan="2">
                            <div class="fixLength" runat="server">
                                <asp:TextBox ID="txtEmpIdOrEmail" runat="server" CssClass="txtBoxNewUser" Placeholder="Emp. Code/Email ID" Style="height: 30pt !important; width: 80% !important; padding: 2% !important; font-weight: bolder;"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" ControlToValidate="txtEmpIdOrEmail" Display="None" SetFocusOnError="true" runat="server" ErrorMessage="Enter Email ID or Emp Code"></asp:RequiredFieldValidator>
                                

                            </div>
                        </td>
                    </tr>
                    <tr>

                        <td class="tableTDFields" colspan="1" style="padding: 2% !important; text-align: left; font-weight: 800; font-size: medium; color: orangered;">Select Attendance Date</td>
                        <td colspan="2">
                            <div class="fixLength" runat="server">
                                <asp:TextBox Style="height: 30pt !important; width: 80% !important; padding: 2% !important; font-weight: bolder;" CssClass="setCalender txtBoxNewUser" ID="dtAttUpdateSelectedForEmp" runat="server" ToolTip="Select Date" ReadOnly="true" />
                                <asp:RequiredFieldValidator ID="requiredDtAttendance" ControlToValidate="dtAttUpdateSelectedForEmp" runat="server" Display="None" SetFocusOnError="true" ErrorMessage="Attendance Date"></asp:RequiredFieldValidator>
                            </div>
                        </td>
                    </tr>

                    <tr>

                        <td class="tableTDFields" colspan="1" style="padding: 2% !important; text-align: left; font-weight: 800; font-size: medium; color: orangered;"></td>
                        <td colspan="2">
                            <div class="fixLength" runat="server">
                                <asp:Button ToolTip="Click And Search Employee Attendance" class="EmpProfileTabPD" ID="btnAttUpdate" Text="Find Employee Attendance" runat="server" Style="cursor: pointer; width: 60% !important; padding: 0 !important; height: 35px !important; margin: 0 !important;" OnClick="btnAttUpdate_Click" />
                            </div>
                        </td>
                    </tr>


                    <tr>
                        <td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            <div class="clear"></div>
            <asp:GridView ID="grdDataForUpdateAttendance" Style="margin-bottom: 10pt; font-size: 12px; font-size-adjust: 0.88 !important; border-color: #DEBA84; border-width: 1px; border-style: None; font-size: 100% !important; font-size-adjust: 0.48 !important; line-height: 23pt;" CssClass="LeaveRecordsList" runat="server" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="3" CellSpacing="2" EnableModelValidation="True" HeaderStyle-Height="120%" Visible="True">
                <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                <HeaderStyle BackColor="orangered" Font-Bold="True" ForeColor="White" />
                <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                <RowStyle BackColor="white" ForeColor="orangered" />
                <SelectedRowStyle BackColor="cornsilk" Font-Bold="True" ForeColor="#fc4508" />
                <Columns>
                    <asp:TemplateField HeaderText="SrNo">
                        <ItemTemplate>
                            <asp:Label ID="lblAttSrNo" runat="server" Text='<%#Eval("SrNo")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <Columns>
                    <asp:TemplateField HeaderText="Emp. Code">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpCodeGrd" runat="server" Text='<%#Eval("EmpCode")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <Columns>
                    <asp:TemplateField HeaderText="Emp No.">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpNoGrd" runat="server" Text='<%#Eval("EmpNo")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>

                <Columns>
                    <asp:TemplateField HeaderText="Employee Name">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpNameGrd" runat="server" Text='<%#Eval("EmpName")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                
                <Columns>
                    <asp:TemplateField HeaderText="Makred Date">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpPreAttDate" runat="server" Text='<%#Eval("AttendanceDate")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>


                <Columns>
                    <asp:TemplateField HeaderText="Marked Status">
                        <ItemTemplate>
                            <asp:Label ID="lblEmpPreAttStatus" runat="server" Text='<%#Eval("AttendanceStatus")%>'> </asp:Label>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>


                <Columns>
                    <asp:TemplateField HeaderText="Update Attendance">
                        <ItemTemplate>
                            <table runat="server" style="width: 100% !important;">
                                <tr>
                                    <td class="ErrorMsg footerButton" style="background-color:white; color:orangered; padding:1% !important">
                                        <asp:RadioButton Checked="true" ID="r1" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="P" ToolTip="P = Present" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r2" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="A" ToolTip="A = Absent" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r3" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="O" ToolTip="O = On Outdoor Duty" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r4" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="PL" ToolTip="L = Leave" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                        <asp:RadioButton Checked="false" ID="r5" Style="cursor: pointer; line-height: 20pt; font-weight: 800; margin-left: 3pt; margin-right: 3pt;" GroupName="rdoMarkPresentAbsent" Text="UL" ToolTip="L = Leave" runat="server" Font-Bold="True" BorderStyle="NotSet" />
                                    </td>
                                </tr>
                            </table>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
            <div class="clear"></div>
            <br />
            <table style="width: 100% !important; text-align: center !important;">
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="3" style="text-align: center !important;">
                        <asp:Button Text="Update Attendance" ID="btnMarkAttendance" runat="server" class="LogBtn" OnClick="btnUpdateAttendance_Click" />&nbsp;
                        <asp:Button CssClass="LogBtn" Text="Attendance History" runat="server" ID="btnMarkAttNewHistory" OnClick="btnMarkAttNewHistory_Click" />&nbsp;
                        <asp:Button CssClass="LogBtn" Text="New Attendance" ID="btnUpdateAttNewAtt" runat="server" OnClick="btnUpdateAttNewAtt_Click" />&nbsp;
                        <asp:Button ID="btnResetAttendance" Text="Clear Data" runat="server" class="LogBtn" />
                    </td>
                </tr>
                <tr>
                    <td style="width: 100% !important; text-align: left !important;">
                        <asp:Label Visible="true" ID="lblErrorMsgOnLeaveGrid" class="ErrorMsg" runat="server">
                        </asp:Label>
                        <asp:ValidationSummary ID="errorSummaryForAttUpdate" runat="server" ShowMessageBox="True" ShowSummary="False" />
                        <asp:LinkButton Text="" ID="lblViewSelectedGridData" runat="server"></asp:LinkButton>
                    </td>
                </tr>
            </table>

        </div>
    </div>

</asp:Content>
