﻿<%@ Page Title="" Language="C#" MasterPageFile="~/hrs/hrsMasterPage.master" AutoEventWireup="true" CodeFile="whatsnew.aspx.cs" Inherits="hrs_whatsnew" %>

<%-- Add content controls here --%>
