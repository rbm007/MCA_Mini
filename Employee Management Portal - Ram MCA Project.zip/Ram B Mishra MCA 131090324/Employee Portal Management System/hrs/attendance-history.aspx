﻿<%@ Page Title="" Language="C#" MasterPageFile="~/hrs/hrsMasterPage.master" AutoEventWireup="true" CodeFile="attendance-history.aspx.cs" Inherits="employee_attendance_history" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="dtEmpAttendanceHistory" ContentPlaceHolderID="pageDataContainer" runat="server">
    <div id="attHistory" class="ntraining" style="width: 800px; margin: 0 auto;" runat="server">
        <div id="thisContainer" class="profileTopBanner" runat="server">Employee Attendance Summary</div>
        <div class="formMjr" style="width: 98% !important; padding: 2pt !important;" runat="server">
            <table style="width: 100%; padding: 0 !important; margin: 0 !important; padding-top: 1pt !important; padding-bottom: 5pt !important; box-shadow: 0 10px 10px -8px #333 !important; height: 20px;">
                <tbody style="width: 100% !important">
                    <tr>
                        <td></td>
                    </tr>
                </tbody>
            </table>

            <div class="clear"></div>

            <asp:GridView ID="grdViewAttendanceRecords" AllowPaging="true" PagerSettings-Mode="NumericFirstLast" Style="margin-bottom: 10pt; font-size: 12px; font-size-adjust: 0.88 !important; border-color: #DEBA84; border-width: 1px; border-style: None; font-size: 100% !important; font-size-adjust: 0.48 !important; line-height: 23pt;" CssClass="LeaveRecordsList" runat="server" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="3" CellSpacing="2" EnableModelValidation="True" HeaderStyle-Height="120%" OnSelectedIndexChanging="grdViewLeaveRecords_SelectedIndexChanging">
                <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" /> 
                <HeaderStyle BackColor="orangered" Font-Bold="True" ForeColor="White" />
                <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                <RowStyle BackColor="white" ForeColor="orangered" />
                <SelectedRowStyle BackColor="cornsilk" Font-Bold="True" ForeColor="#fc4508" />
                <PagerSettings Mode="NumericFirstLast" PageButtonCount="13" Position="TopAndBottom" FirstPageText="First" LastPageText="Last"/>
            </asp:GridView>

            <table style="width:100% !important;"   runat="server">
                <tr>
                    <td colspan="3" style="text-align: center !important;">
<asp:Button Text="Import" ID="btnImportAttendance" runat="server" class="LogBtn" OnClick="btnImportAttendance_Click" />&nbsp;
<asp:Button OnClick="Page_Load" id="btnResetAttendance" text="Refresh" runat="server" class="LogBtn" />&nbsp;
<asp:Button CssClass="LogBtn" Text="New Attendance"  runat="server" ID="btnMarkAttNew" OnClick="btnMarkAttNew_Click" />&nbsp;
<asp:Button CssClass="LogBtn"  Text="Update Attendance" ID="btnUpdateAttNew"  runat="server" OnClick="btnUpdateAttNew_Click" />

                    </td>
                </tr>
            </table>
            <br />
            <br />
            <hr />
            <br />
            <asp:Label ID="lblErrorMsgOnLeaveGrid" class="ErrorMsg" runat="server">
            </asp:Label>
            <br />
            <br />
            <asp:LinkButton Text="" ID="lblViewSelectedGridData" runat="server"></asp:LinkButton>

        </div>
    </div>
</asp:Content>
