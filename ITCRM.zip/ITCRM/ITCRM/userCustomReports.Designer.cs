﻿namespace ITCRM
{
    partial class userCustomReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.rpVwr_Sheet = new Microsoft.Reporting.WinForms.ReportViewer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnReportGenerate = new System.Windows.Forms.Button();
            this.btnExitReport = new System.Windows.Forms.Button();
            this.HCDataSet1 = new ITCRM.HCDataSet1();
            this.HC_REQ_RESUMEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.HC_REQ_RESUMETableAdapter = new ITCRM.HCDataSet1TableAdapters.HC_REQ_RESUMETableAdapter();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HCDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HC_REQ_RESUMEBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // rpVwr_Sheet
            // 
            this.rpVwr_Sheet.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.HC_REQ_RESUMEBindingSource;
            this.rpVwr_Sheet.LocalReport.DataSources.Add(reportDataSource1);
            this.rpVwr_Sheet.LocalReport.ReportEmbeddedResource = "ITCRM.recruitmentRep.rdlc";
            this.rpVwr_Sheet.Location = new System.Drawing.Point(4, 20);
            this.rpVwr_Sheet.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rpVwr_Sheet.Name = "rpVwr_Sheet";
            this.rpVwr_Sheet.Size = new System.Drawing.Size(1224, 687);
            this.rpVwr_Sheet.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnExitReport);
            this.groupBox1.Controls.Add(this.btnReportGenerate);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(26, 80);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(1232, 142);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input for report";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rpVwr_Sheet);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(26, 222);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1232, 711);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd-MMM-yyyy dddd";
            this.dateTimePicker1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(253, 57);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(211, 22);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Date Range";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd-MMM-yyyy dddd";
            this.dateTimePicker2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(253, 94);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(211, 22);
            this.dateTimePicker2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(209, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "From";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(226, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 14);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(4, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1224, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = "1. Select Date Range ==> 2. Select Client ==> 3. Click to Generate button to get " +
    "report.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(558, 93);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(393, 24);
            this.comboBox1.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(555, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Select Client Name";
            // 
            // btnReportGenerate
            // 
            this.btnReportGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReportGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReportGenerate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnReportGenerate.Location = new System.Drawing.Point(1045, 43);
            this.btnReportGenerate.Name = "btnReportGenerate";
            this.btnReportGenerate.Size = new System.Drawing.Size(101, 32);
            this.btnReportGenerate.TabIndex = 8;
            this.btnReportGenerate.Text = "&Generate";
            this.btnReportGenerate.UseVisualStyleBackColor = true;
            // 
            // btnExitReport
            // 
            this.btnExitReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExitReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExitReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnExitReport.Location = new System.Drawing.Point(1045, 84);
            this.btnExitReport.Name = "btnExitReport";
            this.btnExitReport.Size = new System.Drawing.Size(101, 32);
            this.btnExitReport.TabIndex = 9;
            this.btnExitReport.Text = "&Exit";
            this.btnExitReport.UseVisualStyleBackColor = true;
            this.btnExitReport.Click += new System.EventHandler(this.btnExitReport_Click);
            // 
            // HCDataSet1
            // 
            this.HCDataSet1.DataSetName = "HCDataSet1";
            this.HCDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // HC_REQ_RESUMEBindingSource
            // 
            this.HC_REQ_RESUMEBindingSource.DataMember = "HC_REQ_RESUME";
            this.HC_REQ_RESUMEBindingSource.DataSource = this.HCDataSet1;
            // 
            // HC_REQ_RESUMETableAdapter
            // 
            this.HC_REQ_RESUMETableAdapter.ClearBeforeFill = true;
            // 
            // userCustomReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 960);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "userCustomReports";
            this.Padding = new System.Windows.Forms.Padding(26, 80, 26, 27);
            this.Load += new System.EventHandler(this.userCustomReports_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HCDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HC_REQ_RESUMEBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer rpVwr_Sheet;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnReportGenerate;
        private System.Windows.Forms.Button btnExitReport;
        private System.Windows.Forms.BindingSource HC_REQ_RESUMEBindingSource;
        private HCDataSet1 HCDataSet1;
        private HCDataSet1TableAdapters.HC_REQ_RESUMETableAdapter HC_REQ_RESUMETableAdapter;
    }
}