﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Windows.Forms.Design;

namespace ITCRM
{
    public partial class Login : MetroFramework.Forms.MetroForm
    {

        SqlConnection LogCon = new SqlConnection(Properties.Settings.Default.con);
        SqlDataAdapter adp;
        DataSet ds;
        public Login()
        {
            InitializeComponent();
        }
        public class GetUserValue
        {
            public string userLoginName;
            public string userFullNm;
        }
        private void Login_Load(object sender, EventArgs e)
        {
            callReset();
            txtITEmpUserName.Focus();
                       

        }
        protected void callReset()
        {
            txtITEmpPassKey.Text = "";
            txtITEmpUserName.Text = "";
            txtITEmpUserName.Focus();
        }

        private void linkLoginAsst_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Contact your IT Administrator to recover your password."
                + "\n\nContact Support\n--------------------------------------\nEmail ID : support2@jvi-global.com \n"
                + "Phone No : 022 67241624\nSkype ID : jvi_training\n", "Login Assistant", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        }
        private void btnLoginCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnLoginContinue_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtITEmpUserName.Text == "" || txtITEmpPassKey.Text == "")
                {
                    MessageBox.Show("Please Enter Username and Password to continue", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    callReset();

                }
                else
                {
                    acceptUserLogin();
                }
            } catch(Exception ex)
            {
                MessageBox.Show("Connection to server has been failed.\nYou can try re-loggin or check your network cable connection.","Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            }
        protected void acceptUserLogin()
        {
            try
            {
                string selectUser = "Select ELoginName,EPreFix + ' ' + EFirstName + ' ' + ELastName As EFName, EPassKey from JVIEmp with(nolock) Where EWorkingStatus='Working' AND ELoginName=@un AND EPassKey=@pk";
                adp = new SqlDataAdapter(selectUser, LogCon);

                adp.SelectCommand.Parameters.AddWithValue("@un", txtITEmpUserName.Text.ToString().Trim());
                adp.SelectCommand.Parameters.AddWithValue("@pk", txtITEmpPassKey.Text.ToString().Trim());

                ds = new DataSet();
                LogCon.Open();
                adp.Fill(ds, "JVIEmp");
                LogCon.Close();

                if (ds.Tables["JVIEmp"].Rows.Count > 0)
                {
                    GetUserValue gtUser = new GetUserValue();
                    gtUser.userLoginName = txtITEmpUserName.Text.ToString();
                    gtUser.userFullNm = string.Format("{0}", ds.Tables["JVIEmp"].DefaultView[0]["EFName"]);
                    frmDashBoard frmNew = new frmDashBoard(gtUser);
                    frmNew.Show();
                    this.Hide();


                }
                else
                {
                    MessageBox.Show("Invalid Username or Password Entered", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    callReset();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred" + ex.ToString() + ".", "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                callReset();
            }
        }
    }
}
