﻿namespace ITCRM
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.btnLoginContinue = new System.Windows.Forms.Button();
            this.loginPanel = new System.Windows.Forms.Panel();
            this.linkLoginAsst = new System.Windows.Forms.LinkLabel();
            this.btnLoginCancel = new System.Windows.Forms.Button();
            this.txtITEmpPassKey = new System.Windows.Forms.TextBox();
            this.txtITEmpUserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.loginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoginContinue
            // 
            this.btnLoginContinue.BackColor = System.Drawing.Color.White;
            this.btnLoginContinue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLoginContinue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoginContinue.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLoginContinue.FlatAppearance.BorderSize = 2;
            this.btnLoginContinue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnLoginContinue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnLoginContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoginContinue.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginContinue.ForeColor = System.Drawing.Color.Maroon;
            this.btnLoginContinue.Image = global::ITCRM.Properties.Resources.key;
            this.btnLoginContinue.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoginContinue.Location = new System.Drawing.Point(281, 240);
            this.btnLoginContinue.Margin = new System.Windows.Forms.Padding(0);
            this.btnLoginContinue.Name = "btnLoginContinue";
            this.btnLoginContinue.Size = new System.Drawing.Size(93, 32);
            this.btnLoginContinue.TabIndex = 3;
            this.btnLoginContinue.Text = "&Login";
            this.btnLoginContinue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoginContinue.UseCompatibleTextRendering = true;
            this.btnLoginContinue.UseVisualStyleBackColor = false;
            this.btnLoginContinue.Click += new System.EventHandler(this.btnLoginContinue_Click);
            // 
            // loginPanel
            // 
            this.loginPanel.AutoScroll = true;
            this.loginPanel.BackgroundImage = global::ITCRM.Properties.Resources.BG1;
            this.loginPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.loginPanel.Controls.Add(this.linkLoginAsst);
            this.loginPanel.Controls.Add(this.btnLoginCancel);
            this.loginPanel.Controls.Add(this.btnLoginContinue);
            this.loginPanel.Controls.Add(this.txtITEmpPassKey);
            this.loginPanel.Controls.Add(this.txtITEmpUserName);
            this.loginPanel.Controls.Add(this.label3);
            this.loginPanel.Controls.Add(this.label2);
            this.loginPanel.Controls.Add(this.pictureBox1);
            this.loginPanel.Controls.Add(this.label1);
            this.loginPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loginPanel.Location = new System.Drawing.Point(15, 30);
            this.loginPanel.Name = "loginPanel";
            this.loginPanel.Size = new System.Drawing.Size(550, 370);
            this.loginPanel.TabIndex = 1;
            // 
            // linkLoginAsst
            // 
            this.linkLoginAsst.AutoSize = true;
            this.linkLoginAsst.BackColor = System.Drawing.Color.Transparent;
            this.linkLoginAsst.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLoginAsst.Location = new System.Drawing.Point(376, 298);
            this.linkLoginAsst.Name = "linkLoginAsst";
            this.linkLoginAsst.Size = new System.Drawing.Size(108, 16);
            this.linkLoginAsst.TabIndex = 5;
            this.linkLoginAsst.TabStop = true;
            this.linkLoginAsst.Text = "Login Assistant";
            this.linkLoginAsst.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLoginAsst_LinkClicked);
            // 
            // btnLoginCancel
            // 
            this.btnLoginCancel.BackColor = System.Drawing.Color.White;
            this.btnLoginCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLoginCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoginCancel.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLoginCancel.FlatAppearance.BorderSize = 2;
            this.btnLoginCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnLoginCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnLoginCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoginCancel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginCancel.ForeColor = System.Drawing.Color.Maroon;
            this.btnLoginCancel.Image = global::ITCRM.Properties.Resources.can;
            this.btnLoginCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoginCancel.Location = new System.Drawing.Point(391, 240);
            this.btnLoginCancel.Margin = new System.Windows.Forms.Padding(0);
            this.btnLoginCancel.Name = "btnLoginCancel";
            this.btnLoginCancel.Size = new System.Drawing.Size(93, 32);
            this.btnLoginCancel.TabIndex = 4;
            this.btnLoginCancel.Text = "&Cancel";
            this.btnLoginCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoginCancel.UseVisualStyleBackColor = false;
            this.btnLoginCancel.Click += new System.EventHandler(this.btnLoginCancel_Click);
            // 
            // txtITEmpPassKey
            // 
            this.txtITEmpPassKey.AcceptsTab = true;
            this.txtITEmpPassKey.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.txtITEmpPassKey.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtITEmpPassKey.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtITEmpPassKey.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtITEmpPassKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtITEmpPassKey.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtITEmpPassKey.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtITEmpPassKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtITEmpPassKey.HideSelection = false;
            this.txtITEmpPassKey.Location = new System.Drawing.Point(237, 182);
            this.txtITEmpPassKey.Name = "txtITEmpPassKey";
            this.txtITEmpPassKey.PasswordChar = '*';
            this.txtITEmpPassKey.ShortcutsEnabled = false;
            this.txtITEmpPassKey.Size = new System.Drawing.Size(262, 26);
            this.txtITEmpPassKey.TabIndex = 2;
            this.txtITEmpPassKey.UseSystemPasswordChar = true;
            // 
            // txtITEmpUserName
            // 
            this.txtITEmpUserName.AcceptsTab = true;
            this.txtITEmpUserName.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.txtITEmpUserName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtITEmpUserName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtITEmpUserName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtITEmpUserName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtITEmpUserName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtITEmpUserName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtITEmpUserName.HideSelection = false;
            this.txtITEmpUserName.Location = new System.Drawing.Point(237, 106);
            this.txtITEmpUserName.Name = "txtITEmpUserName";
            this.txtITEmpUserName.ShortcutsEnabled = false;
            this.txtITEmpUserName.Size = new System.Drawing.Size(262, 26);
            this.txtITEmpUserName.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(234, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(234, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Username";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::ITCRM.Properties.Resources.logBG;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(216, 328);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Image = global::ITCRM.Properties.Resources.logo1;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(5, 2, 2, 2);
            this.label1.Size = new System.Drawing.Size(550, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "JVI IT - CRM (Login)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Login
            // 
            this.AcceptButton = this.btnLoginContinue;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(580, 415);
            this.ControlBox = false;
            this.Controls.Add(this.loginPanel);
            this.DisplayHeader = false;
            this.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(580, 415);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(580, 415);
            this.Movable = false;
            this.Name = "Login";
            this.Padding = new System.Windows.Forms.Padding(15, 30, 15, 15);
            this.Resizable = false;
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Login_Load);
            this.loginPanel.ResumeLayout(false);
            this.loginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel loginPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtITEmpPassKey;
        private System.Windows.Forms.TextBox txtITEmpUserName;
        private System.Windows.Forms.Button btnLoginContinue;
        private System.Windows.Forms.Button btnLoginCancel;
        private System.Windows.Forms.LinkLabel linkLoginAsst;
    }
}