﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITCRM
{
    public partial class userCustomReports : MetroFramework.Forms.MetroForm
    {
        public userCustomReports()
        {
            InitializeComponent();
        }

        private void userCustomReports_Load(object sender, EventArgs e)
        {
            //// TODO: This line of code loads data into the 'HCDataSet1.HC_REQ_RESUME' table. You can move, or remove it, as needed.
            this.HC_REQ_RESUMETableAdapter.Fill(this.HCDataSet1.HC_REQ_RESUME);

            this.rpVwr_Sheet.RefreshReport();
        }

        private void btnExitReport_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
