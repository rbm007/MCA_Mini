﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace ITCRM
{
    public partial class AllFeedbacks : Form
    {
        con_properties cnn = new con_properties();
        SqlConnection HCConn = new SqlConnection(Properties.Settings.Default.HCcon.ToString());
        SqlDataAdapter adp;
        DataSet ds;
        DataView dv;


        public AllFeedbacks()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AllFeedbacks_Load(object sender, EventArgs e)
        {
            try
            {
                string selectAllFeedbacks = "Select Top 50 ROW_NUMBER() OVER(ORDER BY RID DESC) AS SrNo, Name as Contact_Name, ContactNo as Contact_Number,"
                    + " EmailID, City, CratedDate as Registered_Date, Complaints from HC_JV_FEEDBACK WITH (NOLOCK) Order By CratedDate DESC;";
                adp = new SqlDataAdapter(selectAllFeedbacks, Properties.Settings.Default.HCcon.ToString());
                ds = new DataSet();
                cnn.con_open();
                adp.Fill(ds, "HC_JV_FEEDBACK");
                adp.Dispose();
                cnn.close_con();

                if (ds.Tables["HC_JV_FEEDBACK"].Rows.Count > 0)
                {
                    dv = new DataView(ds.Tables["HC_JV_FEEDBACK"]);
                    //cm = (CurrencyManager)this.BindingContext[dv, "UserCreationRequest"];
                    //cm = (CurrencyManager)this.BindingContext["UserCreationRequest"];

                    lblCreatedDate.DataBindings.Clear();
                    lblCreatedDate.DataBindings.Add("Text", dv, "Registered_Date");

                    lblSrNo.DataBindings.Clear();
                    lblSrNo.DataBindings.Add("Text", dv, "SrNo");

                    lblCreatedName.DataBindings.Clear();
                    lblCreatedName.DataBindings.Add("Text", dv, "Contact_Name");

                    lblContactNo.DataBindings.Clear();
                    lblContactNo.DataBindings.Add("Text", dv, "Contact_Number");

                    lblEmailID.DataBindings.Clear();
                    lblEmailID.DataBindings.Add("Text", dv, "EmailID");

                    lblCity.DataBindings.Clear();
                    lblCity.DataBindings.Add("Text", dv, "City");

                    txtComments.DataBindings.Clear();
                    txtComments.DataBindings.Add("Text", dv, "Complaints");

                    fbGridView.Show();
                    fbGridView.DataSource = dv;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnFindTktDetails_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtSearchFb.Text == "")
                {
                    MessageBox.Show("Enter Value to Filter Data");
                }

                else
                {
                    string selectAllFeedbacks = "Select ROW_NUMBER() OVER(ORDER BY RID DESC) AS SrNo, Name as Contact_Name, ContactNo as Contact_Number,"
                        + " EmailID, City, CratedDate as Registered_Date, Complaints from HC_JV_FEEDBACK WITH (NOLOCK) WHERE Name like @SearchMe Or "
                        + " EmailID like @SearchMe Or ContactNo like @SearchMe Order By CratedDate DESC;";
                    adp = new SqlDataAdapter(selectAllFeedbacks, Properties.Settings.Default.HCcon.ToString());
                    adp.SelectCommand.Parameters.AddWithValue("@SearchMe", '%' + txtSearchFb.Text.Trim().ToString() + '%');

                    ds = new DataSet();
                    cnn.con_open();
                    adp.Fill(ds, "HC_JV_FEEDBACK");
                    adp.Dispose();
                    cnn.close_con();

                    if (ds.Tables["HC_JV_FEEDBACK"].Rows.Count > 0)
                    {
                        dv = new DataView(ds.Tables["HC_JV_FEEDBACK"]);
                        //cm = (CurrencyManager)this.BindingContext[dv, "UserCreationRequest"];
                        //cm = (CurrencyManager)this.BindingContext["UserCreationRequest"];

                        lblCreatedDate.DataBindings.Clear();
                        lblCreatedDate.DataBindings.Add("Text", dv, "Registered_Date");

                        lblSrNo.DataBindings.Clear();
                        lblSrNo.DataBindings.Add("Text", dv, "SrNo");

                        lblCreatedName.DataBindings.Clear();
                        lblCreatedName.DataBindings.Add("Text", dv, "Contact_Name");

                        lblContactNo.DataBindings.Clear();
                        lblContactNo.DataBindings.Add("Text", dv, "Contact_Number");

                        lblEmailID.DataBindings.Clear();
                        lblEmailID.DataBindings.Add("Text", dv, "EmailID");

                        lblCity.DataBindings.Clear();
                        lblCity.DataBindings.Add("Text", dv, "City");

                        txtComments.DataBindings.Clear();
                        txtComments.DataBindings.Add("Text", dv, "Complaints");

                        fbGridView.Show();
                        fbGridView.DataSource = dv;

                        lblCount.Text = "Selected " + fbGridView.SelectedRows.Count + " Of Total " + fbGridView.RowCount.ToString();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void tmr_Tick(object sender, EventArgs e)
        {

            lblCurrentTime.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy HH:mm:ss tt");

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {

        }

        private void btPre_Click(object sender, EventArgs e)
        {
            if (this.BindingContext[fbGridView].Position > 0)
            {
                this.BindingContext[fbGridView].Position--;
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            CurrencyManager cm = (CurrencyManager)this.BindingContext[ds, "HC_JV_FEEDBACK"];
            if (cm.Position < cm.Count - 1)
            {
                cm.Position++;
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {

        }
    }
}
