﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Globalization;
using System.Net;
using System.Net.Mail;

/// <summary>
/// Summary description for myCon
/// </summary>
public partial class con_properties
{
    SqlConnection con = new SqlConnection(ITCRM.Properties.Settings.Default.con.ToString());

    public void con_open()
    {

        try
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        catch (Exception ex) { ex.ToString(); }
    }

    //public void ConStr()
    //{
    //    using (SqlConnection conn = new SqlConnection())
    //    {
    //        conn.ConnectionString = (ConfigurationManager.ConnectionStrings["JVIITString"].ToString());
    //        // using the code here...
    //    }
    //}

    public void getCon()
    {

        string connection = con.ToString();

    }

    public void close_con()
    {
        try
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        catch (Exception ex) { ex.ToString(); }
    }
}