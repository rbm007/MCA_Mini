﻿namespace ITCRM
{
    partial class frmDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ToolTip ttInfo;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashBoard));
            this.lblEmpFullNameOfEmp = new System.Windows.Forms.Label();
            this.lblMinimize = new System.Windows.Forms.Label();
            this.lblLogout = new System.Windows.Forms.Label();
            this.lblHelp = new System.Windows.Forms.Label();
            this.rdBtnUserCreation = new System.Windows.Forms.RadioButton();
            this.rdBtnGreviences = new System.Windows.Forms.RadioButton();
            this.rdBtnTraining = new System.Windows.Forms.RadioButton();
            this.rdUserFeedbacks = new System.Windows.Forms.RadioButton();
            this.rdBtnStaffContacts = new System.Windows.Forms.RadioButton();
            this.lblUserInfo = new System.Windows.Forms.Label();
            this.lblReport = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnFindTktDetails = new System.Windows.Forms.Button();
            this.txtSearchInputs = new System.Windows.Forms.TextBox();
            this.lblIndicator = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tktInfoPanel = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCancelUpdate = new System.Windows.Forms.Button();
            this.btnUpdateTicket = new System.Windows.Forms.Button();
            this.lblTicketDescription = new System.Windows.Forms.RichTextBox();
            this.lblTktLastUpdateDetails = new System.Windows.Forms.Label();
            this.lblTktUserEmail = new System.Windows.Forms.Label();
            this.lblTicketJVIEmpName = new System.Windows.Forms.Label();
            this.lblTicketTitle = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.lblUpdateID = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblTktUserMobile = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblTktCurrentStatus = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbTicketStatus = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblTktUserLocation = new System.Windows.Forms.Label();
            this.lblTktCreatedUsername = new System.Windows.Forms.Label();
            this.lblTicketCreatedDate = new System.Windows.Forms.Label();
            this.lblTktRefNo = new System.Windows.Forms.Label();
            this.lblIndicatorLocation = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblUpdatePanelText = new System.Windows.Forms.Label();
            this.dtGridListAll = new MetroFramework.Controls.MetroGrid();
            this.label20 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblRequesterEmailID = new System.Windows.Forms.Label();
            this.lblFeedsFromUsers = new System.Windows.Forms.Label();
            ttInfo = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tktInfoPanel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGridListAll)).BeginInit();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // ttInfo
            // 
            ttInfo.BackColor = System.Drawing.Color.White;
            ttInfo.ForeColor = System.Drawing.SystemColors.Desktop;
            // 
            // lblEmpFullNameOfEmp
            // 
            this.lblEmpFullNameOfEmp.BackColor = System.Drawing.Color.White;
            this.lblEmpFullNameOfEmp.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblEmpFullNameOfEmp.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpFullNameOfEmp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblEmpFullNameOfEmp.Location = new System.Drawing.Point(0, 6);
            this.lblEmpFullNameOfEmp.Name = "lblEmpFullNameOfEmp";
            this.lblEmpFullNameOfEmp.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.lblEmpFullNameOfEmp.Size = new System.Drawing.Size(325, 27);
            this.lblEmpFullNameOfEmp.TabIndex = 6;
            this.lblEmpFullNameOfEmp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            ttInfo.SetToolTip(this.lblEmpFullNameOfEmp, "Logged in Username");
            // 
            // lblMinimize
            // 
            this.lblMinimize.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblMinimize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMinimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblMinimize.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinimize.ForeColor = System.Drawing.Color.White;
            this.lblMinimize.Location = new System.Drawing.Point(877, 6);
            this.lblMinimize.Name = "lblMinimize";
            this.lblMinimize.Size = new System.Drawing.Size(88, 27);
            this.lblMinimize.TabIndex = 7;
            this.lblMinimize.Text = "&Minimize";
            this.lblMinimize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            ttInfo.SetToolTip(this.lblMinimize, "Click to Minimize");
            this.lblMinimize.Click += new System.EventHandler(this.lblMinimize_Click);
            // 
            // lblLogout
            // 
            this.lblLogout.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblLogout.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogout.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblLogout.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogout.ForeColor = System.Drawing.Color.White;
            this.lblLogout.Location = new System.Drawing.Point(789, 6);
            this.lblLogout.Name = "lblLogout";
            this.lblLogout.Size = new System.Drawing.Size(88, 27);
            this.lblLogout.TabIndex = 9;
            this.lblLogout.Text = "&Logout";
            this.lblLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            ttInfo.SetToolTip(this.lblLogout, "Click to Logout/Close");
            this.lblLogout.Click += new System.EventHandler(this.lblLogout_Click);
            // 
            // lblHelp
            // 
            this.lblHelp.AutoEllipsis = true;
            this.lblHelp.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblHelp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHelp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblHelp.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblHelp.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelp.ForeColor = System.Drawing.Color.White;
            this.lblHelp.Location = new System.Drawing.Point(965, 6);
            this.lblHelp.Name = "lblHelp";
            this.lblHelp.Size = new System.Drawing.Size(88, 27);
            this.lblHelp.TabIndex = 3;
            this.lblHelp.Text = "&Help";
            this.lblHelp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            ttInfo.SetToolTip(this.lblHelp, "Click for Small Tutorial");
            this.lblHelp.Click += new System.EventHandler(this.lblHelp_Click);
            // 
            // rdBtnUserCreation
            // 
            this.rdBtnUserCreation.BackgroundImage = global::ITCRM.Properties.Resources.UReq;
            this.rdBtnUserCreation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.rdBtnUserCreation.Checked = true;
            this.rdBtnUserCreation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdBtnUserCreation.Dock = System.Windows.Forms.DockStyle.Right;
            this.rdBtnUserCreation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdBtnUserCreation.Location = new System.Drawing.Point(51, 0);
            this.rdBtnUserCreation.Name = "rdBtnUserCreation";
            this.rdBtnUserCreation.Size = new System.Drawing.Size(119, 100);
            this.rdBtnUserCreation.TabIndex = 21;
            this.rdBtnUserCreation.TabStop = true;
            ttInfo.SetToolTip(this.rdBtnUserCreation, "User Creation Requests");
            this.rdBtnUserCreation.UseVisualStyleBackColor = true;
            // 
            // rdBtnGreviences
            // 
            this.rdBtnGreviences.BackgroundImage = global::ITCRM.Properties.Resources.greviences;
            this.rdBtnGreviences.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.rdBtnGreviences.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdBtnGreviences.Dock = System.Windows.Forms.DockStyle.Right;
            this.rdBtnGreviences.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdBtnGreviences.Location = new System.Drawing.Point(251, 0);
            this.rdBtnGreviences.Name = "rdBtnGreviences";
            this.rdBtnGreviences.Size = new System.Drawing.Size(119, 100);
            this.rdBtnGreviences.TabIndex = 22;
            this.rdBtnGreviences.TabStop = true;
            this.rdBtnGreviences.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            ttInfo.SetToolTip(this.rdBtnGreviences, "User Support Grievances");
            this.rdBtnGreviences.UseVisualStyleBackColor = true;
            // 
            // rdBtnTraining
            // 
            this.rdBtnTraining.BackgroundImage = global::ITCRM.Properties.Resources.ICEF_icon_contact1;
            this.rdBtnTraining.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.rdBtnTraining.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdBtnTraining.Dock = System.Windows.Forms.DockStyle.Right;
            this.rdBtnTraining.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.rdBtnTraining.Location = new System.Drawing.Point(451, 0);
            this.rdBtnTraining.Name = "rdBtnTraining";
            this.rdBtnTraining.Size = new System.Drawing.Size(119, 100);
            this.rdBtnTraining.TabIndex = 23;
            this.rdBtnTraining.TabStop = true;
            ttInfo.SetToolTip(this.rdBtnTraining, "User Training Requests");
            this.rdBtnTraining.UseVisualStyleBackColor = true;
            // 
            // rdUserFeedbacks
            // 
            this.rdUserFeedbacks.BackgroundImage = global::ITCRM.Properties.Resources.feedback1;
            this.rdUserFeedbacks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.rdUserFeedbacks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdUserFeedbacks.Dock = System.Windows.Forms.DockStyle.Right;
            this.rdUserFeedbacks.Location = new System.Drawing.Point(651, 0);
            this.rdUserFeedbacks.Name = "rdUserFeedbacks";
            this.rdUserFeedbacks.Size = new System.Drawing.Size(131, 100);
            this.rdUserFeedbacks.TabIndex = 24;
            this.rdUserFeedbacks.TabStop = true;
            ttInfo.SetToolTip(this.rdUserFeedbacks, "Users Feedbacks");
            this.rdUserFeedbacks.UseVisualStyleBackColor = true;
            // 
            // rdBtnStaffContacts
            // 
            this.rdBtnStaffContacts.BackgroundImage = global::ITCRM.Properties.Resources.con_file;
            this.rdBtnStaffContacts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.rdBtnStaffContacts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rdBtnStaffContacts.Dock = System.Windows.Forms.DockStyle.Right;
            this.rdBtnStaffContacts.Location = new System.Drawing.Point(863, 0);
            this.rdBtnStaffContacts.Name = "rdBtnStaffContacts";
            this.rdBtnStaffContacts.Size = new System.Drawing.Size(119, 100);
            this.rdBtnStaffContacts.TabIndex = 25;
            this.rdBtnStaffContacts.TabStop = true;
            ttInfo.SetToolTip(this.rdBtnStaffContacts, "List of Staff Directory");
            this.rdBtnStaffContacts.UseVisualStyleBackColor = true;
            // 
            // lblUserInfo
            // 
            this.lblUserInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblUserInfo.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserInfo.ForeColor = System.Drawing.Color.Black;
            this.lblUserInfo.Location = new System.Drawing.Point(0, 6);
            this.lblUserInfo.Name = "lblUserInfo";
            this.lblUserInfo.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.lblUserInfo.Size = new System.Drawing.Size(181, 27);
            this.lblUserInfo.TabIndex = 0;
            this.lblUserInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            ttInfo.SetToolTip(this.lblUserInfo, "Logged in Username");
            // 
            // lblReport
            // 
            this.lblReport.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblReport.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblReport.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReport.ForeColor = System.Drawing.Color.White;
            this.lblReport.Location = new System.Drawing.Point(701, 6);
            this.lblReport.Name = "lblReport";
            this.lblReport.Size = new System.Drawing.Size(88, 27);
            this.lblReport.TabIndex = 10;
            this.lblReport.Text = "&Reports";
            this.lblReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            ttInfo.SetToolTip(this.lblReport, "Click to Generate Report");
            this.lblReport.Click += new System.EventHandler(this.lblReport_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lblFeedsFromUsers);
            this.panel1.Controls.Add(this.lblReport);
            this.panel1.Controls.Add(this.lblLogout);
            this.panel1.Controls.Add(this.lblEmpFullNameOfEmp);
            this.panel1.Controls.Add(this.lblUserInfo);
            this.panel1.Controls.Add(this.lblMinimize);
            this.panel1.Controls.Add(this.lblHelp);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(17, 165);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1053, 33);
            this.panel1.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1053, 6);
            this.panel7.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnFindTktDetails);
            this.panel2.Controls.Add(this.txtSearchInputs);
            this.panel2.Controls.Add(this.lblIndicator);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(17, 204);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1053, 66);
            this.panel2.TabIndex = 3;
            // 
            // btnFindTktDetails
            // 
            this.btnFindTktDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnFindTktDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFindTktDetails.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnFindTktDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btnFindTktDetails.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnFindTktDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFindTktDetails.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindTktDetails.ForeColor = System.Drawing.Color.White;
            this.btnFindTktDetails.Location = new System.Drawing.Point(681, 13);
            this.btnFindTktDetails.Name = "btnFindTktDetails";
            this.btnFindTktDetails.Size = new System.Drawing.Size(97, 39);
            this.btnFindTktDetails.TabIndex = 2;
            this.btnFindTktDetails.Text = "C&ontinue";
            this.btnFindTktDetails.UseVisualStyleBackColor = true;
            this.btnFindTktDetails.Click += new System.EventHandler(this.btnFindTktDetails_Click);
            // 
            // txtSearchInputs
            // 
            this.txtSearchInputs.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchInputs.Location = new System.Drawing.Point(351, 19);
            this.txtSearchInputs.Name = "txtSearchInputs";
            this.txtSearchInputs.Size = new System.Drawing.Size(262, 26);
            this.txtSearchInputs.TabIndex = 1;
            // 
            // lblIndicator
            // 
            this.lblIndicator.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblIndicator.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicator.Location = new System.Drawing.Point(0, 0);
            this.lblIndicator.Name = "lblIndicator";
            this.lblIndicator.Size = new System.Drawing.Size(311, 66);
            this.lblIndicator.TabIndex = 0;
            this.lblIndicator.Text = "Enter The Ticket Number : ";
            this.lblIndicator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(17, 198);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1053, 6);
            this.panel3.TabIndex = 4;
            // 
            // tktInfoPanel
            // 
            this.tktInfoPanel.Controls.Add(this.panel4);
            this.tktInfoPanel.Controls.Add(this.panel5);
            this.tktInfoPanel.Controls.Add(this.lblUpdatePanelText);
            this.tktInfoPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tktInfoPanel.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tktInfoPanel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.tktInfoPanel.Location = new System.Drawing.Point(17, 378);
            this.tktInfoPanel.Name = "tktInfoPanel";
            this.tktInfoPanel.Size = new System.Drawing.Size(1053, 354);
            this.tktInfoPanel.TabIndex = 6;
            this.tktInfoPanel.TabStop = false;
            this.tktInfoPanel.Text = "Complete Ticket Information";
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.btnCancelUpdate);
            this.panel4.Controls.Add(this.btnUpdateTicket);
            this.panel4.Controls.Add(this.lblTicketDescription);
            this.panel4.Controls.Add(this.lblTktLastUpdateDetails);
            this.panel4.Controls.Add(this.lblTktUserEmail);
            this.panel4.Controls.Add(this.lblTicketJVIEmpName);
            this.panel4.Controls.Add(this.lblTicketTitle);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(593, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(457, 301);
            this.panel4.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 366);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(499, 18);
            this.label1.TabIndex = 33;
            // 
            // btnCancelUpdate
            // 
            this.btnCancelUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnCancelUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelUpdate.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCancelUpdate.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnCancelUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCancelUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCancelUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelUpdate.ForeColor = System.Drawing.Color.White;
            this.btnCancelUpdate.Location = new System.Drawing.Point(357, 327);
            this.btnCancelUpdate.Name = "btnCancelUpdate";
            this.btnCancelUpdate.Size = new System.Drawing.Size(99, 39);
            this.btnCancelUpdate.TabIndex = 32;
            this.btnCancelUpdate.Text = "&Cancel";
            this.btnCancelUpdate.UseVisualStyleBackColor = false;
            this.btnCancelUpdate.Click += new System.EventHandler(this.btnCancelUpdate_Click);
            // 
            // btnUpdateTicket
            // 
            this.btnUpdateTicket.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnUpdateTicket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateTicket.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnUpdateTicket.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnUpdateTicket.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.HotTrack;
            this.btnUpdateTicket.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Highlight;
            this.btnUpdateTicket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateTicket.ForeColor = System.Drawing.Color.White;
            this.btnUpdateTicket.Location = new System.Drawing.Point(252, 327);
            this.btnUpdateTicket.Name = "btnUpdateTicket";
            this.btnUpdateTicket.Size = new System.Drawing.Size(99, 39);
            this.btnUpdateTicket.TabIndex = 31;
            this.btnUpdateTicket.Text = "&Update";
            this.btnUpdateTicket.UseVisualStyleBackColor = false;
            this.btnUpdateTicket.Click += new System.EventHandler(this.btnUpdateTicket_Click);
            // 
            // lblTicketDescription
            // 
            this.lblTicketDescription.Location = new System.Drawing.Point(164, 176);
            this.lblTicketDescription.Name = "lblTicketDescription";
            this.lblTicketDescription.Size = new System.Drawing.Size(335, 144);
            this.lblTicketDescription.TabIndex = 30;
            this.lblTicketDescription.Text = "";
            // 
            // lblTktLastUpdateDetails
            // 
            this.lblTktLastUpdateDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktLastUpdateDetails.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktLastUpdateDetails.ForeColor = System.Drawing.Color.Red;
            this.lblTktLastUpdateDetails.Location = new System.Drawing.Point(159, 133);
            this.lblTktLastUpdateDetails.Name = "lblTktLastUpdateDetails";
            this.lblTktLastUpdateDetails.Size = new System.Drawing.Size(339, 32);
            this.lblTktLastUpdateDetails.TabIndex = 29;
            this.lblTktLastUpdateDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTktUserEmail
            // 
            this.lblTktUserEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktUserEmail.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktUserEmail.ForeColor = System.Drawing.Color.Red;
            this.lblTktUserEmail.Location = new System.Drawing.Point(159, 96);
            this.lblTktUserEmail.Name = "lblTktUserEmail";
            this.lblTktUserEmail.Size = new System.Drawing.Size(339, 32);
            this.lblTktUserEmail.TabIndex = 28;
            this.lblTktUserEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTicketJVIEmpName
            // 
            this.lblTicketJVIEmpName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTicketJVIEmpName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicketJVIEmpName.ForeColor = System.Drawing.Color.Red;
            this.lblTicketJVIEmpName.Location = new System.Drawing.Point(159, 60);
            this.lblTicketJVIEmpName.Name = "lblTicketJVIEmpName";
            this.lblTicketJVIEmpName.Size = new System.Drawing.Size(339, 32);
            this.lblTicketJVIEmpName.TabIndex = 27;
            this.lblTicketJVIEmpName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTicketTitle
            // 
            this.lblTicketTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTicketTitle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicketTitle.ForeColor = System.Drawing.Color.Red;
            this.lblTicketTitle.Location = new System.Drawing.Point(159, 23);
            this.lblTicketTitle.Name = "lblTicketTitle";
            this.lblTicketTitle.Size = new System.Drawing.Size(339, 32);
            this.lblTicketTitle.TabIndex = 26;
            this.lblTicketTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(26, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 32);
            this.label2.TabIndex = 25;
            this.label2.Text = "Ticket Comments :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Navy;
            this.label14.Location = new System.Drawing.Point(26, 133);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 32);
            this.label14.TabIndex = 24;
            this.label14.Text = "Last Update :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Navy;
            this.label15.Location = new System.Drawing.Point(26, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(129, 32);
            this.label15.TabIndex = 21;
            this.label15.Text = "Ticket Title :";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Navy;
            this.label16.Location = new System.Drawing.Point(26, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(129, 32);
            this.label16.TabIndex = 22;
            this.label16.Text = "New Joining Name :";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Navy;
            this.label17.Location = new System.Drawing.Point(26, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(129, 32);
            this.label17.TabIndex = 23;
            this.label17.Text = "Requester Email :";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.lblUpdateID);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.lblTktUserMobile);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Controls.Add(this.lblTktCurrentStatus);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.cmbTicketStatus);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.lblTktUserLocation);
            this.panel5.Controls.Add(this.lblTktCreatedUsername);
            this.panel5.Controls.Add(this.lblTicketCreatedDate);
            this.panel5.Controls.Add(this.lblTktRefNo);
            this.panel5.Controls.Add(this.lblIndicatorLocation);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(3, 50);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(590, 301);
            this.panel5.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label22.Location = new System.Drawing.Point(0, 323);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(573, 14);
            this.label22.TabIndex = 32;
            // 
            // lblUpdateID
            // 
            this.lblUpdateID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblUpdateID.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateID.ForeColor = System.Drawing.Color.Red;
            this.lblUpdateID.Location = new System.Drawing.Point(158, 22);
            this.lblUpdateID.Name = "lblUpdateID";
            this.lblUpdateID.Size = new System.Drawing.Size(339, 32);
            this.lblUpdateID.TabIndex = 31;
            this.lblUpdateID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Navy;
            this.label18.Location = new System.Drawing.Point(24, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(129, 32);
            this.label18.TabIndex = 30;
            this.label18.Text = "Update ID :";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTktUserMobile
            // 
            this.lblTktUserMobile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktUserMobile.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktUserMobile.ForeColor = System.Drawing.Color.Red;
            this.lblTktUserMobile.Location = new System.Drawing.Point(158, 254);
            this.lblTktUserMobile.Name = "lblTktUserMobile";
            this.lblTktUserMobile.Size = new System.Drawing.Size(339, 32);
            this.lblTktUserMobile.TabIndex = 29;
            this.lblTktUserMobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Navy;
            this.label19.Location = new System.Drawing.Point(24, 254);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(129, 32);
            this.label19.TabIndex = 28;
            this.label19.Text = "User Mobile :";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTktCurrentStatus
            // 
            this.lblTktCurrentStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktCurrentStatus.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktCurrentStatus.ForeColor = System.Drawing.Color.Red;
            this.lblTktCurrentStatus.Location = new System.Drawing.Point(158, 174);
            this.lblTktCurrentStatus.Name = "lblTktCurrentStatus";
            this.lblTktCurrentStatus.Size = new System.Drawing.Size(339, 32);
            this.lblTktCurrentStatus.TabIndex = 27;
            this.lblTktCurrentStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Navy;
            this.label24.Location = new System.Drawing.Point(24, 174);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(129, 32);
            this.label24.TabIndex = 26;
            this.label24.Text = "Current Status :";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbTicketStatus
            // 
            this.cmbTicketStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTicketStatus.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTicketStatus.FormattingEnabled = true;
            this.cmbTicketStatus.Items.AddRange(new object[] {
            "Pending",
            "InProcess",
            "OnHold",
            "Closed"});
            this.cmbTicketStatus.Location = new System.Drawing.Point(159, 295);
            this.cmbTicketStatus.Name = "cmbTicketStatus";
            this.cmbTicketStatus.Size = new System.Drawing.Size(338, 24);
            this.cmbTicketStatus.TabIndex = 25;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Navy;
            this.label21.Location = new System.Drawing.Point(24, 291);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(129, 32);
            this.label21.TabIndex = 24;
            this.label21.Text = "Update Status As :";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTktUserLocation
            // 
            this.lblTktUserLocation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktUserLocation.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktUserLocation.ForeColor = System.Drawing.Color.Red;
            this.lblTktUserLocation.Location = new System.Drawing.Point(158, 214);
            this.lblTktUserLocation.Name = "lblTktUserLocation";
            this.lblTktUserLocation.Size = new System.Drawing.Size(339, 32);
            this.lblTktUserLocation.TabIndex = 23;
            this.lblTktUserLocation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTktCreatedUsername
            // 
            this.lblTktCreatedUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktCreatedUsername.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktCreatedUsername.ForeColor = System.Drawing.Color.Red;
            this.lblTktCreatedUsername.Location = new System.Drawing.Point(158, 135);
            this.lblTktCreatedUsername.Name = "lblTktCreatedUsername";
            this.lblTktCreatedUsername.Size = new System.Drawing.Size(339, 32);
            this.lblTktCreatedUsername.TabIndex = 22;
            this.lblTktCreatedUsername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTicketCreatedDate
            // 
            this.lblTicketCreatedDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTicketCreatedDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicketCreatedDate.ForeColor = System.Drawing.Color.Red;
            this.lblTicketCreatedDate.Location = new System.Drawing.Point(158, 98);
            this.lblTicketCreatedDate.Name = "lblTicketCreatedDate";
            this.lblTicketCreatedDate.Size = new System.Drawing.Size(339, 32);
            this.lblTicketCreatedDate.TabIndex = 21;
            this.lblTicketCreatedDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTktRefNo
            // 
            this.lblTktRefNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTktRefNo.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTktRefNo.ForeColor = System.Drawing.Color.Red;
            this.lblTktRefNo.Location = new System.Drawing.Point(158, 61);
            this.lblTktRefNo.Name = "lblTktRefNo";
            this.lblTktRefNo.Size = new System.Drawing.Size(339, 32);
            this.lblTktRefNo.TabIndex = 20;
            this.lblTktRefNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIndicatorLocation
            // 
            this.lblIndicatorLocation.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorLocation.ForeColor = System.Drawing.Color.Navy;
            this.lblIndicatorLocation.Location = new System.Drawing.Point(24, 214);
            this.lblIndicatorLocation.Name = "lblIndicatorLocation";
            this.lblIndicatorLocation.Size = new System.Drawing.Size(129, 32);
            this.lblIndicatorLocation.TabIndex = 19;
            this.lblIndicatorLocation.Text = "User Location :";
            this.lblIndicatorLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(24, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 32);
            this.label9.TabIndex = 16;
            this.label9.Text = "Reference Number :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Navy;
            this.label10.Location = new System.Drawing.Point(24, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(129, 32);
            this.label10.TabIndex = 17;
            this.label10.Text = "Created Date :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Navy;
            this.label12.Location = new System.Drawing.Point(24, 135);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 32);
            this.label12.TabIndex = 18;
            this.label12.Text = "Requester Username :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUpdatePanelText
            // 
            this.lblUpdatePanelText.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblUpdatePanelText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUpdatePanelText.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblUpdatePanelText.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdatePanelText.ForeColor = System.Drawing.Color.Navy;
            this.lblUpdatePanelText.Location = new System.Drawing.Point(3, 18);
            this.lblUpdatePanelText.Name = "lblUpdatePanelText";
            this.lblUpdatePanelText.Size = new System.Drawing.Size(1047, 32);
            this.lblUpdatePanelText.TabIndex = 4;
            this.lblUpdatePanelText.Text = "Ticket Details Box";
            this.lblUpdatePanelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtGridListAll
            // 
            this.dtGridListAll.AllowUserToAddRows = false;
            this.dtGridListAll.AllowUserToDeleteRows = false;
            this.dtGridListAll.AllowUserToResizeColumns = false;
            this.dtGridListAll.AllowUserToResizeRows = false;
            this.dtGridListAll.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtGridListAll.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dtGridListAll.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtGridListAll.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dtGridListAll.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGridListAll.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtGridListAll.ColumnHeadersHeight = 30;
            this.dtGridListAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtGridListAll.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtGridListAll.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtGridListAll.Dock = System.Windows.Forms.DockStyle.Top;
            this.dtGridListAll.EnableHeadersVisualStyles = false;
            this.dtGridListAll.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dtGridListAll.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dtGridListAll.HighLightPercentage = 0.4F;
            this.dtGridListAll.Location = new System.Drawing.Point(17, 270);
            this.dtGridListAll.MultiSelect = false;
            this.dtGridListAll.Name = "dtGridListAll";
            this.dtGridListAll.ReadOnly = true;
            this.dtGridListAll.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGridListAll.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtGridListAll.RowHeadersVisible = false;
            this.dtGridListAll.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dtGridListAll.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGridListAll.ShowCellErrors = false;
            this.dtGridListAll.ShowCellToolTips = false;
            this.dtGridListAll.ShowRowErrors = false;
            this.dtGridListAll.Size = new System.Drawing.Size(1053, 108);
            this.dtGridListAll.TabIndex = 8;
            this.dtGridListAll.UseCustomBackColor = true;
            this.dtGridListAll.UseCustomForeColor = true;
            this.dtGridListAll.UseStyleColors = true;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label20.Location = new System.Drawing.Point(17, 732);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1053, 24);
            this.label20.TabIndex = 9;
            this.label20.Text = "Jerry Varghese International. CRM for JV-IT Users";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.rdBtnUserCreation);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.rdBtnGreviences);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.rdBtnTraining);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.rdUserFeedbacks);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.rdBtnStaffContacts);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(17, 65);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1053, 100);
            this.panel6.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 100);
            this.label8.TabIndex = 31;
            this.label8.Text = "User Creation Request";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Location = new System.Drawing.Point(170, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 100);
            this.label3.TabIndex = 30;
            this.label3.Text = "User Grievance";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Right;
            this.label4.Location = new System.Drawing.Point(370, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 100);
            this.label4.TabIndex = 26;
            this.label4.Text = "Training Request";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Location = new System.Drawing.Point(570, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 100);
            this.label5.TabIndex = 27;
            this.label5.Text = "User Feedbacks";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Dock = System.Windows.Forms.DockStyle.Right;
            this.label7.Location = new System.Drawing.Point(782, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 100);
            this.label7.TabIndex = 28;
            this.label7.Text = "Staff Contacts";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Location = new System.Drawing.Point(982, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 100);
            this.label6.TabIndex = 29;
            // 
            // lblRequesterEmailID
            // 
            this.lblRequesterEmailID.AutoSize = true;
            this.lblRequesterEmailID.Location = new System.Drawing.Point(305, 17);
            this.lblRequesterEmailID.Name = "lblRequesterEmailID";
            this.lblRequesterEmailID.Size = new System.Drawing.Size(0, 14);
            this.lblRequesterEmailID.TabIndex = 11;
            // 
            // lblFeedsFromUsers
            // 
            this.lblFeedsFromUsers.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblFeedsFromUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFeedsFromUsers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblFeedsFromUsers.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblFeedsFromUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblFeedsFromUsers.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeedsFromUsers.ForeColor = System.Drawing.Color.White;
            this.lblFeedsFromUsers.Location = new System.Drawing.Point(613, 6);
            this.lblFeedsFromUsers.Name = "lblFeedsFromUsers";
            this.lblFeedsFromUsers.Size = new System.Drawing.Size(88, 27);
            this.lblFeedsFromUsers.TabIndex = 11;
            this.lblFeedsFromUsers.Text = "&Feedbacks";
            this.lblFeedsFromUsers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            ttInfo.SetToolTip(this.lblFeedsFromUsers, "Click to Show Feedbacks");
            // 
            // frmDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1087, 778);
            this.ControlBox = false;
            this.Controls.Add(this.lblRequesterEmailID);
            this.Controls.Add(this.tktInfoPanel);
            this.Controls.Add(this.dtGridListAll);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.panel6);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Movable = false;
            this.Name = "frmDashBoard";
            this.Padding = new System.Windows.Forms.Padding(17, 65, 17, 22);
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.SystemShadow;
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmDashBoard_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tktInfoPanel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGridListAll)).EndInit();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblIndicator;
        private System.Windows.Forms.TextBox txtSearchInputs;
        private System.Windows.Forms.Button btnFindTktDetails;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox tktInfoPanel;
        private MetroFramework.Controls.MetroGrid dtGridListAll;
        private System.Windows.Forms.Label lblUpdatePanelText;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCancelUpdate;
        private System.Windows.Forms.Button btnUpdateTicket;
        private System.Windows.Forms.RichTextBox lblTicketDescription;
        private System.Windows.Forms.Label lblTktLastUpdateDetails;
        private System.Windows.Forms.Label lblTktUserEmail;
        private System.Windows.Forms.Label lblTicketJVIEmpName;
        private System.Windows.Forms.Label lblTicketTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblUpdateID;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblTktUserMobile;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblTktCurrentStatus;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbTicketStatus;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblTktUserLocation;
        private System.Windows.Forms.Label lblTktCreatedUsername;
        private System.Windows.Forms.Label lblTicketCreatedDate;
        private System.Windows.Forms.Label lblTktRefNo;
        private System.Windows.Forms.Label lblIndicatorLocation;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rdBtnUserCreation;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdBtnGreviences;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdBtnTraining;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rdUserFeedbacks;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rdBtnStaffContacts;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblHelp;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblEmpFullNameOfEmp;
        private System.Windows.Forms.Label lblRequesterEmailID;
        private System.Windows.Forms.Label lblMinimize;
        private System.Windows.Forms.Label lblLogout;
        private System.Windows.Forms.Label lblUserInfo;
        private System.Windows.Forms.Label lblReport;
        private System.Windows.Forms.Label lblFeedsFromUsers;
    }
}

