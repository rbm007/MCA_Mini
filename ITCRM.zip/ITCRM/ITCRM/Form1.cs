﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Globalization;
using System.Net;
using System.Net.Mail;

namespace ITCRM
{
    public partial class frmDashBoard : MetroFramework.Forms.MetroForm
    {
        con_properties cnn = new con_properties();
        SqlConnection HCConn = new SqlConnection(Properties.Settings.Default.HCcon.ToString());
        SqlDataAdapter adp;
        DataSet ds;
        DataView dv;
        

        ITCRM.Login.GetUserValue s;
        public string nameOfUser;
        public string fullNameOfUser;

        public frmDashBoard(Login.GetUserValue s1)
        {
            InitializeComponent();
            s = s1;
        }
        public frmDashBoard()
        {
            InitializeComponent();
        }
        private void frmDashBoard_Load(object sender, EventArgs e)
        {
            lblRequesterEmailID.Visible = false;
            rdBtnUserCreation.Checked = true;
            dtGridListAll.DataSource = null;
            tktInfoPanel.Hide();
            txtSearchInputs.Text = "";
            txtSearchInputs.Focus();
            dtGridListAll.Hide();
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.WindowState = FormWindowState.Maximized;
            nameOfUser = s.userLoginName;
            fullNameOfUser = s.userFullNm;

            lblEmpFullNameOfEmp.Text = "Logged In: " + s.userLoginName.ToString()  + " (" + s.userFullNm.ToString() + ")";
            lblUserInfo.Text = s.userLoginName.ToString();

        }
       private void btnFindTktDetails_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtSearchInputs.Text == "")
                {
                    MessageBox.Show("Please Enter Ticket Number to Continue......", "Ticket Number Empty", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
                else
                {
                    if (rdBtnUserCreation.Checked == true)
                    {
                        searchUserCreationReqs();
                    }
                    else if (rdBtnGreviences.Checked == true)
                    {
                        searchUserGrevance();
                    }
                    else if (rdBtnTraining.Checked == true)
                    {
                        searchTrainingRequest();
                    }
                    else if (rdUserFeedbacks.Checked == true)
                    {
                        searchFeedbacks();
                    }
                    else if (rdBtnStaffContacts.Checked == true)
                    {
                        lblIndicator.Text = "Enter Username or Employee Name : ";
                        showAllContacts();
                    }
                    else
                    {
                        lblIndicator.Text = "Enter The Ticket Number : ";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                frmDashBoard_Load(null, null);
            }
        }
        
        //Show All User Creation Request
        protected void searchUserCreationReqs()
        {
            try
            {
                string selectUserCreationRequest = "Select ROW_NUMBER() OVER(ORDER BY UCRRefNo ASC) AS SrNo,UCRPrefix as CaseI,UCRRefNo As ReqID,UCRNewUserCreationNewOld As Title,"
                + "UCRRequestedDate As RequestDate,UCRNewUserCreationStatus As Status, UCRNewUserTitle+ ' ' + UCRNewUserFirstName + ' ' + UCRNewUserMiddleName + ' ' + UCRNewUserLastName "
                + " As 'EmployeeName',UCRNewUserHCID As 'HC ID',ELoginName as Username,UCRNewUserDesg As Designation,UCRNewUserLocation+ ', ' + UCRNewUserDivision + ' ' + ' [ ' + UCRNewUserDeptName + ' - '+"
                + " UCRNewUserTeam + ' ] ' As Location, UCRUpdateBy,UcrUpdatedDate As Updated, UCRNewUserEmailID As Email, UCRNewUserPhone As Contact,UCRNewUserRemarks As Notes"
                 + " from UserCreationRequest with(nolock) Where UCRRefNo like @reqID";
                adp = new SqlDataAdapter(selectUserCreationRequest, Properties.Settings.Default.con.ToString());
                adp.SelectCommand.Parameters.AddWithValue("@reqID", '%' + txtSearchInputs.Text.Trim().ToString() + '%');
                ds = new DataSet();
                cnn.con_open();
                adp.Fill(ds, "UserCreationRequest");
                adp.Dispose();
                cnn.close_con();
                if (ds.Tables["UserCreationRequest"].Rows.Count > 0)
                {
                    dv = new DataView(ds.Tables["UserCreationRequest"]);
                    //cm = (CurrencyManager)this.BindingContext[dv, "UserCreationRequest"];
                    //cm = (CurrencyManager)this.BindingContext["UserCreationRequest"];

                    lblUpdateID.DataBindings.Clear();
                    lblUpdateID.DataBindings.Add("Text", dv, "CaseI");

                    lblTktRefNo.DataBindings.Clear();
                    lblTktRefNo.DataBindings.Add("Text", dv, "ReqID");

                    lblTicketCreatedDate.DataBindings.Clear();
                    lblTicketCreatedDate.DataBindings.Add("Text", dv, "RequestDate");

                    lblTktCreatedUsername.DataBindings.Clear();
                    lblTktCreatedUsername.DataBindings.Add("Text", dv, "Username");

                    lblTktCurrentStatus.DataBindings.Clear();
                    lblTktCurrentStatus.DataBindings.Add("Text", dv, "Status");

                    lblTktUserLocation.DataBindings.Clear();
                    lblTktUserLocation.DataBindings.Add("Text", dv, "Location");

                    lblTicketTitle.DataBindings.Clear();
                    lblTicketTitle.DataBindings.Add("Text", dv, "Title");

                    lblTicketJVIEmpName.DataBindings.Clear();
                    lblTicketJVIEmpName.DataBindings.Add("Text", dv, "EmployeeName");

                    lblTktUserEmail.DataBindings.Clear();
                    lblTktUserEmail.DataBindings.Add("Text", dv, "Email");

                    lblTktUserMobile.DataBindings.Clear();
                    lblTktUserMobile.DataBindings.Add("Text", dv, "Contact");

                    lblTktLastUpdateDetails.DataBindings.Clear();
                    lblTktLastUpdateDetails.DataBindings.Add("Text", dv, "Updated");

                    lblTicketDescription.DataBindings.Clear();
                    lblTicketDescription.DataBindings.Add("Text", dv, "Notes");

                    dtGridListAll.Show();
                    dtGridListAll.DataSource = dv;
                    tktInfoPanel.Show();

                    //lblTktRefNo.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["ReqID"]);
                    //lblTktRefNo.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["ReqID"]);
                }
                else
                {
                    MessageBox.Show("No User Creation Request Found", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    frmDashBoard_Load(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                frmDashBoard_Load(null, null);
            }
        }
        
        //Show All User Grevances
        protected void searchUserGrevance()
        {
            try
            {
                string selectUserGrevance = "Select ROW_NUMBER() OVER(ORDER BY ID ASC) AS 'Sr. No.','Issue In ' + GrCategory + ' ( ' + GrType + ' )' As Title,"
+"GrRefNo As TicketID,Format(GrLoggedInDate, 'dd-MMM-yyyy hh:mm:ss tt') as RequestedDate, EloginName AS UserName,GrPriority as Priority, GrRequestedUser as UserFullName,"
+"GrAltContact as Contact,GrRequestedUserEmail As Email, GrIssueFrom as IssueFrom, GrDesc AS Description,GrStatus as Status, "
+ "'By' + UGLastModifiedBy + 'On ' + UGLastModifiedDate As Updated, GrPrefix As CaseI from UserGreviences with(nolock) Where  GrRefNo like @GrID ORDER BY GrLoggedInDate desc";

                adp = new SqlDataAdapter(selectUserGrevance, Properties.Settings.Default.con.ToString());
                adp.SelectCommand.Parameters.AddWithValue("@GrID", '%' + txtSearchInputs.Text.Trim().ToString() + '%');
                ds = new DataSet();
                cnn.con_open();
                adp.Fill(ds, "UserGreviences");
                adp.Dispose();
                cnn.close_con();
                if (ds.Tables["UserGreviences"].Rows.Count > 0)
                {

                    dv = new DataView(ds.Tables["UserGreviences"]);
                    //cm = (CurrencyManager)this.BindingContext[dv, "UserCreationRequest"];
                    //cm = (CurrencyManager)this.BindingContext["UserCreationRequest"];

                    lblUpdateID.DataBindings.Clear();
                    lblUpdateID.DataBindings.Add("Text", dv, "CaseI");

                    lblTktRefNo.DataBindings.Clear();
                    lblTktRefNo.DataBindings.Add("Text", dv, "TicketID");

                    lblTicketCreatedDate.DataBindings.Clear();
                    lblTicketCreatedDate.DataBindings.Add("Text", dv, "RequestedDate");

                    lblTktCreatedUsername.DataBindings.Clear();
                    lblTktCreatedUsername.DataBindings.Add("Text", dv, "UserName");

                    lblTktCurrentStatus.DataBindings.Clear();
                    lblTktCurrentStatus.DataBindings.Add("Text", dv, "Status");

                    lblIndicatorLocation.Text = "Priority : ";
                    lblTktUserLocation.DataBindings.Clear();
                    lblTktUserLocation.DataBindings.Add("Text", dv, "Priority");

                    lblTicketTitle.DataBindings.Clear();
                    lblTicketTitle.DataBindings.Add("Text", dv, "Title");

                    lblTicketJVIEmpName.DataBindings.Clear();
                    lblTicketJVIEmpName.DataBindings.Add("Text", dv, "UserFullName");

                    lblTktUserEmail.DataBindings.Clear();
                    lblTktUserEmail.DataBindings.Add("Text", dv, "Email");

                    lblTktUserMobile.DataBindings.Clear();
                    lblTktUserMobile.DataBindings.Add("Text", dv, "Contact");

                    lblTktLastUpdateDetails.DataBindings.Clear();
                    lblTktLastUpdateDetails.DataBindings.Add("Text", dv, "Updated");

                    lblTicketDescription.DataBindings.Clear();
                    lblTicketDescription.DataBindings.Add("Text", dv, "Description");



                    dtGridListAll.Show();
                    dtGridListAll.DataSource = dv;
                    tktInfoPanel.Show();
                    
                }
                else
                {
                    MessageBox.Show("No User Grievance Found", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    frmDashBoard_Load(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                frmDashBoard_Load(null, null);
            }
        }
        
        //Show All Training Requests
        protected void searchTrainingRequest()
        {
            try
            {
                string selectAllTraining = "SELECT ROW_NUMBER() OVER(ORDER BY UT.TRefNo ASC) AS SrNo, UT.TRefNo as TicketID,"
              +"Format(UT.TTrainingCreatedDate, 'dd-MMM-yyyy hh:mm tt') As RequestedDate, UT.TTrainingTitle As Subject,"
              +"Format(UT.TdateFromTime, 'dd-MMM-yyyy hh:mm tt') As TFrom, Format(UT.TDateTillTime, 'dd-MMM-yyyy hh:mm tt') As 'End Date',"
              +"UT.TType as 'Training Type', UT.TTrainerName AS 'Trainer Name',UT.TTrainingLocation + ' ' + UT.TTrainingVenue As 'Training Venue',"
              +"UT.TTrainingStatus as Status,UT.TTrainingNotes as Remarks,'By ' + UT.TTrainingModifiedBy + ' On ' + UT.TTrainingModifiedDate As Updated,"
              +"UT.TPrefix as CaseI,J.EPreFix + ' ' + J.EFirstName + ' ' + J.EMiddleName + ' ' + J.ELastName as EmployeeName,UT.EloginName As UserName,"
			  +"J.EEmail As Email, J.EMobile As Mobile from UserTraining UT with(nolock) Join JVIEmp J on UT.ELoginName = J.ELoginName Where TRefNo like @a";

                adp = new SqlDataAdapter(selectAllTraining, Properties.Settings.Default.con.ToString());
                adp.SelectCommand.Parameters.AddWithValue("@a", '%' + txtSearchInputs.Text.Trim().ToString() + '%');
                ds = new DataSet();
                cnn.con_open();
                adp.Fill(ds, "UserTraining");
                adp.Dispose();
                cnn.close_con();
                if (ds.Tables["UserTraining"].Rows.Count > 0)
                {
                    dv = new DataView(ds.Tables["UserTraining"]);
                    //cm = (CurrencyManager)this.BindingContext[dv, "UserCreationRequest"];
                    //cm = (CurrencyManager)this.BindingContext["UserCreationRequest"];

                    lblUpdateID.DataBindings.Clear();
                    lblUpdateID.DataBindings.Add("Text", dv, "CaseI");

                    lblTktRefNo.DataBindings.Clear();
                    lblTktRefNo.DataBindings.Add("Text", dv, "TicketID");

                    lblTicketCreatedDate.DataBindings.Clear();
                    lblTicketCreatedDate.DataBindings.Add("Text", dv, "RequestedDate");

                    lblTktCreatedUsername.DataBindings.Clear();
                    lblTktCreatedUsername.DataBindings.Add("Text", dv, "UserName");

                    lblTktCurrentStatus.DataBindings.Clear();
                    lblTktCurrentStatus.DataBindings.Add("Text", dv, "Status");

                    lblIndicatorLocation.Text = "Training From : ";
                    lblTktUserLocation.DataBindings.Clear();
                    lblTktUserLocation.DataBindings.Add("Text", dv, "TFrom");

                    lblTicketTitle.DataBindings.Clear();
                    lblTicketTitle.DataBindings.Add("Text", dv, "Subject");

                    lblTicketJVIEmpName.DataBindings.Clear();
                    lblTicketJVIEmpName.DataBindings.Add("Text", dv, "EmployeeName");

                    lblTktUserEmail.DataBindings.Clear();
                    lblTktUserEmail.DataBindings.Add("Text", dv, "Email");

                    lblTktUserMobile.DataBindings.Clear();
                    lblTktUserMobile.DataBindings.Add("Text", dv, "Mobile");

                    lblTktLastUpdateDetails.DataBindings.Clear();
                    lblTktLastUpdateDetails.DataBindings.Add("Text", dv, "Updated");

                    lblTicketDescription.DataBindings.Clear();
                    lblTicketDescription.DataBindings.Add("Text", dv, "Remarks");

                    dtGridListAll.Show();
                    dtGridListAll.DataSource = dv;
                    tktInfoPanel.Show();
                }
                else
                {
                    MessageBox.Show("No Training Request Found", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    frmDashBoard_Load(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                frmDashBoard_Load(null, null);
            }
        }
        
        //Show All Feedbacks
        protected void searchFeedbacks()
        {
            try
            {
                string selectAllFB = "Select ROW_NUMBER() OVER(ORDER BY ID DESC) AS 'Sr. No.','Feedback for ' + FBType As 'Subject',"
            + "FBRefNo as RefNo,FBUserName as UserName,Format(FBDateTime, 'dd-MMM-yyyy hh:mm:ss tt') as FeedBackDate,"
            + "FBComments as 'Feedback Description',FBRating as Rating From UserFeebacks with(nolock) WHERE FBREFNo like @FBLogList Order By FBDateTime DESC";

                adp = new SqlDataAdapter(selectAllFB, Properties.Settings.Default.con.ToString());
                adp.SelectCommand.Parameters.AddWithValue("@FBLogList", '%' + txtSearchInputs.Text.Trim().ToString() + '%');
                ds = new DataSet();
                cnn.con_open();
                adp.Fill(ds, "UserFeebacks");
                adp.Dispose();
                cnn.close_con();
                if (ds.Tables["UserFeebacks"].Rows.Count > 0)
                {
                    dtGridListAll.Show();
                    dtGridListAll.DataSource = ds.Tables["UserFeebacks"];
                    tktInfoPanel.Show();

                }
                else
                {
                    MessageBox.Show("No Feedback Found", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    frmDashBoard_Load(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                frmDashBoard_Load(null, null);
            }
        }
        protected void showAllContacts()
        {
            try
            {
                string selectAllFB = "Select ROW_NUMBER() OVER(ORDER BY HC_USERS.UserName ASC) AS SrNo, isnull(Upper(HC_USERS.FirstName), '') as FirstName, "
            + "HC_USERS.JobTitle As 'Job Title',HCD.DivisionTitle + ' ( ' + HCL.LocationTitle + ' )' as 'Location', HCT.TeamTitle As Department,"
            + "lower(HC_USERS.EmailID) As Email,HC_USERS.Mobile from HC_USERS with(nolock) Join HCM_LOCATIONS HCL ON HC_USERS.LocationID=HCL.RID "
            + "Join HCM_DIVISIONS HCD On HC_USERS.DivisionID=HCD.RID Join HCM_Team HCT On HC_USERS.TeamID=HCT.RID  Where "
            + "HC_USERS.Status=0 AND HC_Users.FirstName like @el or HC_Users.UserName like @ek order by HC_USERS.UserName asc";

                adp = new SqlDataAdapter(selectAllFB, HCConn);
                adp.SelectCommand.Parameters.AddWithValue("@el", '%' + txtSearchInputs.Text.Trim().ToString() + '%');
                adp.SelectCommand.Parameters.AddWithValue("@ek", '%' + txtSearchInputs.Text.Trim().ToString() + '%');
                ds = new DataSet();
                HCConn.Open();
                adp.Fill(ds, "HC_USERS");
                HCConn.Close();
                if (ds.Tables["HC_USERS"].Rows.Count > 0)
                {
                    dtGridListAll.DataSource = ds.Tables["HC_USERS"];
                    dtGridListAll.Show();
                    tktInfoPanel.Show();

                }
                else
                {
                    MessageBox.Show("No Contact Found", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    dtGridListAll.DataSource = null;
                    dtGridListAll.Hide();
                    tktInfoPanel.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                dtGridListAll.DataSource = null;
                tktInfoPanel.Hide();
            }
        }
        public void CloseWindowProgram()
        {
            DialogResult dr = MessageBox.Show("Do you want to exit the application?", "Closing confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (dr == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dr == DialogResult.No)
            {
                this.BringToFront();
            }
        }
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            switch (e.CloseReason)
            {
                case CloseReason.UserClosing:
                    e.Cancel = true;
                    break;
            }

            base.OnFormClosing(e);

            //CloseWindowProgram();
        }
        private void btnCancelUpdate_Click(object sender, EventArgs e)
        {
            frmDashBoard_Load(null, null);
        }
        private void lblHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please read below Information carefully before using the"
+" system\n\n1. For User Creation Request, Type UCR followed by given number to search. Once Ticket details are fetched, please proceed with the updation in Ticket Details Box."
+"\n\n2. For User Grievance Type UG followed by number in search field to search ticket details to continue with update mode.\n\n3. For User Training Request Type"
+"JVI followed by number to continue with Training request update mode.\n\n4. For User Feedbacks type FB in search input fields and click to contiue to see feedbacks."
+"\n\n5. For Staff Contact Type Name or Email ID of employee to search contact details.\n\nFor Further Assistant Call On: 022 67241624 ( IT Team )", "Help & Support", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        }

        private void btnUpdateTicket_Click(object sender, EventArgs e)
        {
            try
            {

                if (lblUpdateID.Text == "UCR")
                {
                    UpdateUCRTicketInProcess();
                }
                else
                {
                    try
                    { }
                    catch (Exception ex)
                    {
                        MessageBox.Show(" Error Occured" + ex.ToString(), "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    }
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
            }
        }
        public void UpdateUCRTicketInProcess()
        {
            try
            { 
            DateTime localDate = DateTime.Now;
            string UpdateUcrTicket = "Update UserCreationRequest SET UCRNewUserCreationStatus=@UCRstatus, UCRUpdateBy=@UpdBy, UcrUpdatedDate=@UpdDt,UCRNewUserRemarks=@rem "
       + " WHERE UCRRefNo=@refNo";

            adp = new SqlDataAdapter(UpdateUcrTicket, Properties.Settings.Default.con.ToString());

            adp.SelectCommand.Parameters.AddWithValue("@UCRstatus", cmbTicketStatus.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@UpdBy", lblUserInfo.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@UpdDt", Convert.ToDateTime(localDate.ToString()));
            adp.SelectCommand.Parameters.AddWithValue("@rem", lblTicketDescription.Text.ToString().Trim());
            adp.SelectCommand.Parameters.AddWithValue("@refNo", lblTktRefNo.Text.ToString().Trim());

            ds = new DataSet();
            cnn.con_open();
            adp.Fill(ds, "UserCreationRequest");
            adp.Dispose();
            cnn.close_con();
            sendTicketUpdatedEmail();
            MessageBox.Show("Ticket details have been updated and confirmation email sent successfully", "Update Successful", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            frmDashBoard_Load(null, null);
            }catch ( Exception ex)
            { MessageBox.Show(ex.ToString(), "Error Occurred", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1); }
        }

        public void sendTicketUpdatedEmail()
        {
            try
            {
                string prepareSendEmail = "Select UCRRefNo As ReqID,UCRNewUserCreationNewOld As Title,UCRRequestedDate As RequestDate,UCRNewUserCreationStatus As Status," 
+" J.EPreFix + ' ' + J.EFirstName As ReqName, UCRNewUserTitle +' ' + UCRNewUserFirstName + ' ' + UCRNewUserMiddleName + ' ' + UCRNewUserLastName As 'EmployeeName',"
+" UCRNewUserHCID As 'HC ID',UCRNewUserDesg As Designation,UCRNewUserLocation + ', ' + UCRNewUserDivision + ' ' + ' [ ' + UCRNewUserDeptName + ' - ' + UCRNewUserTeam + ' ] ' As "
+" Location, UCRUpdateBy, UcrUpdatedDate As Updated, UCRNewUserEmailID As Email, UCRNewUserPhone As Contact, UCRNewUserRemarks As Notes, UCRRequestedUserEmail AS ToEmail"
+ " from UserCreationRequest with(nolock) LEFT JOIN JVIEmp J  ON J.ELoginName = UserCreationRequest.ELoginName WHERE UserCreationRequest.ELoginName=@reqID";

                adp = new SqlDataAdapter(prepareSendEmail, Properties.Settings.Default.con.ToString());
                adp.SelectCommand.Parameters.AddWithValue("@reqID", lblTktRefNo.Text.ToString().Trim());
                ds = new DataSet();
                cnn.con_open();
                adp.Fill(ds, "UserCreationRequest");
                adp.Dispose();
                cnn.close_con();
                if (ds.Tables["UserCreationRequest"].Rows.Count > 0)
                {

                    Label lblTitle = new Label();
                    Label lblReqID = new Label();
                    Label lblToEmail = new Label();
                    Label lblReqFullName = new Label();

                    //Pending Work: Last Updated on 09th December 2017 at 01:25pm
                    lblTitle.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["Title"]);
                    lblReqID.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["ReqID"]);

                    //Email ID of Ticket Requester
                    lblRequesterEmailID.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["ToEmail"]);
                    lblReqFullName.Text = string.Format("{0}", ds.Tables["UserCreationRequest"].DefaultView[0]["ReqName"]);


                    //Send Email

                    MailMessage msg = new MailMessage();
                    SmtpClient client = new SmtpClient("smtpout.jvi-global.com");
                    msg.From = new MailAddress("support2@jvi-global.com");
                    msg.To.Add(lblRequesterEmailID.Text.ToString());
                    msg.CC.Add(lblTktUserEmail.Text.ToString());
                    msg.Subject = lblTktRefNo.Text.ToString() + " : " + lblTicketTitle.Text.ToString();
                    msg.Body = "<div class=emailContent><font family=arial size=4 color=blue>Dear " + lblReqFullName.Text.ToString() + ",<br>Greetings! from Jerry Varghese International,"
                    + "<br/><br><desc>We are glad to inform you that your request to Create New User request has been updated as <b><u>" + cmbTicketStatus.Text.ToString() + "</u></b>. Your request is being processed shortly."
                    + "You will receive confirmation email once it has been processed successfully.<br/><br>Please find below updated status for your request<hr /></font>"
                    + "<font color=white family=verdana size=4><table align=centre width=100% cellpadding=2 rowpadding=5 cellspacing=2 border=2 bordercolor=blue><tr font family=verdana bgcolor=grey>"
                    + "<th>Sr.No.</th><th>Request Title</th><th>Ticket No.</th><th>Ticket Created Date</th><th>Current Status</th><th>Requested Username</th><th>Joined Employee Name</th><th>Ticket Updated Information</th><th>Ticket Description</th></tr>"
                    + "<tr align=center><td>1</td><td>" + lblTicketTitle.Text.ToString() + "</td><td>" + lblTktRefNo.Text.ToString() + "</td>"
                    + "<td>" + lblTicketCreatedDate.Text.ToString() + "</td><td>" + cmbTicketStatus.Text.ToString() + "<td>" + lblTktCreatedUsername.Text.ToString() + "</td><td>" + lblTicketJVIEmpName.Text.ToString() + "</td>"
                    + "<td>At " + Convert.ToDateTime(System.DateTime.Now).ToString() + " By <b>" + lblUserInfo.Text.ToString() + "</b></td><td>" + lblTicketDescription.Text.ToString() + "</td></tr></table></div>"
                    + "<br></font><font family=verdana size=4 color=black>Kindly make login again, If you wish to change the training schedule details.</font><br><hr><br>"
                    + "<img src=http://103.231.41.110/Logo/Sign.png width=100% height=240px alt=Signature></div>";
                    msg.IsBodyHtml = true;
                    //client.Port = 465;
                    client.Port = 25;
                    client.Credentials = new NetworkCredential("support2@jvi-global.com", "Hraf@923");
                    client.EnableSsl = false;
                    client.Send(msg);
                    MessageBox.Show("Email Sent", "Sent Email", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error in sending email", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void lblMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void lblLogout_Click(object sender, EventArgs e)
        {
            CloseWindowProgram();
        }

        private void lblReport_Click(object sender, EventArgs e)
        {

        }
    }

}
